//! Only fields selected for publication are stored by the gateway.
use axum::{
    extract::{Query, State},
    http::{header::CACHE_CONTROL, HeaderMap, HeaderName, StatusCode},
    Json,
};
use base64::{engine::general_purpose::STANDARD, Engine};
use bson::{doc, Document};
use serde::Deserialize;
use serde_json::{json, Value};

use crate::{wake, AppState};

type Response = ([(HeaderName, &'static str); 1], Json<Value>);
type Error = (StatusCode, Json<Value>);

#[derive(Default, Deserialize)]
pub struct ProfileQuery {
    lns: Option<String>,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct PublicProfile {
    headline: String,
    bio: String,
    avatar: String,
    is_public: bool,
}

fn error(status: StatusCode, detail: &str) -> Error {
    (status, Json(json!({ "detail": detail })))
}

fn storage_error(_: mongodb::error::Error) -> Error {
    error(StatusCode::SERVICE_UNAVAILABLE, "profile storage unavailable")
}

fn reply(value: Value) -> Response {
    ([(CACHE_CONTROL, "no-store")], Json(value))
}

async fn account(state: &AppState, headers: &HeaderMap) -> Result<String, Error> {
    let (owner, issued_at) = wake::identity(headers)?;
    wake::require_active(state, &owner).await?;
    wake::check_revocation(state, &owner, issued_at).await?;
    Ok(owner)
}

fn valid_avatar(avatar: &str) -> bool {
    if avatar.is_empty() { return true; }
    if avatar.len() > 180_000 { return false; }
    avatar.strip_prefix("data:image/jpeg;base64,")
        .and_then(|data| STANDARD.decode(data).ok())
        .is_some_and(|jpeg| jpeg.starts_with(&[0xff, 0xd8, 0xff]) && jpeg.ends_with(&[0xff, 0xd9]))
}

pub async fn get(
    State(state): State<AppState>,
    headers: HeaderMap,
    Query(query): Query<ProfileQuery>,
) -> Result<Response, Error> {
    let owner = account(&state, &headers).await?;
    let target = query.lns.as_deref().unwrap_or(&owner);
    if target.is_empty() || target.len() > 254 {
        return Err(error(StatusCode::BAD_REQUEST, "invalid identity"));
    }
    let row = state.db.collection::<Document>("lns")
        .find_one(doc! { "lns_name": target, "status": "ACTIVE" })
        .projection(doc! { "_id": 0, "ultron_public_profile": 1 })
        .await.map_err(storage_error)?;
    let details = row.as_ref().and_then(|row| row.get_document("ultron_public_profile").ok());
    let field = |key| details.and_then(|d| d.get_str(key).ok()).unwrap_or("");
    Ok(reply(json!({
        "lns": target,
        "is_public": details.is_some(),
        "headline": field("headline"),
        "bio": field("bio"),
        "avatar": field("avatar")
    })))
}

pub async fn save(
    State(state): State<AppState>,
    headers: HeaderMap,
    Json(profile): Json<PublicProfile>,
) -> Result<Response, Error> {
    let owner = account(&state, &headers).await?;
    let update = if profile.is_public {
        let headline = profile.headline.trim();
        let bio = profile.bio.trim();
        if headline.encode_utf16().count() > 120 || bio.encode_utf16().count() > 500
            || !valid_avatar(&profile.avatar)
            || (headline.is_empty() && bio.is_empty() && profile.avatar.is_empty())
        {
            return Err(error(StatusCode::BAD_REQUEST, "invalid public profile details"));
        }
        doc! { "$set": { "ultron_public_profile": {
            "headline": headline, "bio": bio, "avatar": &profile.avatar
        } } }
    } else {
        doc! { "$unset": { "ultron_public_profile": "" } }
    };
    let result = state.db.collection::<Document>("lns")
        .update_one(doc! { "lns_name": &owner, "status": "ACTIVE" }, update)
        .await.map_err(storage_error)?;
    if result.matched_count != 1 {
        return Err(error(StatusCode::NOT_FOUND, "profile unavailable"));
    }
    Ok(reply(json!({ "ok": true })))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn avatar_uses_bounded_inline_jpeg() {
        assert!(valid_avatar(""));
        assert!(valid_avatar("data:image/jpeg;base64,/9j//9k="));
        assert!(!valid_avatar("https://example.org/image.jpg"));
        assert!(!valid_avatar("data:image/jpeg;base64,YQ=="));
        assert!(!valid_avatar(&format!("data:image/jpeg;base64,{}", "A".repeat(180_000))));
    }
}
