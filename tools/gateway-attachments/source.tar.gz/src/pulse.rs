//! `POST /api/pulse/send` and `GET /api/pulse/session/{conv_id}` — native
//! Rust port of `routes/pulse_mutating.py`. (M7 step 4)
//!
//! Implements:
//!   * Sealed-sender envelope (SHAKE-256 keystream + SHA3-256 16-byte tag).
//!   * ZK-RLN admission control via the `rln_quota` collection
//!     (atomic find_one_and_update — same semantics as Python).
//!   * Conv ID derivation = SHA3-256 of sorted "lo|hi" pair (24-char hex).
//!   * Double-Ratchet session bookkeeping in `pulse_sessions`.
//!   * Loopix 3-hop mixnet route preview (deterministic seed-driven).
//!   * On-chain `NotarySeal` anchor TX every `PULSE_ANCHOR_EVERY` messages
//!     (QBFT-finalised via `chain::finalise_block_for_tx_locked`).
//!
//! Differences from Python:
//!   * `rln_nullifier_hex` / `rln_commitment_hex` audit fields are computed
//!     with **Starknet Poseidon** (`starknet-crypto` crate) over the same
//!     Starknet felt prime as `poseidon_py` — values byte-identical to the
//!     Python reference. (Wired in M7 step 4b.)
//!   * `req.rln_proof` strict validation is skipped (frontend doesn't
//!     send it). The atomic quota check still enforces 10 msg/60 s/LNS.
//!   * Mixnet HTTP forward to relay-01 is NOT triggered (Python had a
//!     fire-and-forget call to `route_through_mixnet_fn`); the route
//!     preview (hops + delays) is still emitted in the response.

use std::collections::HashMap;

use axum::{extract::{Path, State}, http::StatusCode, Json};
use bson::{doc, Document};
use rand::RngCore;
use serde::{Deserialize, Serialize};
use sha3::{
    digest::{ExtendableOutput, Update, XofReader},
    Digest, Sha3_256, Sha3_512, Shake256,
};

use crate::chain;
use crate::chain::utc_iso;
use crate::crypto::{det_hex, pqc_sign_or_delegate};
use crate::rln;
use crate::AppState;

const RLN_EPOCH_SECONDS: i64 = 60;
const RLN_MAX_PER_EPOCH: i64 = 10;
const PULSE_ANCHOR_EVERY: i64 = 3;

#[derive(Debug, Deserialize)]
pub struct PulseSendRequest {
    pub from_lns: String,
    #[serde(default)]
    pub to_lns: Option<String>,
    #[serde(default)]
    pub recipients_lns: Option<Vec<String>>,
    pub plaintext: String,
    #[serde(default)]
    pub client_msg_id: Option<String>,
    #[serde(default)]
    pub attachment_ids: Option<Vec<String>>,
    #[serde(default)]
    pub rln_proof: Option<serde_json::Value>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct RouteHop {
    pub layer: i32,
    pub relay_node_id: String,
    pub relay_label: String,
    pub relay_region: String,
    pub onion_layer_hash: String,
    pub delay_ms: i64,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct PulseSendResponse {
    pub ok: bool,
    pub msg_id: String,
    pub conv_id: String,
    pub ciphertext_hex: String,
    pub nonce_hex: String,
    pub sealed_at: String,
    pub anchor_tx_id: Option<String>,
    pub anchor_block_index: Option<i64>,
    pub session_fingerprint: String,
    pub epoch: i64,
    pub message_number: i64,
    pub route_id: String,
    pub route_hops: Vec<RouteHop>,
    pub rln_slot_used: i64,
    pub rln_slot_max: i64,
}

#[derive(Debug, Serialize)]
pub struct PulseError { pub detail: String }
fn err(code: StatusCode, msg: impl Into<String>) -> (StatusCode, Json<PulseError>) {
    (code, Json(PulseError { detail: msg.into() }))
}

fn conv_id(a: &str, b: &str) -> String {
    let mut pair = [a.to_lowercase(), b.to_lowercase()];
    pair.sort();
    let mut h = Sha3_256::new();
    Digest::update(&mut h, format!("{}|{}", pair[0], pair[1]).as_bytes());
    let out = hex::encode(h.finalize());
    format!("conv-{}", &out[..24])
}

fn pulse_session_fingerprint(conv_id: &str, participants: &[String]) -> String {
    let mut sorted: Vec<String> = participants.iter().map(|p| p.to_lowercase()).collect();
    sorted.sort();
    let pair = sorted.join("|");
    let mut h = Sha3_256::new();
    Digest::update(&mut h, format!("{}|{}", conv_id, pair).as_bytes());
    let bytes = h.finalize();
    bytes.iter().take(8).map(|b| format!("{:02X}", b)).collect::<Vec<_>>().join(":")
}

fn current_rln_epoch() -> i64 {
    chrono::Utc::now().timestamp() / RLN_EPOCH_SECONDS
}

fn shake256(input: &[u8], out_len: usize) -> Vec<u8> {
    let mut x = Shake256::default();
    x.update(input);
    let mut reader = x.finalize_xof();
    let mut out = vec![0u8; out_len];
    reader.read(&mut out);
    out
}

fn get_i64_lenient(d: &Document, key: &str) -> i64 {
    if let Ok(v) = d.get_i64(key) { return v; }
    if let Ok(v) = d.get_i32(key) { return v as i64; }
    if let Ok(v) = d.get_f64(key) { return v as i64; }
    0
}

// ULTRON_V72_A224_DUPLICATE_KEY_CLASSIFIER
fn pulse_is_duplicate_code(code: i32) -> bool {
    code == 11000
}

fn pulse_is_duplicate_key(error: &mongodb::error::Error) -> bool {
    use mongodb::error::{ErrorKind, WriteFailure};

    match error.kind.as_ref() {
        ErrorKind::Write(WriteFailure::WriteError(write_error)) => {
            pulse_is_duplicate_code(write_error.code)
        }
        _ => false,
    }
}

// ULTRON_V72_A224_DUPLICATE_CLASSIFIER_TESTS
#[cfg(test)]
mod pulse_duplicate_classifier_tests {
    use super::pulse_is_duplicate_code;

    #[test]
    fn recognizes_duplicate_key_11000() {
        assert!(pulse_is_duplicate_code(11000));
    }

    #[test]
    fn rejects_other_write_errors() {
        assert!(!pulse_is_duplicate_code(11001));
        assert!(!pulse_is_duplicate_code(121));
        assert!(!pulse_is_duplicate_code(0));
    }
}

// ULTRON_V72_A224_ATOMIC_OPERATION_CLAIM
#[derive(Debug, PartialEq, Eq)]
enum PulseOperationClaim {
    Acquired,
    AlreadyExists,
}

async fn pulse_claim_operation(
    db: &mongodb::Database,
    tenant: &str,
    from_lns: &str,
    client_msg_id: &str,
    request_fingerprint: &str,
    msg_id: &str,
) -> Result<PulseOperationClaim, mongodb::error::Error> {
    let collection = db.collection::<Document>("pulse_send_operations");

    let operation = doc! {
        "tenant_id": tenant,
        "from_lns": from_lns,
        "client_msg_id": client_msg_id,
        "request_fingerprint": request_fingerprint,
        "msg_id": msg_id,
        "state": "PENDING",
        "created_at": utc_iso(),
        "updated_at": utc_iso(),
    };

    match collection.insert_one(operation).await {
        Ok(_) => Ok(PulseOperationClaim::Acquired),
        Err(e) if pulse_is_duplicate_key(&e) => {
            Ok(PulseOperationClaim::AlreadyExists)
        }
        Err(e) => Err(e),
    }
}

// ULTRON_V72_A224_RUST_MONGO_INTEGRATION
#[cfg(test)]
mod pulse_mongo_integration_tests {
    use super::{pulse_claim_operation, PulseOperationClaim};
    use bson::doc;
    use mongodb::Client;

    #[tokio::test]
    #[ignore = "requires explicitly configured isolated MongoDB"]
    async fn concurrent_claims_allow_only_one_acquisition() {
        let uri = std::env::var("ULTRON_A224_TEST_MONGO_URI")
            .expect("isolated MongoDB URI required");

        let db_name = std::env::var("ULTRON_A224_TEST_DB")
            .expect("isolated database name required");

        assert_eq!(
            db_name,
            "ultron_v72_persistence_isolated",
            "refusing non-isolated database"
        );

        let client = Client::with_uri_str(&uri)
            .await
            .expect("MongoDB connection failed");

        let db = client.database(&db_name);
        let collection =
            db.collection::<bson::Document>("pulse_send_operations");

        let run_id = bson::oid::ObjectId::new().to_hex();

        let tenant = "__a224_rust_integration__";
        let sender = "__a224_rust_sender__";
        let fingerprint = "synthetic-rust-test";

        let key = doc! {
            "tenant_id": tenant,
            "from_lns": sender,
            "client_msg_id": &run_id,
        };

        let (first, second) = tokio::join!(
            pulse_claim_operation(
                &db, tenant, sender, &run_id,
                fingerprint, "test-message-one"
            ),
            pulse_claim_operation(
                &db, tenant, sender, &run_id,
                fingerprint, "test-message-two"
            )
        );

        let cleanup = collection.delete_many(key.clone()).await;

        let first = first.expect("first claim failed");
        let second = second.expect("second claim failed");

        let acquired = [&first, &second]
            .iter()
            .filter(|result| {
                ***result == PulseOperationClaim::Acquired
            })
            .count();

        let duplicates = [&first, &second]
            .iter()
            .filter(|result| {
                ***result == PulseOperationClaim::AlreadyExists
            })
            .count();

        assert_eq!(acquired, 1);
        assert_eq!(duplicates, 1);

        let deleted = cleanup
            .expect("cleanup failed")
            .deleted_count;

        assert_eq!(deleted, 1);
    }
}

// ULTRON_V72_A224_REQUEST_FINGERPRINT
fn pulse_request_fingerprint(
    tenant: &str,
    from_lns: &str,
    to_lns: &str,
    plaintext: &str,
    attachment_ids: &[String],
) -> String {
    let canonical = serde_json::json!({
        "version": 1,
        "tenant_id": tenant,
        "from_lns": from_lns,
        "to_lns": to_lns,
        "plaintext": plaintext,
        "attachment_ids": attachment_ids,
    });

    let encoded = serde_json::to_vec(&canonical)
        .expect("canonical fingerprint serialization");

    let mut hasher = Sha3_256::new();
    Digest::update(&mut hasher, &encoded);

    hex::encode(hasher.finalize())
}

// ULTRON_V72_A223_UUID_HELPER
fn valid_client_msg_id(client_id: &str) -> bool {
    let bytes = client_id.as_bytes();

    bytes.len() == 36
        && bytes.iter().enumerate().all(|(i, b)| {
            if matches!(i, 8 | 13 | 18 | 23) {
                *b == b'-'
            } else {
                b.is_ascii_hexdigit()
            }
        })
}

#[cfg(test)]
mod pulse_idempotency_tests {
    use super::{valid_client_msg_id, pulse_request_fingerprint};

    fn fingerprint(text: &str, recipient: &str, attachments: &[String]) -> String {
        pulse_request_fingerprint(
            "tenant-test",
            "alice.uns",
            recipient,
            text,
            attachments,
        )
    }

    #[test]
    fn identical_requests_have_identical_fingerprint() {
        let a = fingerprint("hello", "bob.uns", &[]);
        let b = fingerprint("hello", "bob.uns", &[]);
        assert_eq!(a, b);
        assert_eq!(a.len(), 64);
    }

    #[test]
    fn different_plaintext_changes_fingerprint() {
        assert_ne!(
            fingerprint("hello", "bob.uns", &[]),
            fingerprint("hello!", "bob.uns", &[])
        );
    }

    #[test]
    fn different_recipient_changes_fingerprint() {
        assert_ne!(
            fingerprint("hello", "bob.uns", &[]),
            fingerprint("hello", "charlie.uns", &[])
        );
    }

    #[test]
    fn different_attachments_change_fingerprint() {
        let a = vec!["attachment-1".to_string()];
        let b = vec!["attachment-2".to_string()];

        assert_ne!(
            fingerprint("hello", "bob.uns", &a),
            fingerprint("hello", "bob.uns", &b)
        );
    }

    #[test]
    fn accepts_canonical_uuid() {
        assert!(valid_client_msg_id(
            "550e8400-e29b-41d4-a716-446655440000"
        ));
    }

    #[test]
    fn accepts_uppercase_uuid() {
        assert!(valid_client_msg_id(
            "550E8400-E29B-41D4-A716-446655440000"
        ));
    }

    #[test]
    fn rejects_empty_id() {
        assert!(!valid_client_msg_id(""));
    }

    #[test]
    fn rejects_short_id() {
        assert!(!valid_client_msg_id("550e8400-e29b-41d4"));
    }

    #[test]
    fn rejects_invalid_character() {
        assert!(!valid_client_msg_id(
            "550e8400-e29b-41d4-a716-44665544000Z"
        ));
    }

    #[test]
    fn rejects_missing_hyphens() {
        assert!(!valid_client_msg_id(
            "550e8400e29b41d4a716446655440000"
        ));
    }
}

pub async fn pulse_send(
    State(state): State<AppState>,
    headers: axum::http::HeaderMap,
    Json(req): Json<PulseSendRequest>,
) -> Result<Json<PulseSendResponse>, (StatusCode, Json<PulseError>)> {
    // ULTRON_V72_PULSE_AUTH
    let claims = crate::misc::jwt_decode(&headers)
        .ok_or_else(|| err(StatusCode::UNAUTHORIZED, "JWT required"))?;

    let caller = claims.sub.as_deref().unwrap_or("").trim().to_lowercase();
    let tenant = claims.tenant_id.as_deref().unwrap_or("").trim();

    if caller.is_empty() || tenant.is_empty() {
        return Err(err(StatusCode::FORBIDDEN, "identity or tenant missing"));
    }

    let from_lns = req.from_lns.trim().to_lowercase();

    if from_lns != caller {
        return Err(err(StatusCode::FORBIDDEN, "sender identity mismatch"));
    }

    // ULTRON_V72_A22_CLIENT_MSG_ID_VALIDATION
    if let Some(client_id) = req.client_msg_id.as_deref() {
        if !valid_client_msg_id(client_id) {
            return Err(err(
                StatusCode::UNPROCESSABLE_ENTITY,
                "client_msg_id must be a canonical UUID",
            ));
        }
    }

    if from_lns.is_empty() {
        return Err(err(StatusCode::UNPROCESSABLE_ENTITY, "from_lns required"));
    }
    let target = req.to_lns.clone()
        .or_else(|| req.recipients_lns.as_ref().and_then(|v| v.first().cloned()));
    let to_lns = target.unwrap_or_default().trim().to_lowercase();
    if to_lns.is_empty() {
        return Err(err(StatusCode::UNPROCESSABLE_ENTITY, "to_lns or recipients_lns required"));
    }
    if from_lns == to_lns {
        return Err(err(StatusCode::UNPROCESSABLE_ENTITY, "from_lns and to_lns must differ"));
    }

    // -- LNS active check + cross-tenant guard --
    let lns_coll = state.db.collection::<Document>("lns");
    let sender = lns_coll.find_one(doc! {"lns_name": &from_lns}).await
        .map_err(|e| err(StatusCode::INTERNAL_SERVER_ERROR, format!("db: {e}")))?;
    let recipient = lns_coll.find_one(doc! {"lns_name": &to_lns}).await
        .map_err(|e| err(StatusCode::INTERNAL_SERVER_ERROR, format!("db: {e}")))?;
    let sender = sender.ok_or_else(|| err(StatusCode::NOT_FOUND, format!("Sender LNS not active: {}", from_lns)))?;
    let recipient = recipient.ok_or_else(|| err(StatusCode::NOT_FOUND, format!("Recipient LNS not active: {}", to_lns)))?;
    if sender.get_str("status").unwrap_or("") != "ACTIVE" {
        return Err(err(StatusCode::NOT_FOUND, format!("Sender LNS not active: {}", from_lns)));
    }
    if recipient.get_str("status").unwrap_or("") != "ACTIVE" {
        return Err(err(StatusCode::NOT_FOUND, format!("Recipient LNS not active: {}", to_lns)));
    }
    let s_tenant = sender.get_str("tenant_id")
        .ok().map(str::trim)
        .filter(|t| !t.is_empty())
        .map(String::from);

    let r_tenant = recipient.get_str("tenant_id")
        .ok().map(str::trim)
        .filter(|t| !t.is_empty())
        .map(String::from);

    if s_tenant.as_deref() != Some(tenant)
        || r_tenant.as_deref() != Some(tenant)
    {
        return Err(err(StatusCode::FORBIDDEN, "tenant authorization failed"));
    }


    // ULTRON_V72_A224_HTTP_IDEMPOTENCY
    // Attachments validation (basic)
    let mut attachments_meta: Vec<Document> = Vec::new();
    if let Some(ids) = req.attachment_ids.as_ref() {
        for att_id in ids.iter().take(10) {
            let att = state.db.collection::<Document>("attachments")
                .find_one(doc! {"attachment_id": att_id}).await
                .map_err(|e| err(StatusCode::INTERNAL_SERVER_ERROR, format!("db: {e}")))?;
            let att = att.ok_or_else(|| err(StatusCode::NOT_FOUND, format!("attachment not found: {att_id}")))?;
            if att.get_str("owner_lns").unwrap_or("") != from_lns
                    || att.get_str("tenant_id").unwrap_or("") != tenant
                {
                return Err(err(StatusCode::FORBIDDEN, format!("attachment {} does not belong to you", att_id)));
            }
            attachments_meta.push(doc! {
                "attachment_id": att_id,
                "filename": att.get_str("filename").unwrap_or(""),
                "mime": att.get_str("mime").unwrap_or(""),
                "size": get_i64_lenient(&att, "size"),
                "sha3_512_hex": att.get_str("sha3_512_hex").unwrap_or(""),
            });
        }
    }
    if req.plaintext.trim().is_empty() && attachments_meta.is_empty() {
        return Err(err(StatusCode::UNPROCESSABLE_ENTITY, "message must have text or at least one attachment"));
    }


    let request_fingerprint = req.client_msg_id.as_ref().map(|_| {
        pulse_request_fingerprint(
            tenant,
            &from_lns,
            &to_lns,
            &req.plaintext,
            req.attachment_ids.as_deref().unwrap_or(&[]),
        )
    });

    let msg_id = format!(
        "pulse-{}",
        hex::encode(rand::random::<[u8; 16]>())
    );

    if let (Some(client_id), Some(fingerprint)) =
        (req.client_msg_id.as_deref(), request_fingerprint.as_deref())
    {
        let claim = pulse_claim_operation(
            &state.db,
            tenant,
            &from_lns,
            client_id,
            fingerprint,
            &msg_id,
        )
        .await
        .map_err(|e| err(
            StatusCode::INTERNAL_SERVER_ERROR,
            format!("operation claim failed: {e}")
        ))?;

        if claim == PulseOperationClaim::AlreadyExists {
            let recovery = pulse_load_operation(
                &state.db,
                tenant,
                &from_lns,
                client_id,
                fingerprint,
            )
            .await
            .map_err(|e| err(
                StatusCode::INTERNAL_SERVER_ERROR,
                format!("operation recovery failed: {e}")
            ))?;

            return match recovery {
                PulseOperationRecovery::Committed(response) =>
                    Ok(Json(response)),

                PulseOperationRecovery::Pending =>
                    Err(err(
                        StatusCode::CONFLICT,
                        "operation pending; automatic retry disabled"
                    )),

                PulseOperationRecovery::Conflict =>
                    Err(err(
                        StatusCode::CONFLICT,
                        "client_msg_id already used with different content"
                    )),

                PulseOperationRecovery::Missing =>
                    Err(err(
                        StatusCode::SERVICE_UNAVAILABLE,
                        "operation missing during recovery"
                    )),

                PulseOperationRecovery::Invalid =>
                    Err(err(
                        StatusCode::INTERNAL_SERVER_ERROR,
                        "stored operation is invalid"
                    )),
            };
        }
    }

    // -- ZK-RLN admission control (atomic findAndModify on rln_quota) --
    let epoch = current_rln_epoch();
    let quota_coll = state.db.collection::<Document>("rln_quota");
    let q = quota_coll.find_one_and_update(
        doc! {"lns": &from_lns, "epoch": epoch},
        doc! {"$inc": {"used": 1_i64}, "$setOnInsert": {"created_at": utc_iso()}},
    )
    .upsert(true)
    .return_document(mongodb::options::ReturnDocument::After)
    .await
    .map_err(|e| err(StatusCode::INTERNAL_SERVER_ERROR, format!("rln_quota: {e}")))?;
    let used = q.as_ref().map(|d| get_i64_lenient(d, "used")).unwrap_or(1);
    if used > RLN_MAX_PER_EPOCH {
        let _ = quota_coll.update_one(
            doc! {"lns": &from_lns, "epoch": epoch},
            doc! {"$inc": {"used": -1_i64}},
        ).await;
        return Err(err(
            StatusCode::TOO_MANY_REQUESTS,
            format!("ZK-RLN rate limit exceeded · {}/{}s · epoch {}", RLN_MAX_PER_EPOCH, RLN_EPOCH_SECONDS, epoch),
        ));
    }

    let nullifier_hex = rln::rln_nullifier(&state.db, &from_lns, epoch).await
        .map_err(|e| err(StatusCode::INTERNAL_SERVER_ERROR, format!("rln_nullifier: {e}")))?;
    let commitment_hex = rln::rln_commitment(&state.db, &from_lns).await
        .map_err(|e| err(StatusCode::INTERNAL_SERVER_ERROR, format!("rln_commitment: {e}")))?;
    let _ = state.db.collection::<Document>("rln_nullifiers").insert_one(doc! {
        "epoch": epoch,
        "lns": &from_lns,
        "nullifier_hex": &nullifier_hex,
        "commitment_hex": &commitment_hex,
        "used_slot": used,
        "observed_at": utc_iso(),
        "algo": "poseidon-starknet",
    }).await;

    // Optional client-supplied rln_proof verification (Poseidon nullifier).
    if let Some(p) = req.rln_proof.as_ref() {
        if let Some(nul) = p.get("nullifier").and_then(|v| v.as_str()) {
            if nul.to_ascii_lowercase() != nullifier_hex {
                return Err(err(StatusCode::BAD_REQUEST, "ZK-RLN proof: nullifier mismatch"));
            }
        }
        if let Some(ep) = p.get("epoch").and_then(|v| v.as_i64()) {
            if ep != epoch {
                return Err(err(StatusCode::BAD_REQUEST, "ZK-RLN proof: stale epoch"));
            }
        }
    }

    // -- Sealed-sender envelope (SHAKE-256 keystream + SHA3-256 tag) --
    let cid = conv_id(&from_lns, &to_lns);
    let ts = utc_iso();
    let mut nonce = [0u8; 12];
    rand::rngs::OsRng.fill_bytes(&mut nonce);
    let pt = req.plaintext.as_bytes();
    let need = pt.len().max(64);
    let mut input = nonce.to_vec();
    input.extend_from_slice(cid.as_bytes());
    let ks = shake256(&input, need);
    let ct: Vec<u8> = pt.iter().zip(ks.iter()).map(|(p, k)| p ^ k).collect();
    let mut tag_h = Sha3_256::new();
    Digest::update(&mut tag_h, &ct);
    Digest::update(&mut tag_h, &nonce);
    let tag = tag_h.finalize();
    let mut ciphertext = ct.clone();
    ciphertext.extend_from_slice(&tag[..16]);
    let ciphertext_hex = hex::encode(&ciphertext);
    let nonce_hex = hex::encode(&nonce);


    let _ = state.db.collection::<Document>("pulse_messages").insert_one(doc! {
        "msg_id": &msg_id,
        "conv_id": &cid,
        "from_lns": &from_lns,
        "to_lns": &to_lns,
        "ciphertext_hex": &ciphertext_hex,
        "nonce_hex": &nonce_hex,
        "sealed_at": &ts,
        "anchor_tx_id": bson::Bson::Null,
        "plaintext": &req.plaintext,  // unencrypted at-rest — envelope.seal_text is Python-only for now
        "attachments": if attachments_meta.is_empty() { bson::Bson::Null } else { bson::Bson::Array(attachments_meta.iter().map(|d| bson::Bson::Document(d.clone())).collect()) },
        "via": "lattice-gateway-rust",
    }).await
        .map_err(|e| err(
            StatusCode::INTERNAL_SERVER_ERROR,
            format!("message insert failed: {e}")
        ))?;

    // -- Conversation bump --
    let mut conv_participants = vec![from_lns.clone(), to_lns.clone()];
    conv_participants.sort();
    let conv_participants_bson = bson::Bson::Array(
        conv_participants.iter().map(|s| bson::Bson::String(s.clone())).collect()
    );
    let conv = state.db.collection::<Document>("pulse_conversations")
        .find_one_and_update(
            doc! {"conv_id": &cid},
            doc! {
                "$set": {"last_message_at": &ts, "participants": conv_participants_bson},
                "$inc": {"message_count": 1_i64},
                "$setOnInsert": {
                    "conv_id": &cid,
                    "last_anchor_tx": bson::Bson::Null,
                    "last_anchor_block": bson::Bson::Null,
                    "started_at": &ts,
                },
            },
        )
        .upsert(true)
        .return_document(mongodb::options::ReturnDocument::After)
        .await
        .map_err(|e| err(StatusCode::INTERNAL_SERVER_ERROR, format!("conv upsert: {e}")))?;
    let conv = conv.unwrap_or_default();
    let message_number = get_i64_lenient(&conv, "message_count").max(1);

    // -- Session bookkeeping --
    let mut participants: Vec<String> = vec![from_lns.clone(), to_lns.clone()];
    participants.sort();
    let session_fp = pulse_session_fingerprint(&cid, &participants);
    let epoch_count = ((message_number - 1) / PULSE_ANCHOR_EVERY) + 1;
    let mut root_h = Sha3_256::new();
    Digest::update(&mut root_h, format!("root|{}|epoch={}", cid, epoch_count).as_bytes());
    let root_fp: String = hex::encode(root_h.finalize())[..32].to_uppercase();
    let _ = state.db.collection::<Document>("pulse_sessions").update_one(
        doc! {"conv_id": &cid},
        doc! {
            "$set": {
                "conv_id": &cid,
                "participants": bson::Bson::Array(participants.iter().map(|s| bson::Bson::String(s.clone())).collect()),
                "fingerprint": &session_fp,
                "epoch": epoch_count,
                "message_number": message_number,
                "root_key_fingerprint": &root_fp,
                "cipher_suite": "PQXDH(ML-KEM-768) + Double-Ratchet · AEAD: AES-256-GCM",
            },
            "$setOnInsert": {"started_at": &ts},
        },
    ).upsert(true).await
        .map_err(|e| err(
            StatusCode::INTERNAL_SERVER_ERROR,
            format!("session update failed: {e}")
        ))?;

    // -- Loopix mixnet route preview --
    let relays_coll = state.db.collection::<Document>("mixnet_relays");
    let mut all_relays: Vec<Document> = Vec::new();
    if let Ok(mut cur) = relays_coll.find(doc! {}).await {
        use futures::StreamExt;
        while let Some(r) = cur.next().await { if let Ok(d) = r { all_relays.push(d); } }
    }
    let mut layers: HashMap<i64, Vec<Document>> = HashMap::new();
    for r in &all_relays {
        let l = get_i64_lenient(r, "layer");
        layers.entry(l).or_default().push(r.clone());
    }
    let mut seed_h = Sha3_256::new();
    Digest::update(&mut seed_h, format!("{}|{}", msg_id, cid).as_bytes());
    let seed_hex = hex::encode(seed_h.finalize());
    let mut acc = u128::from_str_radix(&seed_hex[..16], 16).unwrap_or(0);
    let mut hops: Vec<RouteHop> = Vec::with_capacity(3);
    for layer in 0_i64..3 {
        let bucket = layers.get(&layer).filter(|v| !v.is_empty()).unwrap_or(&all_relays);
        if bucket.is_empty() { continue; }
        let idx = (acc as usize) % bucket.len();
        let relay = &bucket[idx];
        let node_id = relay.get_str("node_id").unwrap_or("relay-?").to_string();
        let label = relay.get_str("label").unwrap_or("Relay").to_string();
        let region = relay.get_str("region").unwrap_or("EU-DC").to_string();
        let latency = get_i64_lenient(relay, "latency_ms");
        let mut acc_h = Sha3_256::new();
        Digest::update(&mut acc_h, &acc.to_be_bytes()[8..]);
        Digest::update(&mut acc_h, node_id.as_bytes());
        let next_hex = hex::encode(acc_h.finalize());
        acc = u128::from_str_radix(&next_hex[..16], 16).unwrap_or(0);
        let mut hop_h = Sha3_256::new();
        Digest::update(&mut hop_h, format!("LATTICE-LOOPIX-v1|{}|{}|layer={}|{}", from_lns, to_lns, layer, node_id).as_bytes());
        let onion_layer_hash = hex::encode(hop_h.finalize());
        let delay = latency + 15 * (layer + 1);
        hops.push(RouteHop { layer: layer as i32, relay_node_id: node_id, relay_label: label,
            relay_region: region, onion_layer_hash, delay_ms: delay });
    }
    let mut ri = Sha3_256::new();
    for h in &hops {
        if let Ok(b) = hex::decode(&h.onion_layer_hash) { Digest::update(&mut ri, &b); }
    }
    let route_id = format!("route-{}", &hex::encode(ri.finalize())[..24]);

    // -- On-chain anchor every N messages --
    let mut anchor_tx_id: Option<String> = None;
    let mut anchor_block_index: Option<i64> = None;
    if message_number % PULSE_ANCHOR_EVERY == 0 {
        let trunc_ct = if ciphertext_hex.len() > 128 { &ciphertext_hex[..128] } else { ciphertext_hex.as_str() };
        let payload = format!("{}|{}|{}|{}", cid, message_number, trunc_ct, ts);
        let mut ah = Sha3_512::new();
        Digest::update(&mut ah, payload.as_bytes());
        let anchor_hash = hex::encode(ah.finalize());

        let _guard = chain::BLOCK_LOCK.lock().await;
        let block_idx = chain::peek_next_block_index(&state.db).await
            .map_err(|e| err(StatusCode::INTERNAL_SERVER_ERROR, format!("peek: {e}")))?;
        let _ = state.db.collection::<Document>("meta").update_one(
            doc! {"_id": "seeded"},
            doc! {"$inc": {"block_height": 1_i64, "tx_total": 1_i64, "qbft_round": 1_i64}},
        ).upsert(true).await;
        let tx_id = format!("tx-{}", det_hex(&format!("pulse-anchor-{}-{}", cid, message_number), 12));
        let summary = format!("PULSE_ANCHOR · {} · msgs={}", cid, message_number);
        let tx_msg = chain::tx_canonical_message(&tx_id, block_idx, &ts, "NotarySeal", &summary);
        let (sig_hex, sig_fp, actual_signer) = pqc_sign_or_delegate(
            &state.db, &from_lns, &tx_msg, s_tenant.as_deref(), "PULSE-GATEWAY",
        ).await.map_err(|e| err(StatusCode::INTERNAL_SERVER_ERROR, format!("pqc_sign_or_delegate: {e}")))?;
        let finalised = chain::finalise_block_for_tx_locked(
            &state.db, &state.http, &tx_id, "NotarySeal", &anchor_hash, &actual_signer, &ts,
        ).await
        .map_err(|e| err(StatusCode::SERVICE_UNAVAILABLE, format!("qbft: {e}")))?;
        if finalised.index != block_idx {
            return Err(err(StatusCode::INTERNAL_SERVER_ERROR,
                format!("block drift: signed={} alloc={}", block_idx, finalised.index)));
        }

        let extrinsics_root = det_hex(&format!("xroot-{}", tx_id), 64);
        let state_root = det_hex(&format!("sroot-{}", block_idx), 64);
        let _ = state.db.collection::<Document>("transactions").insert_one(doc! {
            "tx_id": &tx_id,
            "block_index": block_idx,
            "timestamp": &ts,
            "kind": "NotarySeal",
            "summary": &summary,
            "sender_public_key": &sig_fp,
            "signature": &sig_hex,
            "signed_with": "ML-DSA-65",
            "signer_entity": &actual_signer,
            "delegated_for": if actual_signer != from_lns { bson::Bson::String(from_lns.clone()) } else { bson::Bson::Null },
            "nonce": message_number,
            "weight": 8_000_i64,
            "doc_hash": &anchor_hash,
            "state_root": &state_root,
            "extrinsics_root": &extrinsics_root,
        }).await;
        let _ = state.db.collection::<Document>("pulse_messages").update_one(
            doc! {"msg_id": &msg_id},
            doc! {"$set": {"anchor_tx_id": &tx_id}},
        ).await;
        let _ = state.db.collection::<Document>("pulse_conversations").update_one(
            doc! {"conv_id": &cid},
            doc! {"$set": {"last_anchor_tx": &tx_id, "last_anchor_block": block_idx}},
        ).await;
        anchor_tx_id = Some(tx_id);
        anchor_block_index = Some(block_idx);
    }

    let response = PulseSendResponse {
        ok: true, msg_id, conv_id: cid, ciphertext_hex, nonce_hex, sealed_at: ts,
        anchor_tx_id, anchor_block_index, session_fingerprint: session_fp,
        epoch: epoch_count, message_number, route_id, route_hops: hops,
        rln_slot_used: used, rln_slot_max: RLN_MAX_PER_EPOCH,
    };

    if let (Some(client_id), Some(fingerprint)) =
        (req.client_msg_id.as_deref(), request_fingerprint.as_deref())
    {
        let committed = pulse_commit_operation(
            &state.db,
            tenant,
            &from_lns,
            client_id,
            fingerprint,
            &response.msg_id,
            &response,
        )
        .await
        .map_err(|e| err(
            StatusCode::SERVICE_UNAVAILABLE,
            format!("operation commit failed: {e}")
        ))?;

        if !committed {
            return Err(err(
                StatusCode::SERVICE_UNAVAILABLE,
                "operation commit not acknowledged"
            ));
        }
    }

    Ok(Json(response))
}

// -- GET /api/pulse/session/{conv_id} ---------------------------------------

#[derive(Debug, Serialize)]
pub struct PulseSessionDoc {
    pub conv_id: String,
    pub participants: Vec<String>,
    pub fingerprint: String,
    pub epoch: i64,
    pub message_number: i64,
    pub root_key_fingerprint: String,
    pub started_at: String,
    pub cipher_suite: String,
}

// ULTRON_V72_SESSION_TENANT
pub(crate) async fn authorize_pulse_participants(
    state: &AppState,
    caller: &str,
    tenant: &str,
    participants: &[String],
) -> Result<(), (StatusCode, Json<PulseError>)> {
    let caller = caller.trim().to_lowercase();

    let names: Vec<String> = participants
        .iter()
        .map(|p| p.trim().to_lowercase())
        .collect();

    if names.len() != 2
        || names[0].is_empty()
        || names[1].is_empty()
        || names[0] == names[1]
        || !names.iter().any(|p| p == &caller)
    {
        return Err(err(StatusCode::FORBIDDEN, "conversation access denied"));
    }

    let identities = state.db.collection::<Document>("lns");

    for participant in participants {
        let name = participant.trim().to_lowercase();

        let identity = identities
            .find_one(doc! {"lns_name": &name})
            .await
            .map_err(|e| err(StatusCode::INTERNAL_SERVER_ERROR, format!("db: {e}")))?
            .ok_or_else(|| err(StatusCode::FORBIDDEN, "conversation access denied"))?;

        if identity.get_str("status").unwrap_or("") != "ACTIVE"
            || identity.get_str("tenant_id").unwrap_or("") != tenant
        {
            return Err(err(StatusCode::FORBIDDEN, "conversation access denied"));
        }
    }

    Ok(())
}

pub async fn pulse_session(
    State(state): State<AppState>,
    Path(cid): Path<String>,
    headers: axum::http::HeaderMap,
) -> Result<Json<PulseSessionDoc>, (StatusCode, Json<PulseError>)> {
    let claims = crate::misc::jwt_decode(&headers)
        .ok_or_else(|| err(StatusCode::UNAUTHORIZED, "JWT required"))?;

    let caller = claims.sub.as_deref().unwrap_or("").trim().to_lowercase();
    let tenant = claims.tenant_id.as_deref().unwrap_or("").trim();

    if caller.is_empty() || tenant.is_empty() {
        return Err(err(StatusCode::FORBIDDEN, "identity or tenant missing"));
    }

    if let Ok(Some(doc)) = state.db.collection::<Document>("pulse_sessions")
        .find_one(doc! {"conv_id": &cid}).await
    {
        let allowed = doc.get_array("participants")
            .map(|a| a.iter().any(|v|
                v.as_str().map(|p| p.to_lowercase() == caller).unwrap_or(false)
            ))
            .unwrap_or(false);

        if !allowed {
            return Err(err(StatusCode::FORBIDDEN, "not a conversation participant"));
        }

        let participants: Vec<String> = doc.get_array("participants")
            .map(|a| a.iter().filter_map(|v|
                v.as_str().map(String::from)
            ).collect())
            .unwrap_or_default();

        authorize_pulse_participants(
            &state, &caller, tenant, &participants
        ).await?;

        return Ok(Json(PulseSessionDoc {
            conv_id: cid.clone(),
            participants: doc.get_array("participants").map(|a|
                a.iter().filter_map(|b| b.as_str().map(String::from)).collect()).unwrap_or_default(),
            fingerprint: doc.get_str("fingerprint").unwrap_or("").to_string(),
            epoch: get_i64_lenient(&doc, "epoch"),
            message_number: get_i64_lenient(&doc, "message_number"),
            root_key_fingerprint: doc.get_str("root_key_fingerprint").unwrap_or("").to_string(),
            started_at: doc.get_str("started_at").unwrap_or("").to_string(),
            cipher_suite: doc.get_str("cipher_suite").unwrap_or(
                "PQXDH(ML-KEM-768) + Double-Ratchet · AEAD: AES-256-GCM").to_string(),
        }));
    }
    let conv = state.db.collection::<Document>("pulse_conversations")
        .find_one(doc! {"conv_id": &cid}).await
        .map_err(|e| err(StatusCode::INTERNAL_SERVER_ERROR, format!("db: {e}")))?
        .ok_or_else(|| err(StatusCode::NOT_FOUND, format!("No active Pulse session for {}", cid)))?;
    let participants: Vec<String> = conv.get_array("participants").map(|a|
        a.iter().filter_map(|b| b.as_str().map(String::from)).collect()).unwrap_or_default();
    if !participants.iter().any(|p| p.to_lowercase() == caller) {
        return Err(err(StatusCode::FORBIDDEN, "not a conversation participant"));
    }

    authorize_pulse_participants(
        &state, &caller, tenant, &participants
    ).await?;

    let mc = get_i64_lenient(&conv, "message_count");
    let epoch_count = (mc.saturating_sub(1) / PULSE_ANCHOR_EVERY) + 1;
    let mut h = Sha3_256::new();
    Digest::update(&mut h, format!("root|{}|epoch={}", cid, epoch_count).as_bytes());
    let root_fp: String = hex::encode(h.finalize())[..32].to_uppercase();
    let started = conv.get_str("started_at").or_else(|_| conv.get_str("last_message_at"))
        .map(String::from).unwrap_or_else(|_| utc_iso());
    let session = PulseSessionDoc {
        conv_id: cid.clone(),
        participants: participants.clone(),
        fingerprint: pulse_session_fingerprint(&cid, &participants),
        epoch: epoch_count,
        message_number: mc,
        root_key_fingerprint: root_fp.clone(),
        started_at: started.clone(),
        cipher_suite: "PQXDH(ML-KEM-768) + Double-Ratchet · AEAD: AES-256-GCM".to_string(),
    };
    let _ = state.db.collection::<Document>("pulse_sessions").update_one(
        doc! {"conv_id": &cid},
        doc! {"$set": {
            "conv_id": &cid,
            "participants": bson::Bson::Array(participants.iter().map(|s| bson::Bson::String(s.clone())).collect()),
            "fingerprint": &session.fingerprint,
            "epoch": epoch_count,
            "message_number": mc,
            "root_key_fingerprint": &root_fp,
            "started_at": &started,
            "cipher_suite": &session.cipher_suite,
        }},
    ).upsert(true).await;
    Ok(Json(session))
}


// ULTRON_V72_A224_RESPONSE_ROUNDTRIP_TEST
#[cfg(test)]
mod pulse_response_roundtrip_tests {
    use super::{PulseSendResponse, RouteHop};

    #[test]
    fn response_survives_json_roundtrip() {
        let response = PulseSendResponse {
            ok: true,
            msg_id: "pulse-test-001".to_string(),
            conv_id: "conv-test-001".to_string(),
            ciphertext_hex: "aabbcc".to_string(),
            nonce_hex: "001122".to_string(),
            sealed_at: "2026-11-11T00:00:00Z".to_string(),
            anchor_tx_id: Some("tx-test-001".to_string()),
            anchor_block_index: Some(3),
            session_fingerprint: "TEST:FP".to_string(),
            epoch: 42,
            message_number: 3,
            route_id: "route-test".to_string(),
            route_hops: vec![RouteHop {
                layer: 0,
                relay_node_id: "relay-test".to_string(),
                relay_label: "Test Relay".to_string(),
                relay_region: "TEST".to_string(),
                onion_layer_hash: "abcdef".to_string(),
                delay_ms: 25,
            }],
            rln_slot_used: 1,
            rln_slot_max: 10,
        };

        let serialized =
            serde_json::to_value(&response).expect("serialize");

        let restored: PulseSendResponse =
            serde_json::from_value(serialized.clone())
                .expect("deserialize");

        let serialized_again =
            serde_json::to_value(&restored)
                .expect("serialize restored");

        assert_eq!(serialized, serialized_again);
        assert_eq!(restored.msg_id, "pulse-test-001");
        assert_eq!(restored.route_hops.len(), 1);
        assert_eq!(restored.anchor_block_index, Some(3));
    }
}


// ULTRON_V72_A224_ATOMIC_OPERATION_COMMIT
async fn pulse_commit_operation(
    db: &mongodb::Database,
    tenant: &str,
    from_lns: &str,
    client_msg_id: &str,
    request_fingerprint: &str,
    msg_id: &str,
    response: &PulseSendResponse,
) -> Result<bool, String> {
    let response_json = serde_json::to_value(response)
        .map_err(|e| format!("response serialization: {e}"))?;

    let response_bson = bson::to_bson(&response_json)
        .map_err(|e| format!("response BSON conversion: {e}"))?;

    let collection =
        db.collection::<Document>("pulse_send_operations");

    let result = collection.update_one(
        doc! {
            "tenant_id": tenant,
            "from_lns": from_lns,
            "client_msg_id": client_msg_id,
            "request_fingerprint": request_fingerprint,
            "msg_id": msg_id,
            "state": "PENDING",
        },
        doc! {
            "$set": {
                "state": "COMMITTED",
                "response_json": response_bson,
                "updated_at": utc_iso(),
            }
        },
    )
    .await
    .map_err(|e| format!("operation commit: {e}"))?;

    Ok(result.matched_count == 1 && result.modified_count == 1)
}


// ULTRON_V72_A224_RUST_COMMIT_INTEGRATION
#[cfg(test)]
mod pulse_commit_mongo_integration_tests {
    use super::{
        pulse_claim_operation,
        pulse_commit_operation,
        PulseOperationClaim,
        PulseSendResponse,
        RouteHop,
    };
    use bson::doc;
    use mongodb::Client;

    #[tokio::test]
    #[ignore = "requires explicitly configured isolated MongoDB"]
    async fn commit_is_atomic_and_response_is_recoverable() {
        let uri = std::env::var("ULTRON_A224_TEST_MONGO_URI")
            .expect("isolated MongoDB URI required");

        let db_name = std::env::var("ULTRON_A224_TEST_DB")
            .expect("isolated database name required");

        assert_eq!(
            db_name,
            "ultron_v72_persistence_isolated",
            "refusing non-isolated database"
        );

        let client = Client::with_uri_str(&uri)
            .await
            .expect("MongoDB connection failed");

        let db = client.database(&db_name);

        let collection =
            db.collection::<bson::Document>("pulse_send_operations");

        let run_id = bson::oid::ObjectId::new().to_hex();
        let tenant = "__a224_rust_commit_test__";
        let sender = "__a224_rust_commit_sender__";
        let fingerprint = "synthetic-commit-fingerprint";
        let msg_id = format!("synthetic-{run_id}");

        let key = doc! {
            "tenant_id": tenant,
            "from_lns": sender,
            "client_msg_id": &run_id,
        };

        let response = PulseSendResponse {
            ok: true,
            msg_id: msg_id.clone(),
            conv_id: "synthetic-conversation".to_string(),
            ciphertext_hex: "aabbcc".to_string(),
            nonce_hex: "001122".to_string(),
            sealed_at: "2026-11-11T00:00:00Z".to_string(),
            anchor_tx_id: None,
            anchor_block_index: None,
            session_fingerprint: "SYNTHETIC".to_string(),
            epoch: 42,
            message_number: 1,
            route_id: "synthetic-route".to_string(),
            route_hops: vec![RouteHop {
                layer: 0,
                relay_node_id: "synthetic-relay".to_string(),
                relay_label: "Test Relay".to_string(),
                relay_region: "TEST".to_string(),
                onion_layer_hash: "abcdef".to_string(),
                delay_ms: 25,
            }],
            rln_slot_used: 1,
            rln_slot_max: 10,
        };

        let result: Result<(), String> = async {
            let claim = pulse_claim_operation(
                &db,
                tenant,
                sender,
                &run_id,
                fingerprint,
                &msg_id,
            )
            .await
            .map_err(|e| e.to_string())?;

            if claim != PulseOperationClaim::Acquired {
                return Err("initial claim not acquired".into());
            }

            let wrong_fingerprint = pulse_commit_operation(
                &db,
                tenant,
                sender,
                &run_id,
                "wrong-fingerprint",
                &msg_id,
                &response,
            )
            .await?;

            if wrong_fingerprint {
                return Err("wrong fingerprint accepted".into());
            }

            let wrong_msg_id = pulse_commit_operation(
                &db,
                tenant,
                sender,
                &run_id,
                fingerprint,
                "wrong-message-id",
                &response,
            )
            .await?;

            if wrong_msg_id {
                return Err("wrong message ID accepted".into());
            }

            let first = pulse_commit_operation(
                &db,
                tenant,
                sender,
                &run_id,
                fingerprint,
                &msg_id,
                &response,
            )
            .await?;

            if !first {
                return Err("first commit failed".into());
            }

            let second = pulse_commit_operation(
                &db,
                tenant,
                sender,
                &run_id,
                fingerprint,
                &msg_id,
                &response,
            )
            .await?;

            if second {
                return Err("duplicate commit accepted".into());
            }

            let stored = collection
                .find_one(key.clone())
                .await
                .map_err(|e| e.to_string())?
                .ok_or("committed operation missing")?;

            if stored.get_str("state").ok() != Some("COMMITTED") {
                return Err("final state is not COMMITTED".into());
            }

            let response_bson = stored
                .get("response_json")
                .ok_or("stored response missing")?;

            let response_json: serde_json::Value =
                bson::from_bson(response_bson.clone())
                    .map_err(|e| e.to_string())?;

            let restored: PulseSendResponse =
                serde_json::from_value(response_json)
                    .map_err(|e| e.to_string())?;

            if restored.msg_id != msg_id {
                return Err("restored message ID mismatch".into());
            }

            if restored.route_hops.len() != 1 {
                return Err("restored route mismatch".into());
            }

            if restored.epoch != 42 {
                return Err("restored epoch mismatch".into());
            }

            Ok(())
        }
        .await;

        let cleanup = collection.delete_one(key).await;

        assert!(
            cleanup.is_ok(),
            "cleanup failed: {:?}",
            cleanup.err()
        );

        assert_eq!(
            cleanup.unwrap().deleted_count,
            1,
            "unexpected cleanup count"
        );

        result.expect("MongoDB commit integration test failed");
    }
}


// ULTRON_V72_A224_OPERATION_RECOVERY
#[derive(Debug)]
enum PulseOperationRecovery {
    Committed(PulseSendResponse),
    Pending,
    Conflict,
    Missing,
    Invalid,
}

async fn pulse_load_operation(
    db: &mongodb::Database,
    tenant: &str,
    from_lns: &str,
    client_msg_id: &str,
    request_fingerprint: &str,
) -> Result<PulseOperationRecovery, mongodb::error::Error> {
    let collection =
        db.collection::<Document>("pulse_send_operations");

    let stored = collection.find_one(doc! {
        "tenant_id": tenant,
        "from_lns": from_lns,
        "client_msg_id": client_msg_id,
    }).await?;

    let Some(operation) = stored else {
        return Ok(PulseOperationRecovery::Missing);
    };

    let Ok(saved_fingerprint) =
        operation.get_str("request_fingerprint")
    else {
        return Ok(PulseOperationRecovery::Invalid);
    };

    if saved_fingerprint != request_fingerprint {
        return Ok(PulseOperationRecovery::Conflict);
    }

    let Ok(state) = operation.get_str("state") else {
        return Ok(PulseOperationRecovery::Invalid);
    };

    match state {
        "PENDING" => Ok(PulseOperationRecovery::Pending),

        "COMMITTED" => {
            let Some(saved_response) =
                operation.get("response_json")
            else {
                return Ok(PulseOperationRecovery::Invalid);
            };

            let response_json: serde_json::Value =
                match bson::from_bson(saved_response.clone()) {
                    Ok(value) => value,
                    Err(_) => {
                        return Ok(PulseOperationRecovery::Invalid);
                    }
                };

            let response: PulseSendResponse =
                match serde_json::from_value(response_json) {
                    Ok(value) => value,
                    Err(_) => {
                        return Ok(PulseOperationRecovery::Invalid);
                    }
                };

            if !response.ok
                || operation.get_str("msg_id").ok()
                    != Some(response.msg_id.as_str())
            {
                return Ok(PulseOperationRecovery::Invalid);
            }

            Ok(PulseOperationRecovery::Committed(response))
        }

        _ => Ok(PulseOperationRecovery::Invalid),
    }
}


// ULTRON_V72_A224_RECOVERY_MONGO_TEST
#[cfg(test)]
mod pulse_recovery_mongo_integration_tests {
    use super::{
        pulse_claim_operation,
        pulse_commit_operation,
        pulse_load_operation,
        PulseOperationClaim,
        PulseOperationRecovery,
        PulseSendResponse,
    };
    use bson::{doc, Document};
    use mongodb::Client;

    #[tokio::test]
    #[ignore = "requires explicitly configured isolated MongoDB"]
    async fn recovery_handles_all_operation_states() {
        let uri = std::env::var("ULTRON_A224_TEST_MONGO_URI")
            .expect("isolated MongoDB URI required");

        let db_name = std::env::var("ULTRON_A224_TEST_DB")
            .expect("isolated database name required");

        assert_eq!(
            db_name,
            "ultron_v72_persistence_isolated",
            "refusing non-isolated database"
        );

        let client = Client::with_uri_str(&uri)
            .await
            .expect("MongoDB connection failed");

        let db = client.database(&db_name);
        let collection =
            db.collection::<Document>("pulse_send_operations");

        let run_id = bson::oid::ObjectId::new().to_hex();
        let tenant = "__a224_recovery_test__";
        let sender = "__a224_recovery_sender__";
        let fingerprint = "synthetic-recovery-fingerprint";
        let msg_id = format!("synthetic-{run_id}");

        let key = doc! {
            "tenant_id": tenant,
            "from_lns": sender,
            "client_msg_id": &run_id,
        };

        let result: Result<(), String> = async {
            let missing = pulse_load_operation(
                &db, tenant, sender, &run_id, fingerprint,
            )
            .await
            .map_err(|e| e.to_string())?;

            if !matches!(missing, PulseOperationRecovery::Missing) {
                return Err("missing state not detected".into());
            }

            let claim = pulse_claim_operation(
                &db, tenant, sender, &run_id,
                fingerprint, &msg_id,
            )
            .await
            .map_err(|e| e.to_string())?;

            if claim != PulseOperationClaim::Acquired {
                return Err("initial claim failed".into());
            }

            let pending = pulse_load_operation(
                &db, tenant, sender, &run_id, fingerprint,
            )
            .await
            .map_err(|e| e.to_string())?;

            if !matches!(pending, PulseOperationRecovery::Pending) {
                return Err("pending state not detected".into());
            }

            let conflict = pulse_load_operation(
                &db, tenant, sender, &run_id,
                "different-fingerprint",
            )
            .await
            .map_err(|e| e.to_string())?;

            if !matches!(conflict, PulseOperationRecovery::Conflict) {
                return Err("fingerprint conflict not detected".into());
            }

            let response = PulseSendResponse {
                ok: true,
                msg_id: msg_id.clone(),
                conv_id: "synthetic-conversation".into(),
                ciphertext_hex: "aabbcc".into(),
                nonce_hex: "001122".into(),
                sealed_at: "2026-11-11T00:00:00Z".into(),
                anchor_tx_id: None,
                anchor_block_index: None,
                session_fingerprint: "SYNTHETIC".into(),
                epoch: 42,
                message_number: 1,
                route_id: "synthetic-route".into(),
                route_hops: vec![],
                rln_slot_used: 1,
                rln_slot_max: 10,
            };

            let committed = pulse_commit_operation(
                &db, tenant, sender, &run_id,
                fingerprint, &msg_id, &response,
            )
            .await?;

            if !committed {
                return Err("commit failed".into());
            }

            let recovered = pulse_load_operation(
                &db, tenant, sender, &run_id, fingerprint,
            )
            .await
            .map_err(|e| e.to_string())?;

            match recovered {
                PulseOperationRecovery::Committed(saved) => {
                    let original = serde_json::to_value(&response)
                        .map_err(|e| e.to_string())?;
                    let restored = serde_json::to_value(&saved)
                        .map_err(|e| e.to_string())?;

                    if original != restored {
                        return Err("recovered response differs".into());
                    }
                }
                _ => return Err("committed response not recovered".into()),
            }

            let conflict_after_commit = pulse_load_operation(
                &db, tenant, sender, &run_id,
                "different-fingerprint",
            )
            .await
            .map_err(|e| e.to_string())?;

            if !matches!(
                conflict_after_commit,
                PulseOperationRecovery::Conflict
            ) {
                return Err("committed fingerprint conflict missed".into());
            }

            collection.update_one(
                key.clone(),
                doc! {"$set": {"response_json": "invalid-response"}},
            )
            .await
            .map_err(|e| e.to_string())?;

            let invalid = pulse_load_operation(
                &db, tenant, sender, &run_id, fingerprint,
            )
            .await
            .map_err(|e| e.to_string())?;

            if !matches!(invalid, PulseOperationRecovery::Invalid) {
                return Err("invalid response not detected".into());
            }

            collection.update_one(
                key.clone(),
                doc! {"$set": {"state": "UNKNOWN"}},
            )
            .await
            .map_err(|e| e.to_string())?;

            let unknown = pulse_load_operation(
                &db, tenant, sender, &run_id, fingerprint,
            )
            .await
            .map_err(|e| e.to_string())?;

            if !matches!(unknown, PulseOperationRecovery::Invalid) {
                return Err("unknown state not detected".into());
            }

            Ok(())
        }
        .await;

        let cleanup = collection.delete_one(key).await
            .expect("cleanup failed");

        assert!(
            cleanup.deleted_count <= 1,
            "unexpected cleanup count"
        );

        result.expect("recovery integration test failed");

        assert_eq!(
            cleanup.deleted_count,
            1,
            "temporary document was not cleaned"
        );
    }
}
