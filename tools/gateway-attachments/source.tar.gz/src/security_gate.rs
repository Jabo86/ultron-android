//! Fail-closed revocation gate for every request carrying a Bearer JWT.
//! Requests without Bearer are handled by endpoint-specific authorization;
//! this middleware does not make anonymous endpoints safe by itself.
use axum::{extract::{State, Request}, http::{header::AUTHORIZATION, StatusCode}, middleware::Next, response::{IntoResponse, Response}};
use bson::{doc, Document};
use crate::{AppState, misc::jwt_decode};

fn allowed_after_global_revoke(iat: i64, cutoff: i64) -> bool { iat > cutoff }

#[cfg(test)]
mod tests {
    use super::allowed_after_global_revoke;
    #[test]
    fn global_revocation_rejects_older_and_equal_tokens() {
        assert!(!allowed_after_global_revoke(100, 100));
        assert!(!allowed_after_global_revoke(99, 100));
        assert!(allowed_after_global_revoke(101, 100));
    }
}

pub async fn reject_revoked_bearer(State(state): State<AppState>, request: Request, next: Next) -> Response {
    let header = request.headers().get(AUTHORIZATION).and_then(|h| h.to_str().ok());
    if let Some(value) = header {
        if !value.starts_with("Bearer ") { return StatusCode::UNAUTHORIZED.into_response(); }
        let Some(claims) = jwt_decode(request.headers()) else { return StatusCode::UNAUTHORIZED.into_response(); };
        let (Some(jti), Some(sub), Some(iat)) = (claims.jti, claims.sub, claims.iat) else {
            return StatusCode::UNAUTHORIZED.into_response();
        };
        if jti.is_empty() || sub.is_empty() { return StatusCode::UNAUTHORIZED.into_response(); }
        match state.db.collection::<Document>("lns").find_one(doc! {
            "lns_name": &sub, "status": {"$in": ["DELETING", "DELETED"]},
        }).projection(doc! {"_id": 1}).await {
            Ok(Some(_)) => return StatusCode::UNAUTHORIZED.into_response(),
            Err(_) => return StatusCode::SERVICE_UNAVAILABLE.into_response(),
            Ok(None) => {}
        }
        let coll = state.db.collection::<Document>("revoked_jwts");
        match coll.find_one(doc! {"jti": &jti}).await {
            Ok(Some(_)) => return StatusCode::UNAUTHORIZED.into_response(),
            Err(_) => return StatusCode::SERVICE_UNAVAILABLE.into_response(),
            Ok(None) => {}
        }
        match coll.find_one(doc! {"_id": format!("nuke:{sub}")}).await {
            Ok(Some(marker)) => {
                let cutoff = marker.get_i64("nuked_iat")
                    .or_else(|_| marker.get_i32("nuked_iat").map(i64::from));
                // A malformed marker must not silently allow authentication.
                match cutoff {
                    Ok(ts) if allowed_after_global_revoke(iat, ts) => {},
                    _ => return StatusCode::UNAUTHORIZED.into_response(),
                }
            },
            Err(_) => return StatusCode::SERVICE_UNAVAILABLE.into_response(),
            Ok(None) => {}
        }
    }
    next.run(request).await
}


// ULTRON PHASE 01 - Centralized privileged route guard.
pub async fn ultron_phase01_admin_guard(
    request: axum::extract::Request,
    next: axum::middleware::Next,
) -> axum::response::Response {
    use axum::response::IntoResponse;

    let path = request.uri().path();

    let protected =
        path.starts_with("/api/admin/")
        || path.starts_with("/api/vendor/")
        || path == "/api/logs/stream"
        || path == "/api/audit/stream"
        || path == "/api/mixnet/topology"
        || path == "/api/mixnet/route"
        || path == "/api/qbft/alerts";

    let pulse_protected =
        path == "/api/pulse/send"
        || path.starts_with("/api/pulse/session/");

    if pulse_protected
        && crate::misc::jwt_decode(request.headers()).is_none()
    {
        return StatusCode::UNAUTHORIZED.into_response();
    }

    if protected {
        let Some(claims) = crate::misc::jwt_decode(request.headers()) else {
            return axum::http::StatusCode::UNAUTHORIZED.into_response();
        };

        if claims.role.as_deref() != Some("sovereign") {
            return axum::http::StatusCode::FORBIDDEN.into_response();
        }
    }

    next.run(request).await
}
