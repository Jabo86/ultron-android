//! Mobile compatibility endpoints for direct, mutually approved conversations.
use axum::{
    extract::{Path, Query, State},
    http::{header::CACHE_CONTROL, HeaderMap, HeaderName, StatusCode},
    Json,
};
use bson::{doc, oid::ObjectId, Bson, Document};
use futures::TryStreamExt;
use serde::Deserialize;
use serde_json::{json, Map, Value};
use sha2::{Digest, Sha256};

use crate::{wake, AppState};

pub mod status;
pub mod calls;
pub mod blobs;
pub mod reset;
pub mod signed_keys;
pub mod prekeys;
mod ratchet_wire;
pub mod contact_requests;
pub mod purge;
pub mod groups;
pub mod group_invites;
pub mod group_control;
pub mod group_files;

static MESSAGE_EVENTS: std::sync::LazyLock<tokio::sync::broadcast::Sender<String>> =
    std::sync::LazyLock::new(|| tokio::sync::broadcast::channel(256).0);
static EVENT_SLOTS: tokio::sync::Semaphore = tokio::sync::Semaphore::const_new(256);

const MESSAGES: &str = "ultron_mobile_messages";
const CONTACTS: &str = "ultron_mobile_contacts";
const KEYS: &str = "ultron_mobile_keys";
const EXPORT_MESSAGES: i64 = 100;

pub async fn ensure_indexes(db: &mongodb::Database) -> mongodb::error::Result<()> {
    use mongodb::IndexModel;
    let messages = db.collection::<Document>(MESSAGES);
    for keys in [doc! {"participants": 1, "_id": -1},
        doc! {"participants": 1, "conv_id": 1, "_id": -1},
        doc! {"to_lns": 1, "delivered": 1, "silent": 1},
        doc! {"to_lns": 1, "read": 1, "silent": 1}] {
        messages.create_index(IndexModel::builder().keys(keys).build()).await?;
    }
    messages.create_index(IndexModel::builder()
        .keys(doc! {"from_lns": 1, "ratchet_send_id": 1})
        .options(mongodb::options::IndexOptions::builder()
            .unique(true).partial_filter_expression(doc! {"ratchet_send_id": {"$exists": true}}).build())
        .build()).await?;
    let contacts = db.collection::<Document>(CONTACTS);
    for keys in [doc! {"owner": 1, "added": 1}, doc! {"peer": 1, "added": 1}] {
        contacts.create_index(IndexModel::builder().keys(keys).build()).await?;
    }
    contact_requests::ensure_indexes(db).await?;
    if purge::enabled() { purge::ensure_indexes(db).await?; }
    if groups::enabled() { groups::ensure_indexes(db).await?; }
    if group_invites::enabled() { group_invites::ensure_indexes(db).await?; }
    if group_control::enabled() { group_control::indexes(db).await?; group_files::indexes(db).await?; }
    Ok(())
}

type Reply = ([(HeaderName, &'static str); 1], Json<Value>);
type Error = (StatusCode, Json<Value>);
type Result<T = Reply> = std::result::Result<T, Error>;

fn reply(data: Value) -> Reply {
    ([(CACHE_CONTROL, "no-store")], Json(data))
}
fn error(status: StatusCode, detail: &str) -> Error {
    (status, Json(json!({"detail": detail})))
}
fn bad(detail: &str) -> Error {
    error(StatusCode::BAD_REQUEST, detail)
}
fn storage(_: mongodb::error::Error) -> Error {
    error(StatusCode::SERVICE_UNAVAILABLE, "Archivio ULTRON temporaneamente non disponibile.")
}
async fn authenticated(state: &AppState, headers: &HeaderMap) -> Result<String> {
    let (owner, issued_at) = wake::identity(headers)?;
    wake::require_active(state, &owner).await?;
    wake::check_revocation(state, &owner, issued_at).await?;
    Ok(owner)
}
fn address(name: &str) -> Result<String> {
    let name = name.trim().to_ascii_lowercase();
    let (local, domain) = name.split_once('@').ok_or_else(|| bad("Indirizzo non valido."))?;
    let valid = |part: &str| !part.is_empty() && part.bytes()
        .all(|b| b.is_ascii_alphanumeric() || matches!(b, b'.' | b'_' | b'-'));
    if name.len() > 254 || !valid(local) || !valid(domain)
        || !(domain.ends_with(".uns") || domain.ends_with(".lns"))
    {
        return Err(bad("Indirizzo non valido."));
    }
    Ok(name)
}
fn pair_id(left: &str, right: &str) -> String {
    let mut names = [left, right];
    names.sort_unstable();
    hex::encode(Sha256::digest(format!("ultron-mobile-chat-v1\0{}\0{}", names[0], names[1])))
}
fn edge_id(owner: &str, peer: &str) -> String {
    format!("{owner}\n{peer}")
}
fn hex_len(value: &str, length: usize) -> bool {
    value.len() == length && value.bytes().all(|b| b.is_ascii_hexdigit())
}
fn string(row: &Document, field: &str) -> String {
    row.get_str(field).unwrap_or("").to_owned()
}

#[derive(Deserialize)]
pub struct ContactRequest {
    lns: String,
}
#[derive(Deserialize)]
pub struct BlockRequest {
    lns: String,
    on: bool,
}

async fn edge(state: &AppState, owner: &str, peer: &str) -> Result<Option<Document>> {
    state.db.collection::<Document>(CONTACTS).find_one(doc! {"_id": edge_id(owner, peer)})
        .await.map_err(storage)
}
fn added(edge: Option<&Document>) -> bool {
    edge.and_then(|row| row.get_bool("added").ok()) == Some(true)
}
fn blocked(edge: Option<&Document>) -> bool {
    edge.and_then(|row| row.get_bool("blocked").ok()) == Some(true)
}
async fn may_send(state: &AppState, owner: &str, peer: &str) -> Result<bool> {
    if owner == peer { return Ok(false); }
    let outbound = edge(state, owner, peer).await?;
    let inbound = edge(state, peer, owner).await?;
    if blocked(outbound.as_ref()) || blocked(inbound.as_ref()) { return Ok(false); }
    if contact_requests::enabled() {
        if let Some(row) = contact_requests::status(state, owner, peer).await? {
            return Ok(row.get_str("status").ok() == Some("accepted"));
        }
    }
    Ok(added(outbound.as_ref()) && added(inbound.as_ref()))
}

pub async fn add_contact(State(state): State<AppState>, headers: HeaderMap, Json(req): Json<ContactRequest>) -> Result {
    let owner = authenticated(&state, &headers).await?;
    let peer = address(&req.lns)?;
    if owner == peer { return Err(bad("Scegli un altro contatto.")); }
    if contact_requests::enabled() { return contact_requests::request(&state, &owner, &peer).await; }
    wake::require_active(&state, &peer).await?;
    state.db.collection::<Document>(CONTACTS).update_one(
        doc! {"_id": edge_id(&owner, &peer)},
        doc! {"$set": {"owner": &owner, "peer": &peer, "added": true}},
    ).upsert(true).await.map_err(storage)?;
    Ok(reply(json!({"ok": true, "lns": peer})))
}

pub async fn remove_contact(State(state): State<AppState>, headers: HeaderMap, Path(target): Path<String>) -> Result {
    let owner = authenticated(&state, &headers).await?;
    let peer = address(&target)?;
    if contact_requests::enabled() { contact_requests::close(&state, &owner, &peer).await?; }
    state.db.collection::<Document>(CONTACTS).update_one(
        doc! {"_id": edge_id(&owner, &peer)}, doc! {"$set": {"added": false}},
    ).await.map_err(storage)?;
    Ok(reply(json!({"ok": true})))
}

pub async fn block_contact(State(state): State<AppState>, headers: HeaderMap, Json(req): Json<BlockRequest>) -> Result {
    let owner = authenticated(&state, &headers).await?;
    let peer = address(&req.lns)?;
    if owner == peer { return Err(bad("Scegli un altro contatto.")); }
    wake::require_active(&state, &peer).await?;
    state.db.collection::<Document>(CONTACTS).update_one(
        doc! {"_id": edge_id(&owner, &peer)},
        doc! {"$set": {"owner": &owner, "peer": &peer, "blocked": req.on}},
    ).upsert(true).await.map_err(storage)?;
    if contact_requests::enabled() && req.on { contact_requests::close(&state, &owner, &peer).await?; }
    Ok(reply(json!({"ok": true})))
}

pub async fn blocks(State(state): State<AppState>, headers: HeaderMap) -> Result {
    let owner = authenticated(&state, &headers).await?;
    let rows: Vec<Document> = state.db.collection::<Document>(CONTACTS)
        .find(doc! {"owner": owner, "blocked": true}).projection(doc! {"peer": 1})
        .limit(2000).await.map_err(storage)?.try_collect().await.map_err(storage)?;
    Ok(reply(json!({"blocked": rows.iter().filter_map(|row| row.get_str("peer").ok()).collect::<Vec<_>>() })))
}

pub async fn contacts(State(state): State<AppState>, headers: HeaderMap) -> Result {
    let owner = authenticated(&state, &headers).await?;
    let edges = state.db.collection::<Document>(CONTACTS);
    let rows: Vec<Document> = edges.find(doc! {"$or": [
        {"owner": &owner, "added": true}, {"peer": &owner, "added": true}
    ]}).limit(2000).await.map_err(storage)?.try_collect().await.map_err(storage)?;
    let mut contacts = std::collections::BTreeMap::<String, (bool, bool, bool)>::new();
    for row in rows {
        let own = row.get_str("owner").ok() == Some(owner.as_str());
        let peer = string(&row, if own { "peer" } else { "owner" });
        if peer.is_empty() { continue; }
        let entry = contacts.entry(peer).or_default();
        if own { entry.0 = true; entry.2 = blocked(Some(&row)); } else { entry.1 = true; }
    }
    let mut requests = std::collections::BTreeMap::new();
    if contact_requests::enabled() {
        for row in contact_requests::list(&state, &owner).await? {
            let Some(peer) = row.get_array("members").ok().and_then(|members|
                members.iter().filter_map(Bson::as_str).find(|peer| *peer != owner.as_str())
            ).map(str::to_owned) else { continue; };
            let blocked = contacts.get(&peer).is_some_and(|entry| entry.2);
            match row.get_str("status").unwrap_or("") {
                "accepted" => { contacts.insert(peer, (true, true, blocked)); },
                "pending" => {
                    let outgoing = row.get_str("sender").ok() == Some(owner.as_str());
                    contacts.insert(peer.clone(), (outgoing, !outgoing, blocked));
                    requests.insert(peer, if outgoing { "outgoing" } else { "incoming" });
                }
                _ => { contacts.remove(&peer); }
            }
        }
    }
    Ok(reply(json!(contacts.into_iter().map(|(peer, (mine, theirs, blocked))| json!({
        "lns": peer, "display_name": peer.split('@').next().unwrap_or(""),
        "in_my_book": mine, "they_have_me": theirs, "mutual": mine && theirs && !blocked, "blocked": blocked,
        "contact_request": requests.get(&peer),
    })).collect::<Vec<_>>())))
}

#[derive(Deserialize)]
pub struct PublishRequest {
    kem_pk_hex: String,
    dh_pk_hex: String,
}
#[derive(Deserialize)]
pub struct KeyRequest {
    lns_list: Vec<String>,
}

pub async fn publish(State(state): State<AppState>, headers: HeaderMap, Json(req): Json<PublishRequest>) -> Result {
    let owner = authenticated(&state, &headers).await?;
    if !hex_len(&req.kem_pk_hex, 2368) || !hex_len(&req.dh_pk_hex, 64) {
        return Err(bad("Chiavi pubbliche non valide."));
    }
    let keys = state.db.collection::<Document>(KEYS);
    let filter = doc! {"_id": &owner, "signature": {"$exists": false}};
    let update = doc! {"$set": {"kem": req.kem_pk_hex.to_ascii_lowercase(), "dh": req.dh_pk_hex.to_ascii_lowercase()}};
    if let Err(err) = keys.update_one(filter, update).upsert(true).await {
        let duplicate = matches!(err.kind.as_ref(), mongodb::error::ErrorKind::Write(
            mongodb::error::WriteFailure::WriteError(write)
        ) if write.code == 11000);
        if !duplicate { return Err(storage(err)); }
        // Older applications can sign in, but cannot replace a signed publication.
        if keys.find_one(doc! {"_id": &owner, "signature": {"$exists": true}})
            .projection(doc! {"_id": 1}).await.map_err(storage)?.is_none()
        {
            return Err(storage(err));
        }
    }
    Ok(reply(json!({"ok": true})))
}

async fn key_lookup(state: &AppState, headers: &HeaderMap, req: KeyRequest, field: &str) -> Result {
    let owner = authenticated(state, headers).await?;
    if req.lns_list.len() > 32 { return Err(bad("Troppi contatti nella richiesta.")); }
    let strict = field == "kem" && req.lns_list.len() == 1;
    let mut keys = Map::new();
    let stored = state.db.collection::<Document>(KEYS);
    for input in req.lns_list {
        let peer = address(&input)?;
        if peer != owner && !may_send(state, &owner, &peer).await? {
            if strict {
                return Err(error(StatusCode::FORBIDDEN, "Per scrivervi, aggiungetevi entrambi ai contatti."));
            }
            continue;
        }
        if let Some(row) = stored.find_one(doc! {"_id": &peer}).await.map_err(storage)? {
            if let Ok(key) = row.get_str(field) {
                keys.insert(peer.clone(), json!(key));
            }
        }
        if strict && !keys.contains_key(&peer) {
            return Err(error(StatusCode::CONFLICT, "Il destinatario deve aprire ULTRON e accedere per pubblicare le chiavi."));
        }
    }
    Ok(reply(Value::Object(keys)))
}
pub async fn keys(State(state): State<AppState>, headers: HeaderMap, Json(req): Json<KeyRequest>) -> Result {
    key_lookup(&state, &headers, req, "kem").await
}
pub async fn dhkeys(State(state): State<AppState>, headers: HeaderMap, Json(req): Json<KeyRequest>) -> Result {
    key_lookup(&state, &headers, req, "dh").await
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Envelope {
    #[serde(rename = "for")]
    recipient: String,
    kem: String,
    iv: String,
    ct: String,
}

impl Envelope {
    fn validate(&self) -> Result<String> {
        if !hex_len(&self.kem, 2176) || !hex_len(&self.iv, 24)
            || !(32..=131_072).contains(&self.ct.len()) || self.ct.len() % 2 != 0
            || !hex_len(&self.ct, self.ct.len())
        {
            return Err(bad("Busta cifrata non valida."));
        }
        address(&self.recipient)
    }
    fn to_doc(&self, owner: String) -> Document {
        doc! {"for": owner, "kem": &self.kem, "iv": &self.iv, "ct": &self.ct}
    }
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct SendRequest {
    to_lns: Vec<String>,
    envelopes: Vec<Envelope>,
    #[serde(default)]
    silent: bool,
}

pub async fn send(State(state): State<AppState>, headers: HeaderMap, Json(req): Json<SendRequest>) -> Result {
    let owner = authenticated(&state, &headers).await?;
    if req.to_lns.len() != 1 || req.envelopes.len() != 2 {
        return Err(bad("Il gateway supporta due buste cifrate per chat individuale."));
    }
    let peer = address(&req.to_lns[0])?;
    wake::require_active(&state, &peer).await?;
    if !may_send(&state, &owner, &peer).await? {
        return Err(error(StatusCode::FORBIDDEN, "Invio non consentito. Verifica che vi siate aggiunti entrambi ai contatti."));
    }
    let mut own = None;
    let mut theirs = None;
    for envelope in &req.envelopes {
        let recipient = envelope.validate()?;
        let selected = if recipient == owner { &mut own } else if recipient == peer { &mut theirs }
            else { return Err(bad("Destinatario della busta non valido.")); };
        if selected.is_some() { return Err(bad("Busta duplicata.")); }
        *selected = Some(envelope.to_doc(recipient));
    }
    let (Some(own), Some(theirs)) = (own, theirs) else {
        return Err(bad("Manca una busta cifrata."));
    };
    let id = ObjectId::new();
    let conv_id = pair_id(&owner, &peer);
    let _guard = purge::WRITES.read().await;
    purge::require_generation(&state, &conv_id, 0).await?;
    state.db.collection::<Document>(MESSAGES).insert_one(doc! {
        "_id": id, "conv_id": &conv_id, "from_lns": &owner, "to_lns": &peer,
        "participants": [&owner, &peer], "from_envelope": own, "to_envelope": theirs,
        "sent_at": crate::utc_iso(), "delivered": false, "read": false, "silent": req.silent,
    }).await.map_err(storage)?;
    let _ = MESSAGE_EVENTS.send(conv_id.clone());
    Ok(reply(json!({"ok": true, "conv_id": conv_id, "message_id": id.to_hex()})))
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct RatchetSendRequest {
    to_lns: Vec<String>,
    envelope: ratchet_wire::RatchetEnvelope,
    send_id: String,
    #[serde(default)]
    generation: i64,
    #[serde(default)]
    attachment_ids: Vec<String>,
}

pub async fn send_ratchet(State(state): State<AppState>, headers: HeaderMap, Json(req): Json<RatchetSendRequest>) -> Result {
    if !std::env::var("ULTRON_EXPERIMENTAL_RATCHET").is_ok_and(|value| value == "1") {
        return Err(error(StatusCode::NOT_FOUND, "Trasporto ratchet non attivo."));
    }
    let owner = authenticated(&state, &headers).await?;
    if !hex_len(&req.send_id, 32) {
        return Err(bad("Identificativo di invio non valido."));
    }
    let peer = direct_recipient(&state, &owner, &req.to_lns).await?;
    if req.envelope.validate()? != peer {
        return Err(bad("Destinatario della busta non valido."));
    }
    let identity = signed_keys::identity_key(&state, &owner).await?;
    req.envelope.verify_initial_sender(&owner, &identity)?;
    let envelope = req.envelope.to_doc(peer.clone())?;
    let stored = state.db.collection::<Document>(MESSAGES);
    let selector = doc! {"from_lns": &owner, "ratchet_send_id": &req.send_id};
    let id = ObjectId::new();
    let conv_id = pair_id(&owner, &peer);
    let _guard = purge::WRITES.read().await;
    purge::require_generation(&state, &conv_id, req.generation).await?;
    if purge::enabled() { blobs::require_attachments(&state, &owner, &peer, req.generation, &req.attachment_ids).await?; }
    let update = doc! {"$setOnInsert": {
        "_id": id, "conv_id": &conv_id, "generation": req.generation, "to_lns": &peer, "participants": [&owner, &peer],
        "to_envelope": &envelope, "sent_at": crate::utc_iso(), "delivered": false, "read": false, "silent": false,
    }};
    if let Err(err) = stored.update_one(selector.clone(), update).upsert(true).await {
        let duplicate = matches!(err.kind.as_ref(), mongodb::error::ErrorKind::Write(
            mongodb::error::WriteFailure::WriteError(write)
        ) if write.code == 11000);
        if !duplicate { return Err(storage(err)); }
    }
    let row = stored.find_one(selector).await.map_err(storage)?
        .ok_or_else(|| error(StatusCode::SERVICE_UNAVAILABLE, "Messaggio non disponibile."))?;
    if row.get_str("to_lns").ok() != Some(peer.as_str())
        || row.get_document("to_envelope").ok() != Some(&envelope)
    {
        return Err(error(StatusCode::CONFLICT, "Identificativo di invio già usato."));
    }
    let id = row.get_object_id("_id")
        .map_err(|_| error(StatusCode::SERVICE_UNAVAILABLE, "Identificativo del messaggio non disponibile."))?;
    let _ = MESSAGE_EVENTS.send(conv_id.clone());
    Ok(reply(json!({"ok": true, "conv_id": conv_id, "message_id": id.to_hex()})))
}

async fn direct_recipient(state: &AppState, owner: &str, recipients: &[String]) -> Result<String> {
    if recipients.len() != 1 {
        return Err(bad("Scegli un destinatario per la chat individuale."));
    }
    let peer = address(&recipients[0])?;
    wake::require_active(state, &peer).await?;
    if !may_send(state, owner, &peer).await? {
        return Err(error(StatusCode::FORBIDDEN, "Invio non consentito. Verifica che vi siate aggiunti entrambi ai contatti."));
    }
    Ok(peer)
}

#[derive(Deserialize)]
pub struct History {
    conv_id: String,
    limit: Option<i64>,
    before: Option<String>,
}
#[derive(Deserialize)]
pub struct Conversation {
    conv_id: String,
}

fn message_view(row: &Document, owner: &str) -> Value {
    let mine = row.get_str("from_lns").ok() == Some(owner);
    let field = if mine { "from_envelope" } else { "to_envelope" };
    let envelope = row.get_document(field).ok().and_then(|e| {
        if e.contains_key("r") {
            return ratchet_wire::view(e);
        }
        Some(json!({
            "for": string(e, "for"), "kem": string(e, "kem"), "iv": string(e, "iv"), "ct": string(e, "ct"),
        }))
    });
    let mut response = json!({
        "message_id": row.get_object_id("_id").ok().map(|id| id.to_hex()),
        "conv_id": string(row,"conv_id"), "from_lns": string(row,"from_lns"), "to_lns": string(row,"to_lns"),
        "generation": row.get_i64("generation").unwrap_or(0),
        "mine": mine, "sent_at": string(row,"sent_at"), "envelope": envelope,
        "hidden": row.get_bool("hidden_for_all").unwrap_or(false)
            || row.get_array("hidden_for").is_ok_and(|users| users.iter().any(|user| user.as_str() == Some(owner))),
        "read": row.get_bool("read").unwrap_or(false), "delivered": row.get_bool("delivered").unwrap_or(false)
    });
    if let Ok(send_id) = row.get_str("ratchet_send_id") {
        response["ratchet"] = json!(true);
        if mine { response["send_id"] = json!(send_id); }
    }
    response
}

pub async fn messages(State(state): State<AppState>, headers: HeaderMap, Query(req): Query<History>) -> Result {
    let owner = authenticated(&state, &headers).await?;
    if !hex_len(&req.conv_id, 64) { return Err(bad("Conversazione non valida.")); }
    let _guard = purge::WRITES.read().await;
    let mut query = doc! {"participants": &owner, "conv_id": &req.conv_id};
    if let Some(cursor) = req.before {
        let before = ObjectId::parse_str(cursor).map_err(|_| bad("Cursore non valido."))?;
        query.insert("_id", doc! {"$lt": before});
    }
    let stored = state.db.collection::<Document>(MESSAGES);
    let mut rows: Vec<Document> = stored.find(query).sort(doc! {"_id": -1})
        .limit(req.limit.unwrap_or(40).clamp(1, 101)).await.map_err(storage)?
        .try_collect().await.map_err(storage)?;
    let delivered: Vec<ObjectId> = rows.iter()
        .filter(|row| row.get_str("to_lns").ok() == Some(owner.as_str()) && row.get_bool("delivered").ok() != Some(true))
        .filter_map(|row| row.get_object_id("_id").ok()).collect();
    if !delivered.is_empty() {
        stored.update_many(doc! {"to_lns": &owner, "_id": {"$in": delivered}, "delivered": false},
            doc! {"$set": {"delivered": true}}).await.map_err(storage)?;
    }
    rows.reverse();
    Ok(reply(json!(rows.iter().map(|row| message_view(row, &owner)).collect::<Vec<_>>())))
}

#[derive(Deserialize)]
pub struct MessageEvents {
    conv_id: String,
    after: String,
}

pub async fn message_events(State(state): State<AppState>, headers: HeaderMap, Query(req): Query<MessageEvents>) -> Result {
    let owner = authenticated(&state, &headers).await?;
    if !hex_len(&req.conv_id, 64) { return Err(bad("Conversazione non valida.")); }
    let after = ObjectId::parse_str(&req.after).map_err(|_| bad("Cursore non valido."))?;
    let _permit = EVENT_SLOTS.try_acquire()
        .map_err(|_| error(StatusCode::SERVICE_UNAVAILABLE, "Troppe connessioni aperte."))?;
    let mut events = MESSAGE_EVENTS.subscribe();
    let stored = state.db.collection::<Document>(MESSAGES);
    let mut filter = doc! {"participants": owner, "conv_id": &req.conv_id, "_id": after};
    if stored.find_one(filter.clone()).projection(doc! {"_id": 1}).await.map_err(storage)?.is_none() {
        return Err(error(StatusCode::NOT_FOUND, "Conversazione non disponibile."));
    }
    filter.insert("_id", doc! {"$gt": after});
    let wait = async {
        loop {
            if stored.find_one(filter.clone()).projection(doc! {"_id": 1}).await.map_err(storage)?.is_some() {
                return Ok::<_, Error>(true);
            }
            loop {
                match events.recv().await {
                    Ok(conv) if conv != req.conv_id => continue,
                    Ok(_) => return Ok::<_, Error>(true),
                    Err(_) => break,
                }
            }
        }
    };
    let changed = tokio::time::timeout(std::time::Duration::from_secs(15), wait).await.unwrap_or(Ok(false))?;
    Ok(reply(json!({"changed": changed})))
}

pub async fn read(State(state): State<AppState>, headers: HeaderMap, Json(req): Json<Conversation>) -> Result {
    let owner = authenticated(&state, &headers).await?;
    if !hex_len(&req.conv_id, 64) { return Err(bad("Conversazione non valida.")); }
    state.db.collection::<Document>(MESSAGES).update_many(
        doc! {"to_lns": owner, "conv_id": req.conv_id, "read": false},
        doc! {"$set": {"read": true, "delivered": true}},
    ).await.map_err(storage)?;
    Ok(reply(json!({"ok": true})))
}

#[derive(Deserialize)]
pub struct HideScope {
    scope: Option<String>,
}

pub async fn hide_message(
    State(state): State<AppState>,
    headers: HeaderMap,
    Path(message_id): Path<String>,
    Query(req): Query<HideScope>,
) -> Result {
    let owner = authenticated(&state, &headers).await?;
    let id = ObjectId::parse_str(message_id).map_err(|_| bad("Messaggio non valido."))?;
    let stored = state.db.collection::<Document>(MESSAGES);
    let mut filter = doc! {"_id": id, "participants": &owner};
    let update = match req.scope.as_deref().unwrap_or("me") {
        "me" => doc! {"$addToSet": {"hidden_for": &owner}},
        "all" => {
            filter.insert("from_lns", &owner);
            doc! {"$set": {"hidden_for_all": true}}
        }
        _ => return Err(bad("Destinatari della rimozione non validi.")),
    };
    let row = stored.find_one_and_update(filter, update)
        .projection(doc! {"conv_id": 1}).await.map_err(storage)?
        .ok_or_else(|| error(StatusCode::NOT_FOUND, "Messaggio non disponibile."))?;
    let _ = MESSAGE_EVENTS.send(string(&row, "conv_id"));
    Ok(reply(json!({"ok": true})))
}

pub async fn hide_conversation(
    State(state): State<AppState>,
    headers: HeaderMap,
    Path(conv_id): Path<String>,
) -> Result {
    let owner = authenticated(&state, &headers).await?;
    if !hex_len(&conv_id, 64) { return Err(bad("Conversazione non valida.")); }
    state.db.collection::<Document>(MESSAGES).update_many(
        doc! {"participants": &owner, "conv_id": &conv_id},
        doc! {"$addToSet": {"hidden_for": &owner}},
    ).await.map_err(storage)?;
    let _ = MESSAGE_EVENTS.send(conv_id);
    Ok(reply(json!({"ok": true})))
}

pub async fn conversations(State(state): State<AppState>, headers: HeaderMap) -> Result {
    let owner = authenticated(&state, &headers).await?;
    let rows: Vec<Document> = state.db.collection::<Document>(MESSAGES).aggregate([
        doc! {"$match": {"participants": &owner, "hidden_for": {"$ne": &owner}, "hidden_for_all": {"$ne": true}}},
        doc! {"$sort": {"_id": -1}},
        doc! {"$group": {
            "_id": "$conv_id", "from": {"$first": "$from_lns"}, "to": {"$first": "$to_lns"},
            "last_at": {"$first": "$sent_at"},
            "unread": {"$sum": {"$cond": [{"$and": [
                {"$eq": ["$to_lns", &owner]}, {"$eq": ["$read", false]}, {"$eq": ["$silent", false]}
            ]}, 1, 0]}},
        }},
        doc! {"$sort": {"last_at": -1}},
        doc! {"$limit": 200},
    ]).await.map_err(storage)?.try_collect().await.map_err(storage)?;
    Ok(reply(json!(rows.iter().map(|row| {
        let from = string(row, "from");
        let peer = if from == owner { string(row, "to") } else { from.clone() };
        let unread = match row.get("unread") {
            Some(Bson::Int32(n)) => i64::from(*n),
            Some(Bson::Int64(n)) => *n,
            _ => 0,
        };
        json!({"conv_id": string(row,"_id"), "others": [peer], "title_lns": peer,
            "title": peer.split('@').next().unwrap_or(""), "last_at": string(row,"last_at"),
            "last_from": from, "unread": unread})
    }).collect::<Vec<_>>())))
}

pub async fn badges(State(state): State<AppState>, headers: HeaderMap) -> Result {
    let owner = authenticated(&state, &headers).await?;
    let chat = state.db.collection::<Document>(MESSAGES)
        .count_documents(doc! {"to_lns": &owner, "read": false, "silent": false, "hidden_for": {"$ne": &owner}, "hidden_for_all": {"$ne": true}})
        .limit(1000).await.map_err(storage)?;
    Ok(reply(json!({"chat": chat, "certify": 0})))
}

#[derive(Deserialize)]
pub struct ExportPage {
    before: Option<String>,
}

pub async fn export(State(state): State<AppState>, headers: HeaderMap, Query(page): Query<ExportPage>) -> Result {
    let owner = authenticated(&state, &headers).await?;
    let account = state.db.collection::<Document>("lns")
        .find_one(doc! {"lns_name": &owner, "status": "ACTIVE"})
        .projection(doc! {"_id": 0, "created_at": 1, "ultron_public_key_hex": 1, "ultron_public_profile": 1})
        .await.map_err(storage)?.ok_or_else(|| error(StatusCode::NOT_FOUND, "Account non disponibile."))?;
    let public_profile = account.get_document("ultron_public_profile").ok().map(|p| json!({
        "headline": string(p,"headline"), "bio": string(p,"bio"), "avatar": string(p,"avatar"),
    }));
    let contacts: Vec<Document> = state.db.collection::<Document>(CONTACTS)
        .find(doc! {"owner": &owner, "$or": [{"added": true}, {"blocked": true}]})
        .projection(doc! {"_id": 0, "peer": 1, "added": 1, "blocked": 1})
        .limit(2001).await.map_err(storage)?.try_collect().await.map_err(storage)?;
    let mut query = doc! {"participants": &owner};
    if let Some(cursor) = page.before {
        query.insert("_id", doc! {"$lt": ObjectId::parse_str(cursor).map_err(|_| bad("Cursore non valido."))?});
    }
    let rows: Vec<Document> = state.db.collection::<Document>(MESSAGES)
        .find(query).sort(doc! {"_id": -1}).limit(EXPORT_MESSAGES + 1)
        .await.map_err(storage)?.try_collect().await.map_err(storage)?;
    let messages: Vec<Value> = rows.iter().take(EXPORT_MESSAGES as usize)
        .map(|row| message_view(row, &owner)).collect();
    let next = if rows.len() > EXPORT_MESSAGES as usize {
        messages.last().and_then(|row| row.get("message_id")).cloned()
    } else { None };
    Ok(reply(json!({
        "format": "ultron-server-export-v1", "generated_at": crate::utc_iso(),
        "account": {"lns": owner, "created_at": string(&account,"created_at"),
            "identity_public_key": string(&account,"ultron_public_key_hex"), "public_profile": public_profile},
        "contacts": contacts.iter().take(2000).map(|row| json!({
            "lns": string(row,"peer"), "added": added(Some(row)), "blocked": blocked(Some(row))
        })).collect::<Vec<_>>(),
        "contacts_truncated": contacts.len() > 2000, "messages": messages,
        "messages_truncated": next.is_some(), "next_before": next,
        "scope": "Server account, public profile, server contact entries and this account's encrypted message envelopes. Device-local data is excluded."
    })))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn conversation_is_pair_specific() {
        assert_eq!(pair_id("a@ultron.uns", "b@ultron.uns"), pair_id("b@ultron.uns", "a@ultron.uns"));
        assert_ne!(pair_id("a@ultron.uns", "b@ultron.uns"), pair_id("a@ultron.uns", "c@ultron.uns"));
        assert_eq!(address(" A@ULTRON.UNS ").unwrap(), "a@ultron.uns");
        assert!(address("a@@ultron.uns").is_err());
    }

    #[test]
    fn response_contains_only_the_callers_envelope() {
        let row = doc! {"from_lns": "a@ultron.uns", "to_lns": "b@ultron.uns",
            "from_envelope": {"for": "a@ultron.uns", "ct": "aaa"},
            "to_envelope": {"for": "b@ultron.uns", "ct": "bbb"}};
        let sender = message_view(&row, "a@ultron.uns");
        let recipient = message_view(&row, "b@ultron.uns");
        assert_eq!(sender["envelope"]["ct"], "aaa");
        assert_eq!(recipient["envelope"]["ct"], "bbb");
        assert!(sender.get("to_envelope").is_none());
        assert!(recipient.get("from_envelope").is_none());
    }
}
