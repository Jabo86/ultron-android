use axum::{extract::{Query, State}, http::StatusCode, Json};
use bson::{doc, Document};
use chrono::Utc;
use pqcrypto_mldsa::mldsa65;
use pqcrypto_traits::sign::{DetachedSignature as _, PublicKey as _};
use serde::Deserialize;
use serde_json::{json, Value};

use crate::{auth::{err, AuthError}, AppState};

type Response = Result<Json<Value>, (StatusCode, Json<AuthError>)>;

#[derive(Deserialize)]
pub struct CheckRequest {
    username: String,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct SignupRequest {
    username: String,
    public_key_hex: String,
    signature_hex: String,
}

fn address(username: &str) -> Result<String, (StatusCode, Json<AuthError>)> {
    if !(3..=32).contains(&username.len()) || !username.bytes().all(|c| {
        c.is_ascii_lowercase() || c.is_ascii_digit() || matches!(c, b'.' | b'_' | b'-')
    }) || !username.bytes().any(|c| c.is_ascii_alphanumeric()) {
        return Err(err(StatusCode::BAD_REQUEST, "Nome utente non valido."));
    }
    Ok(format!("{username}@ultron.uns"))
}

fn storage_error(error: mongodb::error::Error) -> (StatusCode, Json<AuthError>) {
    tracing::error!(%error, "ULTRON account storage");
    err(StatusCode::SERVICE_UNAVAILABLE, "Registrazione temporaneamente indisponibile.")
}

pub async fn check(State(state): State<AppState>, Query(req): Query<CheckRequest>) -> Response {
    let name = address(&req.username)?;
    let existing = state.db.collection::<Document>("lns")
        .find_one(doc! {"lns_name": &name}).projection(doc! {"_id": 1})
        .await.map_err(storage_error)?;
    Ok(Json(json!({"available": existing.is_none()})))
}

pub async fn signup(State(state): State<AppState>, Json(req): Json<SignupRequest>) -> Response {
    let name = address(&req.username)?;
    let invalid = || err(StatusCode::BAD_REQUEST, "Chiave pubblica o firma non valida.");
    if req.public_key_hex.len() != 2 * mldsa65::public_key_bytes()
        || req.signature_hex.len() != 2 * mldsa65::signature_bytes() {
        return Err(invalid());
    }
    let key_bytes = hex::decode(&req.public_key_hex).map_err(|_| invalid())?;
    let signature_bytes = hex::decode(&req.signature_hex).map_err(|_| invalid())?;
    let public_key = mldsa65::PublicKey::from_bytes(&key_bytes).map_err(|_| invalid())?;
    let signature = mldsa65::DetachedSignature::from_bytes(&signature_bytes).map_err(|_| invalid())?;
    let proof = format!("ultron-personal-signup-v1:{name}");
    mldsa65::verify_detached_signature(&signature, proof.as_bytes(), &public_key)
        .map_err(|_| err(StatusCode::UNAUTHORIZED, "Firma di registrazione non valida."))?;

    let accounts = state.db.collection::<Document>("lns");
    if accounts.find_one(doc! {"lns_name": &name, "_id": {"$ne": &name}})
        .projection(doc! {"_id": 1}).await.map_err(storage_error)?.is_some() {
        return Err(err(StatusCode::CONFLICT, "Nome utente già in uso."));
    }
    let public_key_hex = hex::encode(key_bytes);
    let created_at = Utc::now().to_rfc3339();
    let result = accounts.update_one(
        doc! {"_id": &name},
        doc! {"$setOnInsert": {
            "lns_name": &name,
            "status": "ACTIVE",
            "role": "operator",
            "discoverable": false,
            "ultron_public_key_hex": &public_key_hex,
            "created_at": &created_at,
        }},
    ).upsert(true).await;
    if let Err(error) = result {
        let duplicate = matches!(error.kind.as_ref(), mongodb::error::ErrorKind::Write(
            mongodb::error::WriteFailure::WriteError(write)
        ) if write.code == 11000);
        if !duplicate { return Err(storage_error(error)); }
    }
    let existing = accounts.find_one(doc! {"_id": &name}).await.map_err(storage_error)?
        .ok_or_else(|| err(StatusCode::SERVICE_UNAVAILABLE, "Registrazione temporaneamente indisponibile."))?;
    if existing.get_str("ultron_public_key_hex").ok() != Some(public_key_hex.as_str())
        || existing.get_str("status").ok() != Some("ACTIVE") {
        return Err(err(StatusCode::CONFLICT, "Nome utente già in uso."));
    }
    Ok(Json(json!({"lns_name": name, "created_at": existing.get_str("created_at").unwrap_or(&created_at)})))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn namespace_and_username_bounds() {
        assert_eq!(address("mario.rossi").unwrap(), "mario.rossi@ultron.uns");
        for invalid in ["ab", "___", "Mario", "a@b", "foo/bar", &"a".repeat(33)] {
            assert!(address(invalid).is_err());
        }
    }
}
