//! Ordered, opaque MLS delivery for the isolated pilot. Clients verify the MLS
//! transcript and signatures. The gateway only controls authorization, ordering
//! and delivery, and never receives group secrets or cleartext.
use super::{address, authenticated, bad, error, hex_len, may_send, purge::durable, reply, storage, AppState, Result};
use super::{group_control, group_files};
use crate::wake;
use axum::{extract::{Path, Query, State}, http::{HeaderMap, StatusCode}, Json};
use base64::{engine::general_purpose::STANDARD, Engine};
use bson::{doc, Bson, DateTime, Document};
use futures::TryStreamExt;
use serde::Deserialize;
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::time::Duration;
use tokio::sync::Mutex;

pub(super) const GROUPS: &str = "ultron_mls_groups";
pub(super) const EVENTS: &str = "ultron_mls_events";
const PACKAGES: &str = "ultron_mls_packages";
const MAX_MEMBERS: usize = 12;
const MAX_PACKET: usize = 384 * 1024;
const PACKAGE_TTL_MS: i64 = 86_400_000;
// The pilot currently runs one writable process against standalone MongoDB.
// Committing the metadata with a compare-and-swap remains required on retries.
pub(super) static WRITE: Mutex<()> = Mutex::const_new(());

pub(super) fn enabled() -> bool {
    std::env::var("ULTRON_MLS_PILOT").as_deref() == Ok("1")
}

pub(super) async fn ensure_indexes(db: &mongodb::Database) -> mongodb::error::Result<()> {
    use mongodb::{options::IndexOptions, IndexModel};
    for (name, keys, unique) in [
        (GROUPS, doc! {"members.account": 1}, false),
        (GROUPS, doc! {"listing.name": 1}, false),
        (EVENTS, doc! {"group": 1, "seq": 1}, true),
        (EVENTS, doc! {"group": 1, "author": 1, "op": 1}, true),
        (PACKAGES, doc! {"owner": 1, "expires_at": 1}, false),
    ] {
        db.collection::<Document>(name).create_index(IndexModel::builder().keys(keys)
            .options(IndexOptions::builder().unique(unique).build()).build()).await?;
    }
    db.collection::<Document>(PACKAGES).create_index(IndexModel::builder().keys(doc! {"expires_at": 1})
        .options(IndexOptions::builder().expire_after(Duration::ZERO).build()).build()).await?;
    Ok(())
}

fn missing() -> super::Error {
    error(StatusCode::NOT_FOUND, "Gruppo ULTRON non disponibile.")
}

fn conflict() -> super::Error {
    error(StatusCode::CONFLICT, "Lo stato del gruppo è cambiato. Sincronizza prima di inviare.")
}

pub(super) async fn owner(state: &AppState, headers: &HeaderMap) -> Result<String> {
    if !enabled() { return Err(missing()); }
    authenticated(state, headers).await
}

pub(super) fn group_id(id: &str) -> Result<&str> {
    if !hex_len(id, 64) || id != id.to_ascii_lowercase() { return Err(bad("Identificativo gruppo non valido.")); }
    Ok(id)
}

fn packet(value: &str) -> Result<Vec<u8>> {
    if value.is_empty() || value.len() > MAX_PACKET.div_ceil(3) * 4 {
        return Err(bad("Busta MLS non valida."));
    }
    STANDARD.decode(value).ok().filter(|bytes| !bytes.is_empty() && bytes.len() <= MAX_PACKET)
        .ok_or_else(|| bad("Busta MLS non valida."))
}

fn number(doc: &Document, key: &str) -> Result<i64> {
    doc.get_i64(key).map_err(|_| conflict())
}

pub(super) fn since(doc: &Document, account: &str) -> Option<i64> {
    doc.get_array("members").ok()?.iter().find_map(|entry| {
        let entry = entry.as_document()?;
        if entry.get_str("account").ok()? == account { entry.get_i64("since").ok() } else { None }
    })
}

pub(super) async fn admin_group(state: &AppState, id: &str, owner: &str) -> Result<Document> {
    durable(state, GROUPS).find_one(doc! {"_id": id, "admin": owner})
        .await.map_err(storage)?.ok_or_else(missing)
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct GroupCreate {
    id: String,
    signature: String,
    listing: Option<Listing>,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Listing { name: String, signature: String }

pub async fn create(State(state): State<AppState>, headers: HeaderMap, Json(req): Json<GroupCreate>) -> Result {
    let sender = owner(&state, &headers).await?;
    let id = group_id(&req.id)?;
    if !hex_len(&req.signature, 6618) { return Err(bad("Firma del gruppo non valida.")); }
    let listing = if let Some(listing) = req.listing {
        if !super::group_invites::enabled() || listing.name.trim() != listing.name ||
            listing.name.is_empty() || listing.name.chars().count() > 60 || listing.name.chars().any(char::is_control) {
            return Err(bad("Nome pubblico del gruppo non valido."));
        }
        let scope = std::env::var("ULTRON_MLS_ORIGIN").map_err(|_| missing())?;
        let transcript = json!(["ultron-mls-listing-v1", scope, id, &sender, &listing.name]).to_string();
        super::group_invites::verify_signature(&state, &sender, &transcript, &listing.signature).await?;
        Some(doc! {"name": listing.name, "signature": listing.signature})
    } else { None };
    let groups = durable(&state, GROUPS);
    let _guard = WRITE.lock().await;
    if let Some(existing) = groups.find_one(doc! {"_id": id}).await.map_err(storage)? {
        if existing.get_str("admin").ok() != Some(sender.as_str()) ||
            existing.get_str("signature").ok() != Some(req.signature.as_str()) || existing.get_document("listing").ok() != listing.as_ref() { return Err(conflict()); }
        return Ok(reply(json!({"id": id})));
    }
    if groups.count_documents(doc! {"admin": &sender}).limit(100).await.map_err(storage)? >= 100 {
        return Err(error(StatusCode::TOO_MANY_REQUESTS, "Limite di gruppi pilota raggiunto."));
    }
    let mut row = doc! {"_id": id, "admin": &sender, "signature": &req.signature, "epoch": 0_i64, "seq": 0_i64,
        "members": [doc! {"account": &sender, "since": 0_i64}]};
    if let Some(listing) = listing { row.insert("listing", listing); }
    groups.insert_one(row).await.map_err(storage)?;
    Ok(reply(json!({"id": id})))
}

pub async fn list(State(state): State<AppState>, headers: HeaderMap) -> Result {
    let sender = owner(&state, &headers).await?;
    let rows: Vec<Document> = durable(&state, GROUPS).find(doc! {"members.account": &sender})
        .projection(doc! {"admin": 1, "signature": 1, "epoch": 1, "seq": 1, "members": 1, "leaving": 1, "deleted_at": 1, "listing": 1})
        .limit(250).await.map_err(storage)?.try_collect().await.map_err(storage)?;
    Ok(reply(json!(rows.iter().filter(|row| group_control::visible(row, &sender)).filter_map(|row| Some(json!({
        "id": row.get_str("_id").ok()?, "admin": row.get_str("admin").ok()?,
        "signature": row.get_str("signature").ok()?, "epoch": number(row, "epoch").ok()?, "seq": number(row, "seq").ok()?,
        "since": since(row, &sender)?, "visibility": if row.contains_key("listing") {"public"} else {"private"},
    }))).collect::<Vec<_>>())))
}

pub async fn directory(State(state): State<AppState>, headers: HeaderMap) -> Result {
    owner(&state, &headers).await?;
    if !super::group_invites::enabled() { return Err(missing()); }
    let rows: Vec<Document> = durable(&state, GROUPS).find(doc! {"listing.name": {"$exists": true}})
        .projection(doc! {"admin": 1, "listing": 1}).sort(doc! {"listing.name": 1})
        .limit(100).await.map_err(storage)?.try_collect().await.map_err(storage)?;
    Ok(reply(json!(rows.iter().filter_map(|row| Some(json!({
        "id": row.get_str("_id").ok()?, "admin": row.get_str("admin").ok()?,
        "name": row.get_document("listing").ok()?.get_str("name").ok()?,
    }))).collect::<Vec<_>>())))
}

#[derive(Clone, Copy, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "lowercase")]
enum Kind { Message, Add, Remove }

impl Kind {
    fn as_str(self) -> &'static str {
        match self { Self::Message => "message", Self::Add => "add", Self::Remove => "remove" }
    }
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Append {
    op: String,
    epoch: i64,
    cursor: i64,
    kind: Kind,
    wire: String,
    target: Option<String>,
    welcome: Option<String>,
    welcome_signature: Option<String>,
    invitation: Option<String>,
    package: Option<String>,
    file: Option<String>,
    #[serde(default)]
    managed_profile: bool,
}

fn available_target(req: &Append, sender: &str) -> Result<Option<String>> {
    packet(&req.wire)?;
    if !hex_len(&req.op, 32) || req.epoch < 0 || req.cursor < 0 { return Err(bad("Operazione gruppo non valida.")); }
    match (req.kind, &req.target, &req.welcome, &req.welcome_signature, &req.package) {
        (Kind::Message, None, None, None, None) => Ok(None),
        (Kind::Add, Some(target), Some(welcome), Some(signature), Some(package)) if hex_len(package, 64) && hex_len(signature, 6618) => {
            packet(welcome)?;
            let target = address(target)?;
            if target == sender { return Err(bad("Il destinatario è già amministratore.")); }
            Ok(Some(target))
        }
        (Kind::Remove, Some(target), None, None, None) => {
            let target = address(target)?;
            if target == sender { return Err(bad("L’amministratore non può rimuovere se stesso.")); }
            Ok(Some(target))
        }
        _ => Err(bad("Configurazione operazione gruppo non valida.")),
    }
}

// Complete a durable reservation. The event is only visible once the group
// advances its published cursor. A retry completes the same event and roster.
pub(super) async fn settle(state: &AppState, id: &str, group: Document) -> Result<Document> {
    let Ok(pending) = group.get_document("pending") else { return Ok(group); };
    let event = pending.get_document("event").map_err(|_| conflict())?;
    let seq = number(event, "seq")?;
    let event_id = event.get_str("_id").map_err(|_| conflict())?;
    let groups = durable(state, GROUPS);
    let events = durable(state, EVENTS);
    events.update_one(doc! {"_id": event_id}, doc! {"$setOnInsert": event.clone()})
        .upsert(true).await.map_err(storage)?;
    let fixed = events.find_one(doc! {"_id": event_id}).await.map_err(storage)?.ok_or_else(conflict)?;
    // The driver may return _id first even when BSON input field order differs.
    if event.iter().any(|(key, value)| fixed.get(key) != Some(value)) { return Err(conflict()); }
    if let Ok(invitation) = event.get_str("invitation") {
        super::group_invites::settle(state, invitation, event_id).await?;
    }
    if let Ok(file) = event.get_str("file") {
        group_files::bind(state, id, file, seq).await?;
    }
    let members = pending.get_array("members").map_err(|_| conflict())?.clone();
    let mut leaving = group.get_array("leaving").cloned().unwrap_or_default();
    if event.get_str("kind").ok() == Some("remove") {
        let target = event.get_str("subject").ok();
        leaving.retain(|entry| entry.as_document().and_then(|item| item.get_str("account").ok()) != target);
    }
    let updated = groups.update_one(doc! {"_id": id, "seq": seq - 1, "pending.event._id": event_id},
        doc! {"$set": {"seq": seq, "epoch": number(event, "next_epoch")?, "members": members, "leaving": leaving},
            "$unset": {"pending": ""}}).await.map_err(storage)?;
    if updated.matched_count != 1 { return Err(conflict()); }
    groups.find_one(doc! {"_id": id}).await.map_err(storage)?.ok_or_else(missing)
}

pub async fn append(State(state): State<AppState>, headers: HeaderMap, Path(raw): Path<String>, Json(req): Json<Append>) -> Result {
    let sender = owner(&state, &headers).await?;
    let id = group_id(&raw)?;
    let target = available_target(&req, &sender)?;
    let groups = durable(&state, GROUPS);
    let events = durable(&state, EVENTS);
    let _guard = WRITE.lock().await;
    let group = groups.find_one(doc! {"_id": id}).await.map_err(storage)?.ok_or_else(missing)?;
    if !group_control::visible(&group, &sender) { return Err(missing()); }
    let group = settle(&state, id, group).await?;
    if !group_control::visible(&group, &sender) { return Err(missing()); }
    let joined = since(&group, &sender).ok_or_else(missing)?;
    let prior = events.find_one(doc! {"group": id, "author": &sender, "op": &req.op})
        .await.map_err(storage)?;
    if let Some(row) = prior {
        if number(&row, "seq")? < joined || number(&row, "seq")? - 1 != req.cursor || number(&row, "epoch")? != req.epoch
            || row.get_str("kind").ok() != Some(req.kind.as_str())
            || row.get_str("wire").ok() != Some(req.wire.as_str())
            || row.get_str("subject").ok() != target.as_deref()
            || row.get_str("welcome").ok() != req.welcome.as_deref()
            || row.get_str("welcome_signature").ok() != req.welcome_signature.as_deref()
            || row.get_str("invitation").ok() != req.invitation.as_deref()
            || row.get_str("package").ok() != req.package.as_deref()
            || row.get_str("file").ok() != req.file.as_deref()
            || row.get_bool("managed_profile").unwrap_or(false) != req.managed_profile { return Err(conflict()); }
        return Ok(reply(json!({"seq": number(&row, "seq")?, "epoch": number(&row, "next_epoch")?})));
    }

    if group_control::enabled() {
        if group_control::pending_rotation(&group) && req.kind != Kind::Remove {
            return Err(error(StatusCode::FORBIDDEN, "Attendi il rinnovo delle chiavi del gruppo."));
        }
        if req.kind == Kind::Message && group_control::muted(&group, &sender) {
            return Err(error(StatusCode::FORBIDDEN, "Invio silenziato da un moderatore."));
        }
    }
    let seq = number(&group, "seq")?.checked_add(1).ok_or_else(conflict)?;
    let epoch = number(&group, "epoch")?;
    if epoch != req.epoch || seq - 1 != req.cursor { return Err(conflict()); }
    if req.managed_profile && (!group_control::enabled() || req.kind != Kind::Message || !group_control::can_manage(&group, &sender)) {
        return Err(group_control::denied());
    }
    if let Some(file) = req.file.as_deref() {
        if !group_control::enabled() || req.kind != Kind::Message { return Err(bad("Allegato non valido.")); }
        group_files::available(&state, id, &sender, file, epoch).await?;
    }
    let mut members = group.get_array("members").map_err(|_| conflict())?.clone();
    let mut next_epoch = epoch;
    let mut consent = None;
    if req.invitation.is_some() && req.kind != Kind::Add { return Err(bad("Invito non valido per questa operazione.")); }
    if let Some(peer) = &target {
        if group.get_str("admin").ok() != Some(sender.as_str()) {
            return Err(error(StatusCode::FORBIDDEN, "Solo l’amministratore può modificare i membri."));
        }
        next_epoch = epoch.checked_add(1).ok_or_else(conflict)?;
        match req.kind {
            Kind::Add => {
                if members.len() >= MAX_MEMBERS || since(&group, peer).is_some() { return Err(conflict()); }
                wake::require_active(&state, peer).await?;
                if !may_send(&state, &sender, peer).await? {
                    return Err(error(StatusCode::FORBIDDEN, "Serve un contatto accettato da entrambi."));
                }
                if group_control::enabled() && group.contains_key("listing") && !group_control::verified(&state, peer).await? {
                    return Err(error(StatusCode::FORBIDDEN, "Il destinatario deve verificare il proprio account."));
                }
                if super::group_invites::enabled() {
                    let invitation = req.invitation.as_deref().ok_or_else(|| error(StatusCode::FORBIDDEN, "Serve un invito accettato dal destinatario."))?;
                    consent = Some(super::group_invites::check_accepted(&state, invitation, id, &sender, peer).await?);
                } else if req.invitation.is_some() { return Err(conflict()); }
                let package = req.package.as_deref().ok_or_else(conflict)?;
                let consumed = durable(&state, PACKAGES).update_one(doc! {"_id": package, "owner": peer,
                    "claimed_by": &sender, "expires_at": {"$gt": DateTime::now()}, "$or": [
                        {"bound_op": {"$exists": false}}, {"bound_op": &req.op, "bound_group": id}
                    ]}, doc! {"$set": {"bound_op": &req.op, "bound_group": id}})
                    .await.map_err(storage)?;
                if consumed.matched_count != 1 { return Err(conflict()); }
                members.push(Bson::Document(doc! {"account": peer, "since": seq}));
            }
            Kind::Remove => {
                if since(&group, peer).is_none() { return Err(conflict()); }
                members.retain(|row| row.as_document().and_then(|entry| entry.get_str("account").ok()) != Some(peer.as_str()));
            }
            Kind::Message => unreachable!(),
        }
    }

    for entry in &members {
        let account = entry.as_document().and_then(|row| row.get_str("account").ok()).ok_or_else(conflict)?;
        if account != sender { wake::require_active(&state, account).await?; }
    }
    let mut event = doc! {"_id": format!("{id}:{seq}"), "group": id, "author": &sender, "op": &req.op,
        "kind": req.kind.as_str(), "epoch": epoch, "next_epoch": next_epoch, "seq": seq, "wire": &req.wire};
    if let Some(peer) = target { event.insert("subject", peer); }
    if let Some(welcome) = req.welcome { event.insert("welcome", welcome); }
    if let Some(signature) = req.welcome_signature { event.insert("welcome_signature", signature); }
    if let Some(package) = req.package { event.insert("package", package); }
    if let Some(invitation) = req.invitation { event.insert("invitation", invitation); }
    if let Some(proof) = consent { event.insert("consent", proof); }
    if let Some(file) = req.file { event.insert("file", file); }
    if req.managed_profile { event.insert("managed_profile", true); }
    let reserved = groups.update_one(doc! {"_id": id, "seq": seq - 1, "epoch": epoch, "pending": {"$exists": false}},
        doc! {"$set": {"pending": {"event": event, "members": members}}}).await.map_err(storage)?;
    if reserved.matched_count != 1 { return Err(conflict()); }
    let reserved = groups.find_one(doc! {"_id": id}).await.map_err(storage)?.ok_or_else(missing)?;
    settle(&state, id, reserved).await?;
    Ok(reply(json!({"seq": seq, "epoch": next_epoch})))
}

#[derive(Deserialize)]
pub struct Paging {
    #[serde(default)]
    cursor: i64,
    #[serde(default)]
    protocol: u8,
}

fn visible_event(row: &Document, viewer: &str, joined: i64) -> Result<Value> {
    let sequence = number(row, "seq")?;
    let subject = row.get_str("subject").ok();
    let joining_here = sequence == joined && subject == Some(viewer) && row.get_str("kind").ok() == Some("add");
    // The old-epoch Commit packet is not needed by the recipient of Welcome.
    Ok(json!({
        "seq": sequence, "epoch": number(row, "epoch")?, "next_epoch": number(row, "next_epoch")?,
        "kind": row.get_str("kind").map_err(|_| conflict())?, "author": row.get_str("author").map_err(|_| conflict())?,
        "op": row.get_str("op").map_err(|_| conflict())?, "subject": subject, "wire": if joining_here { None } else { row.get_str("wire").ok() },
        "welcome": if joining_here { row.get_str("welcome").ok() } else { None },
        "welcome_signature": if joining_here { row.get_str("welcome_signature").ok() } else { None },
        "package": if joining_here { row.get_str("package").ok() } else { None },
        "invitation": if joining_here { row.get_str("invitation").ok() } else { None },
        "consent": if joining_here { row.get_str("consent").ok() } else { None },
        "file": row.get_str("file").ok(), "managed_profile": row.get_bool("managed_profile").unwrap_or(false),
    }))
}

pub async fn events(State(state): State<AppState>, headers: HeaderMap, Path(raw): Path<String>, Query(q): Query<Paging>) -> Result {
    let sender = owner(&state, &headers).await?;
    let id = group_id(&raw)?;
    let _guard = WRITE.lock().await;
    let group = durable(&state, GROUPS).find_one(doc! {"_id": id}).await.map_err(storage)?.ok_or_else(missing)?;
    if !group_control::visible(&group, &sender) { return Err(missing()); }
    let group = settle(&state, id, group).await?;
    if !group_control::visible(&group, &sender) { return Err(missing()); }
    let joined = since(&group, &sender).ok_or_else(missing)?;
    if q.protocol == 0 && group.get_array("hidden").is_ok_and(|items| !items.is_empty()) {
        return Err(error(StatusCode::UPGRADE_REQUIRED, "Aggiorna ULTRON per aprire il gruppo moderato."));
    }
    let last = number(&group, "seq")?;
    let limit = 8_i64;
    let rows: Vec<Document> = durable(&state, EVENTS).find(doc! {"group": id, "seq": {"$gt": q.cursor.max(joined - 1), "$lte": last}})
        .sort(doc! {"seq": 1}).limit(limit).await.map_err(storage)?.try_collect().await.map_err(storage)?;
    let page = rows.iter().map(|row| visible_event(row, &sender, joined)).collect::<Result<Vec<_>>>()?;
    Ok(reply(json!({"epoch": number(&group, "epoch")?, "seq": last, "since": joined, "events": page})))
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct PublishPackage { wire: String }

pub async fn publish_package(State(state): State<AppState>, headers: HeaderMap, Json(req): Json<PublishPackage>) -> Result {
    let sender = owner(&state, &headers).await?;
    let sha = hex::encode(Sha256::digest(packet(&req.wire)?));
    let id = hex::encode(Sha256::digest(format!("ultron-mls-package-v1\0{sender}\0{sha}").as_bytes()));
    let packages = durable(&state, PACKAGES);
    let _guard = WRITE.lock().await;
    if packages.find_one(doc! {"_id": &id, "owner": &sender}).await.map_err(storage)?.is_none() {
        let now = DateTime::now();
        if packages.count_documents(doc! {"owner": &sender, "expires_at": {"$gt": now}})
            .limit(48).await.map_err(storage)? >= 48 {
            return Err(error(StatusCode::TOO_MANY_REQUESTS, "Troppi pacchetti MLS attivi."));
        }
        packages.insert_one(doc! {"_id": &id, "owner": &sender, "wire": &req.wire,
            "expires_at": DateTime::from_millis(now.timestamp_millis() + PACKAGE_TTL_MS)})
            .await.map_err(storage)?;
    }
    Ok(reply(json!({"id": id})))
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ClaimPackage { op: String }

pub async fn claim_package(State(state): State<AppState>, headers: HeaderMap, Path(raw): Path<String>, Json(req): Json<ClaimPackage>) -> Result {
    let sender = owner(&state, &headers).await?;
    let peer = address(&raw)?;
    if !hex_len(&req.op, 32) { return Err(bad("Prenotazione non valida.")); }
    if !may_send(&state, &sender, &peer).await? { return Err(missing()); }
    wake::require_active(&state, &peer).await?;
    let packages = durable(&state, PACKAGES);
    let _guard = WRITE.lock().await;
    let now = DateTime::now();
    let previous = packages.find_one(doc! {"owner": &peer, "claimed_by": &sender, "claim": &req.op,
        "expires_at": {"$gt": now}}).await.map_err(storage)?;
    let row = if let Some(previous) = previous { previous } else {
        packages.find_one_and_update(doc! {"owner": &peer, "expires_at": {"$gt": now},
            "claimed_by": {"$exists": false}}, doc! {"$set": {"claimed_by": &sender, "claim": &req.op}})
            .sort(doc! {"expires_at": 1}).await.map_err(storage)?.ok_or_else(missing)?
    };
    Ok(reply(json!({"id": row.get_str("_id").map_err(|_| conflict())?, "wire": row.get_str("wire").map_err(|_| conflict())?})))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn welcome_is_visible_only_to_the_joining_member() {
        let event = doc! {"seq": 8_i64, "epoch": 2_i64, "next_epoch": 3_i64, "kind": "add",
            "author": "alice@ultron.uns", "op": "proof", "subject": "bob@ultron.uns", "wire": "old epoch commit",
            "welcome": "sealed welcome", "package": "one-time package"};
        let bob = visible_event(&event, "bob@ultron.uns", 8).unwrap();
        assert!(bob["wire"].is_null());
        assert_eq!(bob["welcome"], "sealed welcome");
        let other = visible_event(&event, "alice@ultron.uns", 0).unwrap();
        assert!(other["welcome"].is_null());
        assert!(other["package"].is_null());
        assert_eq!(other["wire"], "old epoch commit");
    }

    #[test]
    fn invalid_base64_or_oversized_packets_and_ambiguous_operations_are_rejected() {
        assert!(packet("not a valid packet").is_err());
        assert!(packet(&"AAAA".repeat(MAX_PACKET)).is_err());
        let request = Append { op: "aa".repeat(16), epoch: 3, cursor: 0, kind: Kind::Message, wire: "AA==".into(),
            target: Some("bob@ultron.uns".into()), welcome: None, welcome_signature: None, invitation: None, package: None, file: None, managed_profile: false };
        assert!(available_target(&request, "alice@ultron.uns").is_err());
    }
}
