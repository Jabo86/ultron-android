//! Wire validation for hybrid ratchet envelopes. Ratchet state lives on the devices.
use super::{address, bad, hex_len, Result};
use base64::{engine::general_purpose::STANDARD, Engine};
use bson::{doc, Document};
use serde::{Deserialize, Serialize};
use pqcrypto_mldsa::mldsa65;
use pqcrypto_traits::sign::{DetachedSignature as _, PublicKey as _};

#[derive(Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
struct Init {
    ct1: String,
    pk_id: String,
    epk: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    k: Option<String>,
}

#[derive(Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
struct Header {
    v: u8,
    sdev: String,
    pf: String,
    xpk: String,
    n: u32,
    pn: u32,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pk: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    ct: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    kf: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    init: Option<Init>,
}

#[derive(Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct RatchetEnvelope {
    #[serde(rename = "for")]
    recipient: String,
    dev: String,
    session_id: String,
    r: u8,
    h: Header,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    init_sig: Option<String>,
    iv: String,
    ct: String,
}

fn base64_size(input: &str, min: usize, max: usize) -> bool {
    input.len() <= max.div_ceil(3) * 4
        && STANDARD.decode(input).is_ok_and(|bytes| (min..=max).contains(&bytes.len()))
}

fn b64(input: &str, size: usize) -> bool {
    base64_size(input, size, size)
}

impl RatchetEnvelope {
    pub(super) fn validate(&self) -> Result<String> {
        let h = &self.h;
        let pq = match (&h.pk, &h.ct, &h.kf) {
            (None, None, None) => true,
            (Some(pk), Some(ct), Some(kf)) => b64(pk, 1184) && b64(ct, 1088) && b64(kf, 8),
            _ => false,
        };
        let init = h.init.as_ref().is_none_or(|i| {
            let size = match i.k.as_deref() {
                None => 1088,
                Some("1024") => 1568,
                _ => return false,
            };
            i.pk_id == self.session_id && b64(&i.epk, 32) && b64(&i.ct1, size) && h.pk.is_some()
        });
        if self.r != 2 || h.v != 2 || !hex_len(&self.dev, 32) || !hex_len(&h.sdev, 32)
            || !hex_len(&self.session_id, 32) || !b64(&h.pf, 8) || !b64(&h.xpk, 32)
            || h.n > i32::MAX as u32 || h.pn > i32::MAX as u32
            || h.init.is_some() != self.init_sig.is_some()
            || self.init_sig.as_ref().is_some_and(|s| !hex_len(s, mldsa65::signature_bytes() * 2))
            || !pq || !init || !b64(&self.iv, 12) || !base64_size(&self.ct, 16, 65_536)
        {
            return Err(bad("Busta ratchet non valida."));
        }
        let recipient = address(&self.recipient)?;
        if recipient != self.recipient { return Err(bad("Indirizzo della busta non canonico.")); }
        Ok(recipient)
    }

    fn initial_proof(&self, sender: &str, init: &Init) -> String {
        let h = &self.h;
        let fields = serde_json::json!([
            sender, self.recipient, self.dev, self.session_id, self.r, h.v, h.sdev, h.pf, h.xpk, h.n, h.pn,
            h.pk, h.ct, h.kf, init.ct1, init.pk_id, init.epk, init.k, self.iv, self.ct,
        ]);
        format!("ultron-ratchet-init-v1\n{fields}")
    }

    pub(super) fn verify_initial_sender(&self, sender: &str, identity_key: &str) -> Result<()> {
        let Some(init) = &self.h.init else { return Ok(()); };
        let invalid = || bad("Firma dell’aggancio ratchet non valida.");
        let public = hex::decode(identity_key).map_err(|_| invalid())?;
        let signature = hex::decode(self.init_sig.as_deref().unwrap_or_default()).map_err(|_| invalid())?;
        let public = mldsa65::PublicKey::from_bytes(&public).map_err(|_| invalid())?;
        let signature = mldsa65::DetachedSignature::from_bytes(&signature).map_err(|_| invalid())?;
        mldsa65::verify_detached_signature(
            &signature, self.initial_proof(sender, init).as_bytes(), &public,
        ).map_err(|_| invalid())
    }

    pub(super) fn to_doc(&self, owner: String) -> Result<Document> {
        let mut envelope = bson::to_document(self).map_err(|_| bad("Busta ratchet non valida."))?;
        envelope.insert("for", owner);
        Ok(envelope)
    }
}

pub(super) fn view(envelope: &Document) -> Option<serde_json::Value> {
    let decoded: RatchetEnvelope = bson::from_document(envelope.clone()).ok()?;
    serde_json::to_value(decoded).ok()
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    fn sample() -> serde_json::Value {
        json!({
            "for": "b@ultron.uns", "dev": "22".repeat(16), "session_id": "33".repeat(16), "r": 2,
            "h": {"v": 2, "sdev": "11".repeat(16), "pf": STANDARD.encode([2; 8]),
                  "xpk": STANDARD.encode([1; 32]), "n": 0, "pn": 0,
                  "pk": STANDARD.encode([1; 1184]), "ct": STANDARD.encode([1; 1088]), "kf": STANDARD.encode([3; 8]),
                  "init": {"ct1": STANDARD.encode([1; 1088]), "pk_id": "33".repeat(16), "epk": STANDARD.encode([1; 32])}},
            "init_sig": "44".repeat(mldsa65::signature_bytes()),
            "iv": STANDARD.encode([1; 12]), "ct": STANDARD.encode([1; 16]),
        })
    }

    #[test]
    fn initial_envelope_round_trips_without_losing_header_fields() {
        let input = sample();
        let decoded: RatchetEnvelope = serde_json::from_value(input.clone()).unwrap();
        let who = decoded.validate().unwrap();
        assert_eq!(view(&decoded.to_doc(who).unwrap()).unwrap(), input);
    }

    #[test]
    fn initial_signature_binds_sender_recipient_device_and_ciphertext() {
        let sender = "a@ultron.uns";
        let mut envelope: RatchetEnvelope = serde_json::from_value(sample()).unwrap();
        let (pk, sk) = mldsa65::keypair();
        let signature = mldsa65::detached_sign(
            envelope.initial_proof(sender, envelope.h.init.as_ref().unwrap()).as_bytes(), &sk,
        );
        envelope.init_sig = Some(hex::encode(signature.as_bytes()));
        let pk = hex::encode(pk.as_bytes());
        assert!(envelope.verify_initial_sender(sender, &pk).is_ok());
        assert!(envelope.verify_initial_sender("other@ultron.uns", &pk).is_err());
        envelope.dev = "33".repeat(16);
        assert!(envelope.verify_initial_sender(sender, &pk).is_err());
    }

    #[test]
    fn missing_prekey_and_incomplete_pq_header_are_rejected() {
        let mut input = sample();
        input["h"]["init"]["pk_id"] = json!("");
        let decoded: RatchetEnvelope = serde_json::from_value(input).unwrap();
        assert!(decoded.validate().is_err());

        let mut input = sample();
        input["h"].as_object_mut().unwrap().remove("ct");
        let decoded: RatchetEnvelope = serde_json::from_value(input).unwrap();
        assert!(decoded.validate().is_err());
    }
}
