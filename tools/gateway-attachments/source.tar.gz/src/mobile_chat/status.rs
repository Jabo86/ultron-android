//! Expiring encrypted statuses. The gateway only stores ciphertext and per-recipient wraps.
use super::{address, authenticated, bad, error, hex_len, may_send, reply, storage, string, Reply, Result, CONTACTS, KEYS};
use crate::AppState;
use axum::{extract::{Path, State}, http::{HeaderMap, StatusCode}, Json};
use bson::{doc, oid::ObjectId, DateTime, Document};
use futures::TryStreamExt;
use mongodb::IndexModel;
use serde::Deserialize;
use serde_json::json;
use sha2::{Digest, Sha256};
use std::{collections::HashSet, time::Duration};

const COLLECTION: &str = "ultron_mobile_status";
const MAX_RECIPIENTS: usize = 32;
const MAX_CIPHERTEXT_HEX: usize = 900_000;

pub async fn ensure_indexes(db: &mongodb::Database) -> mongodb::error::Result<()> {
    let collection = db.collection::<Document>(COLLECTION);
    collection.create_index(IndexModel::builder().keys(doc! {"expires_at": 1})
        .options(mongodb::options::IndexOptions::builder().expire_after(Duration::ZERO).build())
        .build()).await?;
    collection.create_index(IndexModel::builder().keys(doc! {"audience": 1, "_id": -1}).build()).await?;
    collection.create_index(IndexModel::builder().keys(doc! {"author": 1, "expires_at": 1}).build()).await?;
    Ok(())
}

fn live(id: ObjectId) -> Document {
    doc! {"_id": id, "expires_at": {"$gt": DateTime::now()}}
}

fn id(value: &str) -> Result<ObjectId> {
    ObjectId::parse_str(value).map_err(|_| bad("Stato non valido."))
}

fn unavailable() -> super::Error {
    error(StatusCode::NOT_FOUND, "Stato non disponibile.")
}

pub async fn audience(State(state): State<AppState>, headers: HeaderMap) -> Result {
    let owner = authenticated(&state, &headers).await?;
    let contacts: Vec<Document> = state.db.collection::<Document>(CONTACTS)
        .find(doc! {"owner": &owner, "added": true, "blocked": {"$ne": true}})
        .projection(doc! {"peer": 1}).limit(257).await.map_err(storage)?
        .try_collect().await.map_err(storage)?;
    let keys = state.db.collection::<Document>(KEYS);
    let mut recipients = Vec::new();
    for contact in contacts {
        let peer = string(&contact, "peer");
        if peer.is_empty() || !may_send(&state, &owner, &peer).await? { continue; }
        if let Some(row) = keys.find_one(doc! {"_id": &peer}).await.map_err(storage)? {
            let kem = string(&row, "kem");
            if hex_len(&kem, 2368) {
                recipients.push(json!({"lns": peer, "kem_pk": kem}));
            }
        }
        if recipients.len() == MAX_RECIPIENTS { break; }
    }
    Ok(reply(json!(recipients)))
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Wrap {
    #[serde(rename = "for")]
    recipient: String,
    kem: String,
    iv: String,
    ct: String,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct NewStatus {
    ct: String,
    iv: String,
    wraps: Vec<Wrap>,
    has_image: bool,
}

pub async fn create(State(state): State<AppState>, headers: HeaderMap, Json(request): Json<NewStatus>) -> Result {
    let owner = authenticated(&state, &headers).await?;
    if !(32..=MAX_CIPHERTEXT_HEX).contains(&request.ct.len()) || request.ct.len() % 2 != 0
        || !hex_len(&request.ct, request.ct.len()) || !hex_len(&request.iv, 24)
        || !(1..=MAX_RECIPIENTS + 1).contains(&request.wraps.len())
    {
        return Err(bad("Stato cifrato non valido o troppo grande."));
    }

    let mut recipients = HashSet::new();
    let mut wraps = Vec::with_capacity(request.wraps.len());
    for wrap in request.wraps {
        let peer = address(&wrap.recipient)?;
        if !recipients.insert(peer.clone()) || !hex_len(&wrap.kem, 2176)
            || !hex_len(&wrap.iv, 24) || !hex_len(&wrap.ct, 96)
        {
            return Err(bad("Busta dello stato non valida."));
        }
        if peer != owner && !may_send(&state, &owner, &peer).await? {
            return Err(error(StatusCode::FORBIDDEN, "Lo stato può essere condiviso con i contatti reciproci."));
        }
        wraps.push(doc! {"for": peer, "kem": wrap.kem, "iv": wrap.iv, "ct": wrap.ct});
    }
    if !recipients.contains(&owner) { return Err(bad("Manca la busta dell'autore.")); }

    let collection = state.db.collection::<Document>(COLLECTION);
    let active = collection.count_documents(doc! {"author": &owner, "expires_at": {"$gt": DateTime::now()}})
        .limit(12).await.map_err(storage)?;
    if active >= 12 { return Err(error(StatusCode::TOO_MANY_REQUESTS, "Hai già 12 stati attivi.")); }
    let id = ObjectId::new();
    collection.insert_one(doc! {
        "_id": id, "author": owner, "ct": request.ct, "iv": request.iv,
        "has_image": request.has_image, "wraps": wraps,
        "audience": recipients.into_iter().collect::<Vec<_>>(),
        "created_at": crate::utc_iso(),
        "expires_at": DateTime::from_millis(DateTime::now().timestamp_millis() + 86_400_000),
    }).await.map_err(storage)?;
    Ok(reply(json!({"status_id": id.to_hex()})))
}

fn visible_wrap<'a>(row: &'a Document, viewer: &str) -> Option<&'a Document> {
    row.get_array("wraps").ok()?.iter().filter_map(|item| item.as_document())
        .find(|wrap| wrap.get_str("for").ok() == Some(viewer))
}

pub(super) fn viewer_slot(owner: &str) -> String {
    hex::encode(Sha256::digest(owner.as_bytes()))
}

pub async fn list(State(state): State<AppState>, headers: HeaderMap) -> Result<Reply> {
    let owner = authenticated(&state, &headers).await?;
    let rows: Vec<Document> = state.db.collection::<Document>(COLLECTION)
        .find(doc! {"audience": &owner, "expires_at": {"$gt": DateTime::now()}})
        .sort(doc! {"_id": -1}).limit(20).await.map_err(storage)?
        .try_collect().await.map_err(storage)?;
    let slot = viewer_slot(&owner);
    let mut result = Vec::new();
    for row in rows {
        let author = string(&row, "author");
        let mine = author == owner;
        if !mine && !may_send(&state, &owner, &author).await? { continue; }
        let Some(wrap) = visible_wrap(&row, &owner) else { continue };
        let reactions = row.get_document("reactions").ok();
        let my_reaction = reactions.and_then(|r| r.get_document(&slot).ok())
            .map(|r| string(r, "emoji")).unwrap_or_default();
        let views: Vec<_> = if mine {
            row.get_document("views").ok().into_iter().flat_map(|v| v.values())
                .filter_map(|v| v.as_str()).map(|by| json!({"by": by})).collect()
        } else { Vec::new() };
        let public_reactions: Vec<_> = if mine {
            reactions.into_iter().flat_map(|r| r.values()).filter_map(|v| v.as_document())
                .map(|r| json!({"by": string(r, "by"), "emoji": string(r, "emoji")})).collect()
        } else { Vec::new() };
        result.push(json!({
            "status_id": row.get_object_id("_id").map(|id| id.to_hex()).unwrap_or_default(),
            "author": author, "mine": mine, "created_at": string(&row, "created_at"),
            "iv": string(&row, "iv"), "ct": string(&row, "ct"),
            "wrap": {"kem": string(wrap, "kem"), "iv": string(wrap, "iv"), "ct": string(wrap, "ct")},
            "my_reaction": my_reaction, "views_count": views.len(), "views": views, "reactions": public_reactions
        }));
    }
    Ok(reply(json!(result)))
}

pub async fn delete(State(state): State<AppState>, headers: HeaderMap, Path(raw): Path<String>) -> Result {
    let owner = authenticated(&state, &headers).await?;
    let mut filter = live(id(&raw)?);
    filter.insert("author", owner);
    let deleted = state.db.collection::<Document>(COLLECTION).delete_one(filter).await.map_err(storage)?;
    if deleted.deleted_count != 1 { return Err(unavailable()); }
    Ok(reply(json!({"ok": true})))
}

async fn viewer_filter(state: &AppState, owner: &str, raw: &str) -> Result<Document> {
    let mut filter = live(id(raw)?);
    filter.insert("audience", owner);
    filter.insert("author", doc! {"$ne": owner});
    let item = state.db.collection::<Document>(COLLECTION).find_one(filter.clone())
        .projection(doc! {"author": 1}).await.map_err(storage)?.ok_or_else(unavailable)?;
    let author = string(&item, "author");
    if !may_send(state, owner, &author).await? { return Err(unavailable()); }
    Ok(filter)
}

pub async fn seen(State(state): State<AppState>, headers: HeaderMap, Path(raw): Path<String>) -> Result {
    let owner = authenticated(&state, &headers).await?;
    let filter = viewer_filter(&state, &owner, &raw).await?;
    let mut changes = Document::new();
    changes.insert(format!("views.{}", viewer_slot(&owner)), owner);
    state.db.collection::<Document>(COLLECTION).update_one(filter, doc! {"$set": changes}).await.map_err(storage)?;
    Ok(reply(json!({"ok": true})))
}

#[derive(Deserialize)]
pub struct Reaction {
    emoji: String,
}

pub async fn react(State(state): State<AppState>, headers: HeaderMap, Path(raw): Path<String>, Json(reaction): Json<Reaction>) -> Result {
    if !matches!(reaction.emoji.as_str(), "" | "👍" | "❤️" | "😮" | "🎉") {
        return Err(bad("Reazione non valida."));
    }
    let owner = authenticated(&state, &headers).await?;
    let filter = viewer_filter(&state, &owner, &raw).await?;
    let mut changes = Document::new();
    let field = format!("reactions.{}", viewer_slot(&owner));
    let update = if reaction.emoji.is_empty() {
        changes.insert(field, "");
        doc! {"$unset": changes}
    } else {
        changes.insert(field, doc! {"by": owner, "emoji": reaction.emoji});
        doc! {"$set": changes}
    };
    state.db.collection::<Document>(COLLECTION).update_one(filter, update).await.map_err(storage)?;
    Ok(reply(json!({"ok": true})))
}
