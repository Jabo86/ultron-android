//! Short-lived capability-addressed WebRTC signaling and authenticated TURN credentials.
use super::{authenticated, bad, error, hex_len, reply, storage, Result};
use crate::AppState;
use axum::{extract::State, http::{HeaderMap, StatusCode}, Json};
use base64::{engine::general_purpose::STANDARD, Engine};
use bson::{doc, DateTime, Document};
use futures::TryStreamExt;
use hmac::{Hmac, Mac};
use mongodb::IndexModel;
use serde::Deserialize;
use serde_json::{json, Value};
use sha1::Sha1;
use sha2::{Digest, Sha256};
use std::time::Duration;

const SIGNALS: &str = "ultron_mobile_call_signals";
const INVITE_MS: i64 = 60_000;
const CALL_MS: i64 = 7_200_000;
const MAX_ICE: i64 = 64;
const TURN_SECONDS: i64 = 7_200;

pub async fn ensure_indexes(db: &mongodb::Database) -> mongodb::error::Result<()> {
    db.collection::<Document>(SIGNALS).create_index(
        IndexModel::builder().keys(doc! {"expires_at": 1})
            .options(mongodb::options::IndexOptions::builder().expire_after(Duration::ZERO).build())
            .build(),
    ).await?;
    Ok(())
}

fn capability(raw: &str) -> Result<String> {
    if !hex_len(raw, 32) { return Err(bad("Canale chiamata non valido.")); }
    Ok(hex::encode(Sha256::digest(raw.to_ascii_lowercase().as_bytes())))
}

#[derive(Deserialize)]
pub struct Put {
    rid: String,
    slot: String,
    data: Value,
}

fn sealed(value: &Value) -> bool {
    let field = |key: &str| value.get(key).and_then(Value::as_str).unwrap_or("");
    let ct = field("ct");
    hex_len(field("kem"), 2176) && hex_len(field("iv"), 24)
        && (32..=65_536).contains(&ct.len()) && ct.len() % 2 == 0 && hex_len(ct, ct.len())
}

pub async fn put(State(state): State<AppState>, headers: HeaderMap, Json(req): Json<Put>) -> Result {
    let owner = authenticated(&state, &headers).await?;
    let key = capability(&req.rid)?;
    let expiry = |ms| DateTime::from_millis(DateTime::now().timestamp_millis() + ms);
    let stored = state.db.collection::<Document>(SIGNALS);
    let data = bson::to_bson(&req.data).map_err(|_| bad("Segnale non valido."))?;
    if req.slot == "ping" && sealed(&req.data) {
        stored.update_one(doc! {"_id": key}, doc! {"$set": {"ping": data, "caller": owner, "expires_at": expiry(INVITE_MS)}})
            .upsert(true).await.map_err(storage)?;
    } else {
        let mut changes = doc! {"$setOnInsert": {"expires_at": expiry(CALL_MS)}};
        match req.slot.as_str() {
            "answer" if sealed(&req.data) => { changes.insert("$set", doc! {"answer": data}); }
            "bye" => {
                let mut terminal = doc! {"bye": true};
                if req.data.get("reason").and_then(Value::as_str) == Some("declined") {
                    terminal.insert("reason", "declined");
                }
                changes.insert("$set", terminal);
            }
            "ice_c" | "ice_e" => {
                let candidate = req.data.get("candidate").and_then(Value::as_str).unwrap_or("");
                // Hosted calls use TURN. Reject host and server-reflexive addresses.
                if candidate.len() > 1024 || !candidate.split_ascii_whitespace().collect::<Vec<_>>()
                    .windows(2).any(|part| part == ["typ", "relay"])
                    || req.data.to_string().len() > 2048
                { return Err(bad("Candidato TURN non valido.")); }
                // Keep a bounded append-only sequence so the client's offset stays valid.
                stored.update_one(doc! {"_id": &key}, doc! {"$setOnInsert": {"expires_at": expiry(CALL_MS)}})
                    .upsert(true).await.map_err(storage)?;
                let mut filter = doc! {"_id": key, "expires_at": {"$gt": DateTime::now()}, "bye": {"$ne": true}};
                filter.insert(format!("{}.{}", req.slot, MAX_ICE - 1), doc! {"$exists": false});
                let mut append = Document::new();
                append.insert(req.slot, data);
                stored.update_one(filter, doc! {"$push": append}).await.map_err(storage)?;
                return Ok(reply(json!({"ok": true})));
            }
            _ => return Err(bad("Segnale chiamata non valido.")),
        }
        stored.update_one(doc! {"_id": key}, changes).upsert(true).await.map_err(storage)?;
    }
    Ok(reply(json!({"ok": true})))
}

#[derive(Deserialize)]
pub struct Get {
    rid: String,
    #[serde(default)]
    ice_c_from: usize,
    #[serde(default)]
    ice_e_from: usize,
}

fn candidates(row: &Document, key: &str, offset: usize) -> Vec<Value> {
    row.get_array(key).ok().into_iter().flatten().skip(offset)
        .filter_map(|value| bson::from_bson(value.clone()).ok()).collect()
}

pub async fn get(State(state): State<AppState>, headers: HeaderMap, Json(req): Json<Get>) -> Result {
    authenticated(&state, &headers).await?;
    let row = state.db.collection::<Document>(SIGNALS)
        .find_one(doc! {"_id": capability(&req.rid)?, "expires_at": {"$gt": DateTime::now()}})
        .await.map_err(storage)?;
    let Some(row) = row else { return Ok(reply(json!({"found": false}))); };
    let signal = |key| row.get(key).cloned().and_then(|v| bson::from_bson::<Value>(v).ok());
    Ok(reply(json!({
        "found": true, "ping": signal("ping"), "answer": signal("answer"),
        "bye": row.get_bool("bye").unwrap_or(false), "reason": signal("reason"),
        "ice_c": candidates(&row, "ice_c", req.ice_c_from),
        "ice_e": candidates(&row, "ice_e", req.ice_e_from),
    })))
}

#[derive(Deserialize)]
pub struct Poll {
    rids: Vec<String>,
}

pub async fn poll(State(state): State<AppState>, headers: HeaderMap, Json(req): Json<Poll>) -> Result {
    authenticated(&state, &headers).await?;
    if req.rids.len() > 128 { return Err(bad("Troppi canali di chiamata.")); }
    let hashed = req.rids.iter().map(|rid| capability(rid)).collect::<Result<Vec<_>>>()?;
    let rows: Vec<Document> = state.db.collection::<Document>(SIGNALS)
        .find(doc! {"_id": {"$in": hashed.clone()}, "expires_at": {"$gt": DateTime::now()}, "ping": {"$exists": true}})
        .projection(doc! {"_id": 1}).await.map_err(storage)?.try_collect().await.map_err(storage)?;
    let hits: Vec<_> = req.rids.into_iter().zip(hashed)
        .filter_map(|(rid, hash)| rows.iter().any(|row| row.get_str("_id").ok() == Some(hash.as_str())).then_some(rid))
        .collect();
    Ok(reply(json!({"hits": hits})))
}

#[derive(Deserialize)]
pub struct Ring {
    to: String,
    rid: String,
}

pub async fn ring(State(state): State<AppState>, headers: HeaderMap, Json(req): Json<Ring>) -> Result {
    let owner = authenticated(&state, &headers).await?;
    let peer = super::address(&req.to)?;
    if !super::may_send(&state, &owner, &peer).await? {
        return Err(error(StatusCode::FORBIDDEN, "Chiamata non autorizzata."));
    }
    let exists = state.db.collection::<Document>(SIGNALS)
        .find_one(doc! {"_id": capability(&req.rid)?, "ping": {"$exists": true}, "caller": owner, "expires_at": {"$gt": DateTime::now()}})
        .projection(doc! {"_id": 1}).await.map_err(storage)?.is_some();
    if !exists { return Err(error(StatusCode::NOT_FOUND, "Invito scaduto.")); }
    let now = chrono::Utc::now().timestamp();
    let result = state.db.collection::<Document>("ultron_wake_devices")
        .update_many(doc! {"owner": peer, "expires_at": {"$gt": now}},
            doc! {"$set": {"call_rid": req.rid, "call_until": now + INVITE_MS / 1000}}).await.map_err(storage)?;
    Ok(reply(json!({"ok": true, "devices": result.matched_count})))
}

fn turn_password(secret: &str, username: &str) -> String {
    let mut mac = Hmac::<Sha1>::new_from_slice(secret.as_bytes()).expect("HMAC accepts any key length");
    mac.update(username.as_bytes());
    STANDARD.encode(mac.finalize().into_bytes())
}

pub async fn turn(State(state): State<AppState>, headers: HeaderMap) -> Result {
    let owner = authenticated(&state, &headers).await?;
    let secret = std::env::var("ULTRON_TURN_SECRET").ok().filter(|s| hex_len(s, 64));
    let host = std::env::var("ULTRON_TURN_HOST").ok()
        .and_then(|s| s.parse::<std::net::Ipv4Addr>().ok());
    let (Some(secret), Some(host)) = (secret, host) else {
        return Err(error(StatusCode::SERVICE_UNAVAILABLE, "Relay TURN non configurato."));
    };
    let expiry = chrono::Utc::now().timestamp() + TURN_SECONDS;
    let pseudonym = hex::encode(Sha256::digest(owner.as_bytes()));
    let username = format!("{expiry}:{}", &pseudonym[..24]);
    let credential = turn_password(&secret, &username);
    Ok(reply(json!({
        "urls": [format!("turn:{host}:3478?transport=udp"), format!("turn:{host}:3478?transport=tcp")],
        "username": username, "credential": credential, "expires_at": expiry
    })))
}
