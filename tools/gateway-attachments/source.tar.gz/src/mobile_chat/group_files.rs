//! Group-scoped opaque blobs. Publishing requires a committed MLS event.
use super::{error, group_control, groups, hex_len, purge::durable, reply, storage, AppState, Result};
use axum::{body::{Body, Bytes}, extract::{Path, Query, State}, http::{header, HeaderMap, StatusCode}, response::{IntoResponse, Response}};
use bson::{doc, spec::BinarySubtype, Binary, DateTime, Document};
use serde_json::json;

pub(super) const STORE: &str = "ultron_mls_files";
const MAX_FILE: usize = 4 * 1024 * 1024 + 16;
const MAX_PLAIN: usize = 50 * 1024 * 1024;
const CHUNK: usize = 4 * 1024 * 1024;
#[derive(Default, serde::Deserialize)]
pub struct FileParts { index: Option<usize>, parts: Option<usize>, size: Option<usize> }
fn frame(index: usize, parts: usize, size: usize, length: usize) -> bool {
    size > 0 && size <= MAX_PLAIN && parts == size.div_ceil(CHUNK) && index < parts &&
    length == (size - index * CHUNK).min(CHUNK) + 16
}

fn absent() -> super::Error { error(StatusCode::NOT_FOUND, "Allegato del gruppo non disponibile.") }

pub async fn upload(State(state): State<AppState>, headers: HeaderMap, Path((raw, file)): Path<(String, String)>, Query(params): Query<FileParts>, bytes: Bytes) -> Result {
    let owner = groups::owner(&state, &headers).await?;
    let id = groups::group_id(&raw)?;
    if !group_control::enabled() || !hex_len(&file, 32) { return Err(absent()); }
    if bytes.len() <= 16 || bytes.len() > MAX_FILE {
        return Err(error(StatusCode::PAYLOAD_TOO_LARGE, "Blocco non valido: allegato massimo 50 MB."));
    }
    let _guard = groups::WRITE.lock().await;
    let group = group_control::live_group(&state, id).await?;
    if !group_control::visible(&group, &owner) || group_control::muted(&group, &owner)
        || group_control::pending_rotation(&group) { return Err(group_control::denied()); }
    let files = durable(&state, STORE);
    if params.index.is_some() || params.parts.is_some() || params.size.is_some() {
        let (Some(index), Some(parts), Some(size)) = (params.index,params.parts,params.size) else { return Err(absent()); };
        if !frame(index,parts,size,bytes.len()) { return Err(error(StatusCode::PAYLOAD_TOO_LARGE,"Allegato massimo 50 MB; blocchi non validi.")); }
        let epoch=group.get_i64("epoch").map_err(|_|absent())?;
        let expires=DateTime::from_millis(DateTime::now().timestamp_millis()+3_600_000);
        let prior=files.find_one(doc!{"_id":&file}).await.map_err(storage)?;
        if let Some(row)=prior.as_ref() {
            if row.get_str("group").ok()!=Some(id) || row.get_str("owner").ok()!=Some(owner.as_str()) ||
                row.get_i64("epoch").ok()!=Some(epoch) || row.get_i64("parts").ok()!=Some(parts as i64) || row.get_i64("plain_size").ok()!=Some(size as i64) { return Err(absent()); }
        } else {
            if index!=0 || files.count_documents(doc!{"group":id,"part":{"$exists":false}}).limit(128).await.map_err(storage)? >=128 { return Err(absent()); }
            files.insert_one(doc!{"_id":&file,"group":id,"owner":&owner,"epoch":epoch,"expires":expires,"chunked":true,
                "parts":parts as i64,"plain_size":size as i64,"length":(size+parts*16) as i64,"ready":false}).await.map_err(storage)?;
        }
        let part_id=format!("{}:{}",file,index);
        if let Some(row)=files.find_one(doc!{"_id":&part_id}).await.map_err(storage)? {
            if row.get_binary_generic("data").map(|v|v.as_slice()).ok()!=Some(bytes.as_ref()) { return Err(error(StatusCode::CONFLICT,"Blocco già caricato con dati diversi.")); }
        } else {
            if prior.as_ref().is_some_and(|row|row.contains_key("seq")) { return Err(absent()); }
            files.insert_one(doc!{"_id":part_id,"file":&file,"part":index as i64,"group":id,"owner":&owner,"epoch":epoch,"expires":expires,
                "data":Binary{subtype:BinarySubtype::Generic,bytes:bytes.to_vec()}}).await.map_err(storage)?;
        }
        let ready=files.count_documents(doc!{"file":&file,"group":id}).await.map_err(storage)? ==parts as u64;
        if ready { files.update_one(doc!{"_id":&file},doc!{"$set":{"ready":true}}).await.map_err(storage)?; }
        return Ok(reply(json!({"id":file,"ready":ready})));
    }
    if let Some(row) = files.find_one(doc! {"_id": &file}).await.map_err(storage)? {
        if row.get_str("group").ok() == Some(id) && row.get_str("owner").ok() == Some(owner.as_str())
            && row.get_binary_generic("data").is_ok_and(|prior| prior.as_slice() == bytes.as_ref()) {
            return Ok(reply(json!({"id": file})));
        }
        return Err(absent());
    }
    if files.count_documents(doc! {"group": id, "part": {"$exists": false}}).limit(128).await.map_err(storage)? >= 128 {
        return Err(error(StatusCode::TOO_MANY_REQUESTS, "Limite di allegati del gruppo raggiunto."));
    }
    let epoch = group.get_i64("epoch").map_err(|_| absent())?;
    let expires = DateTime::from_millis(DateTime::now().timestamp_millis() + 3_600_000);
    files.insert_one(doc! {"_id": &file, "group": id, "owner": owner, "epoch": epoch, "expires": expires,
        "data": Binary { subtype: BinarySubtype::Generic, bytes: bytes.to_vec() }, "length": bytes.len() as i64})
        .await.map_err(storage)?;
    Ok(reply(json!({"id": file})))
}

pub(super) async fn available(state: &AppState, group: &str, owner: &str, file: &str, epoch: i64) -> Result<()> {
    if !hex_len(file, 32) { return Err(absent()); }
    if durable(state, STORE).find_one(doc! {"_id": file, "group": group, "owner": owner, "epoch": epoch,
        "$or": [{"chunked": {"$ne": true}}, {"ready": true}], "seq": {"$exists": false}, "expires": {"$gt": DateTime::now()}}).projection(doc! {"_id": 1})
        .await.map_err(storage)?.is_none() { return Err(absent()); }
    Ok(())
}

pub(super) async fn bind(state: &AppState, id: &str, file: &str, seq: i64) -> Result<()> {
    // A process restart may re-run this exact reservation.
    durable(state, STORE).update_many(doc! {"group":id,"$and":[{"$or":[{"_id":file},{"file":file}]},{"$or":[{"seq":{"$exists":false}},{"seq":seq}]}]},
        doc! {"$set": {"seq": seq}, "$unset": {"expires": ""}}).await.map_err(storage)?;
    // A staged file can expire during a prolonged outage. The MLS stream must
    // still advance; the client can report this one file as unavailable.
    Ok(())
}

pub async fn download(State(state): State<AppState>, headers: HeaderMap, Path((raw, file)): Path<(String, String)>) -> Result<Response> {
    let owner = groups::owner(&state, &headers).await?;
    let id = groups::group_id(&raw)?;
    if !group_control::enabled() || !hex_len(&file, 32) { return Err(absent()); }
    let _guard = groups::WRITE.lock().await;
    let group = group_control::live_group(&state, id).await?;
    if !group_control::visible(&group, &owner) { return Err(absent()); }
    let since = groups::since(&group, &owner).ok_or_else(absent)?;
    let last = group.get_i64("seq").map_err(|_| absent())?;
    let row = durable(&state, STORE).find_one(doc! {"_id": file, "group": id, "seq": {"$gte": since, "$lte": last}})
        .await.map_err(storage)?.ok_or_else(absent)?;
    let seq = row.get_i64("seq").map_err(|_| absent())?;
    if group.get_array("hidden").is_ok_and(|values| values.iter().any(|value| value.as_i64() == Some(seq))) {
        return Err(absent());
    }
    if row.get_bool("chunked").unwrap_or(false) {
        use futures::StreamExt;
        let length=row.get_i64("length").map_err(|_|absent())?;
        let cursor=durable(&state,STORE).find(doc!{"file":&file,"group":id}).sort(doc!{"part":1}).batch_size(1).await.map_err(storage)?;
        let stream=cursor.map(|result|{
            let item=result.map_err(std::io::Error::other)?;
            let data=item.get_binary_generic("data").map_err(std::io::Error::other)?;
            Ok::<_,std::io::Error>(Bytes::copy_from_slice(data))
        });
        return Ok(([(header::CONTENT_TYPE,"application/octet-stream".into()),(header::CACHE_CONTROL,"no-store".into()),(header::CONTENT_LENGTH,length.to_string())],Body::from_stream(stream)).into_response());
    }
    let bytes = row.get_binary_generic("data").map_err(|_| absent())?.clone();
    Ok(([(header::CONTENT_TYPE, "application/octet-stream"), (header::CACHE_CONTROL, "no-store")], bytes).into_response())
}

pub(super) async fn indexes(db: &mongodb::Database) -> mongodb::error::Result<()> {
    use mongodb::{IndexModel, options::IndexOptions};
    let store = db.collection::<Document>(STORE);
    store.create_index(IndexModel::builder().keys(doc! {"expires": 1})
        .options(IndexOptions::builder().expire_after(std::time::Duration::ZERO).build()).build()).await?;
    store.create_index(IndexModel::builder().keys(doc! {"group": 1}).build()).await?;
    Ok(())
}

#[cfg(test)]
mod tests {
 use super::*;
 #[test] fn accepts_exact_limit_and_last_partial_chunk(){let n=MAX_PLAIN.div_ceil(CHUNK);assert!(frame(0,n,MAX_PLAIN,CHUNK+16));assert!(frame(n-1,n,MAX_PLAIN,(MAX_PLAIN-(n-1)*CHUNK)+16));}
 #[test] fn rejects_over_limit_and_malformed_frames(){let n=MAX_PLAIN.div_ceil(CHUNK);assert!(!frame(0,n,MAX_PLAIN+1,CHUNK+16));assert!(!frame(n,n,MAX_PLAIN,16));assert!(!frame(0,n-1,MAX_PLAIN,CHUNK+16));assert!(!frame(0,n,MAX_PLAIN,CHUNK+15));}
}
