// A purge changes the pair's generation before deleting any content. The durable
// pending flag lets the request resume after a gateway restart or write failure.
// The pilot runs one writable gateway against its standalone MongoDB database.
use super::{address, authenticated, bad, error, pair_id, reply, storage, AppState, Result, MESSAGES, MESSAGE_EVENTS};
use axum::{extract::{Path, Query, State}, http::{HeaderMap, StatusCode}};
use bson::{doc, oid::ObjectId, Document};
use futures::TryStreamExt;
use mongodb::options::{CollectionOptions, WriteConcern};
use serde::Deserialize;
use serde_json::json;
use tokio::sync::RwLock;

const THREADS: &str = "ultron_mobile_thread_generations";
const RECEIPTS: &str = "ultron_mobile_purge_receipts";
pub(super) static WRITES: RwLock<()> = RwLock::const_new(());

pub async fn ensure_indexes(db: &mongodb::Database) -> mongodb::error::Result<()> {
    db.collection::<Document>(RECEIPTS).create_index(mongodb::IndexModel::builder()
        .keys(doc! {"conv_id": 1, "generation": 1, "_id": 1}).build()).await?;
    Ok(())
}

pub(super) fn durable(state: &AppState, name: &str) -> mongodb::Collection<Document> {
    state.db.collection_with_options(name, CollectionOptions::builder()
        .write_concern(WriteConcern::builder().journal(true).build()).build())
}

pub(super) fn enabled() -> bool {
    std::env::var("ULTRON_CHAT_PURGE").is_ok_and(|value| value == "1")
}

async fn thread(state: &AppState, conversation: &str) -> Result<Option<Document>> {
    state.db.collection::<Document>(THREADS).find_one(doc! {"_id": conversation})
        .await.map_err(storage)
}

fn generation(row: Option<&Document>) -> i64 {
    row.and_then(|row| row.get_i64("generation").ok()).unwrap_or(0)
}

fn pending(row: Option<&Document>) -> bool {
    row.and_then(|row| row.get_bool("pending").ok()) == Some(true)
}

fn stale() -> super::Error {
    error(StatusCode::CONFLICT, "La chat è stata eliminata o è in eliminazione. Aggiorna la conversazione.")
}

pub(super) async fn require_generation(state: &AppState, conversation: &str, expected: i64) -> Result<()> {
    if !enabled() { return Ok(()); }
    let row = thread(state, conversation).await?;
    if pending(row.as_ref()) || generation(row.as_ref()) != expected { return Err(stale()); }
    Ok(())
}

#[derive(Deserialize)]
pub struct ReceiptQuery {
    after: Option<String>,
    from: Option<i64>,
}

pub async fn status(
    State(state): State<AppState>,
    headers: HeaderMap,
    Path(raw_peer): Path<String>,
    Query(query): Query<ReceiptQuery>,
) -> Result {
    if !enabled() { return Err(error(StatusCode::NOT_FOUND, "Eliminazione definitiva non disponibile.")); }
    let owner = authenticated(&state, &headers).await?;
    let peer = address(&raw_peer)?;
    if owner == peer { return Err(bad("Conversazione non valida.")); }
    let conversation = pair_id(&owner, &peer);
    let _guard = WRITES.read().await;
    let row = thread(&state, &conversation).await?;
    let current = generation(row.as_ref());
    if pending(row.as_ref()) { return Err(stale()); }
    let Some(start) = query.from else {
        return Ok(reply(json!({"generation": current, "conv_id": conversation})));
    };
    if start < 0 || start > current { return Err(bad("Generazione non valida.")); }
    let mut filter = doc! {"conv_id": &conversation, "generation": {"$gt": start, "$lte": current}};
    if let Some(after) = query.after {
        filter.insert("_id", doc! {"$gt": ObjectId::parse_str(after).map_err(|_| bad("Cursore non valido."))?});
    }
    let records: Vec<Document> = state.db.collection::<Document>(RECEIPTS)
        .find(filter).sort(doc! {"_id": 1}).limit(201).await.map_err(storage)?
        .try_collect().await.map_err(storage)?;
    let items = records.iter().take(200).filter_map(|entry| {
        let id = entry.get_object_id("_id").ok()?.to_hex();
        if entry.get_bool("attachment").ok() == Some(true) { return Some(json!({"id": id, "attachment": true})); }
        let sender = entry.get_str("sender").ok()?;
        let send_id = (sender == owner).then(|| entry.get_str("send_id").ok()).flatten();
        Some(json!({"id": id, "sender": sender, "send_id": send_id}))
    }).collect::<Vec<_>>();
    let next = (records.len() > 200).then(|| records[199].get_object_id("_id").ok().map(|id| id.to_hex())).flatten();
    Ok(reply(json!({"generation": current, "conv_id": conversation, "items": items, "next": next})))
}

#[derive(Deserialize)]
pub struct PurgeQuery {
    generation: i64,
}

pub async fn delete(
    State(state): State<AppState>,
    headers: HeaderMap,
    Path(raw_peer): Path<String>,
    Query(req): Query<PurgeQuery>,
) -> Result {
    if !enabled() { return Err(error(StatusCode::NOT_FOUND, "Eliminazione definitiva non disponibile.")); }
    let owner = authenticated(&state, &headers).await?;
    let peer = address(&raw_peer)?;
    if peer == owner || !(0..9_007_199_254_740_990).contains(&req.generation) {
        return Err(bad("Conversazione non valida."));
    }
    let conversation = pair_id(&owner, &peer);
    let _guard = WRITES.write().await;
    let row = thread(&state, &conversation).await?;
    let current = generation(row.as_ref());
    let next = req.generation + 1;
    let threads = durable(&state, THREADS);
    let messages = durable(&state, MESSAGES);
    let scope = doc! {"conv_id": &conversation, "participants": {"$all": [&owner, &peer]}};
    if current == req.generation && !pending(row.as_ref()) {
        if messages.find_one(scope.clone()).projection(doc! {"_id": 1}).await.map_err(storage)?.is_none() {
            return Err(error(StatusCode::NOT_FOUND, "Conversazione non disponibile."));
        }
        threads.update_one(doc! {"_id": &conversation}, doc! {"$set": {"generation": next, "pending": true}})
            .upsert(true).await.map_err(storage)?;
    } else if current != next {
        return Err(stale());
    } else if !pending(row.as_ref()) {
        return Ok(reply(json!({"purged": true, "generation": next, "conv_id": conversation})));
    }

    let receipts = durable(&state, RECEIPTS);
    let mut cursor = messages.find(scope.clone()).projection(doc! {"from_lns": 1, "ratchet_send_id": 1})
        .await.map_err(storage)?;
    while let Some(record) = cursor.try_next().await.map_err(storage)? {
        let Ok(id) = record.get_object_id("_id") else { continue };
        let Ok(sender) = record.get_str("from_lns") else { continue };
        receipts.update_one(doc! {"_id": id}, doc! {"$setOnInsert": {
            "conv_id": &conversation, "generation": next, "sender": sender,
            "send_id": record.get_str("ratchet_send_id").unwrap_or(""),
        }}).upsert(true).await.map_err(storage)?;
    }
    super::blobs::purge_pair(&state, &owner, &peer, &conversation, next, &receipts).await?;
    messages.delete_many(scope).await.map_err(storage)?;
    threads.update_one(doc! {"_id": &conversation, "generation": next, "pending": true},
        doc! {"$set": {"pending": false}}).await.map_err(storage)?;
    let _ = MESSAGE_EVENTS.send(conversation.clone());
    Ok(reply(json!({"purged": true, "generation": next, "conv_id": conversation})))
}
