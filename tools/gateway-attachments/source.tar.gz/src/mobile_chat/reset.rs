//! Account reset capabilities for personal ULTRON accounts.
use super::{authenticated, error, hex_len, reply, storage, Result};
use crate::AppState;
use axum::{extract::State, http::{HeaderMap, StatusCode}, Json};
use bson::{doc, Document};
use futures::TryStreamExt;
use serde::Deserialize;
use serde_json::json;
use sha2::{Digest, Sha256};

#[derive(Deserialize)]
pub struct Capability {
    token: String,
}

fn token_hash(token: &str) -> Result<String> {
    if !hex_len(token, 64) {
        return Err(error(StatusCode::BAD_REQUEST, "Token di ripristino non valido."));
    }
    let bytes = hex::decode(token)
        .map_err(|_| error(StatusCode::BAD_REQUEST, "Token di ripristino non valido."))?;
    Ok(hex::encode(Sha256::digest(bytes)))
}

pub async fn arm(State(state): State<AppState>, headers: HeaderMap, Json(request): Json<Capability>) -> Result {
    let owner = authenticated(&state, &headers).await?;
    let hash = token_hash(&request.token)?;
    let outcome = state.db.collection::<Document>("lns").update_one(
        doc! {"_id": &owner, "lns_name": &owner, "status": "ACTIVE", "role": "operator",
              "ultron_public_key_hex": {"$exists": true}},
        doc! {"$addToSet": {"reset_hashes": hash}},
    ).await.map_err(storage)?;
    if outcome.matched_count == 0 {
        return Err(error(StatusCode::NOT_FOUND, "Ripristino remoto non disponibile per questo account."));
    }
    Ok(reply(json!({"ok": true})))
}

pub async fn delete_account(State(state): State<AppState>, headers: HeaderMap) -> Result {
    let owner = authenticated(&state, &headers).await?;
    let result = state.db.collection::<Document>("lns").update_one(
        doc! {"_id": &owner, "lns_name": &owner, "status": "ACTIVE", "role": "operator",
              "ultron_public_key_hex": {"$exists": true}},
        doc! {"$set": {"status": "DELETING"}},
    ).await.map_err(storage)?;
    if result.matched_count == 0 {
        return Err(error(StatusCode::NOT_FOUND, "Cancellazione non disponibile per questo account."));
    }
    erase(&state, &owner).await.map_err(storage)?;
    Ok(reply(json!({"ok": true})))
}

pub async fn wipe(State(state): State<AppState>, Json(request): Json<Capability>) -> Result {
    let hash = token_hash(&request.token)?;
    let accounts = state.db.collection::<Document>("lns");
    let filter = doc! {"reset_hashes": hash, "status": {"$in": ["ACTIVE", "DELETING"]}};
    let Some(account) = accounts.find_one_and_update(
        filter, doc! {"$set": {"status": "DELETING"}},
    ).projection(doc! {"_id": 1}).await.map_err(storage)? else {
        return Err(error(StatusCode::NOT_FOUND, "Ripristino non disponibile."));
    };
    let owner = account.get_str("_id")
        .map_err(|_| error(StatusCode::SERVICE_UNAVAILABLE, "Ripristino non disponibile."))?;
    erase(&state, owner).await.map_err(storage)?;
    Ok(reply(json!({"ok": true})))
}

async fn erase(state: &AppState, owner: &str) -> mongodb::error::Result<()> {
    let db = &state.db;
    let between = doc! {"$or": [{"from_lns": owner}, {"to_lns": owner}]};
    for (name, filter) in [
        ("ultron_mobile_messages", between.clone()),
        ("pulse_messages", between),
        ("ultron_mobile_contact_requests", doc! {"members": owner}),
        ("ultron_mobile_contacts", doc! {"$or": [{"owner": owner}, {"peer": owner}]}),
        ("ultron_mobile_keys", doc! {"_id": owner}),
        ("ultron_wake_devices", doc! {"owner": owner}),
        ("ultron_mobile_call_signals", doc! {"caller": owner}),
        ("auth_challenges", doc! {"lns_name": owner}),
        ("access_log", doc! {"lns": owner}),
        ("ultron_mobile_status", doc! {"author": owner}),
    ] {
        db.collection::<Document>(name).delete_many(filter).await?;
    }

    let slot = super::status::viewer_slot(owner);
    let mut remove = doc! {};
    remove.insert(format!("views.{slot}"), "");
    remove.insert(format!("reactions.{slot}"), "");
    db.collection::<Document>("ultron_mobile_status").update_many(
        doc! {"audience": owner},
        doc! {"$pull": {"audience": owner, "wraps": {"for": owner}}, "$unset": remove},
    ).await?;

    let uploads = db.collection::<Document>("ultron_attachment_uploads");
    let mut owned = uploads.find(doc! {"owner": owner}).projection(doc! {"_id": 1}).await?;
    let chunks = db.collection::<Document>("ultron_attachment_chunks");
    while let Some(upload) = owned.try_next().await? {
        if let Ok(id) = upload.get_object_id("_id") {
            chunks.delete_many(doc! {"upload": id}).await?;
            uploads.delete_one(doc! {"_id": id}).await?;
        }
    }
    uploads.update_many(doc! {"allowed": owner}, doc! {"$pull": {"allowed": owner}}).await?;
    // Reserve the identifier and remove the identity key so exported keyfiles cannot log in.
    db.collection::<Document>("lns").replace_one(
        doc! {"_id": owner, "status": "DELETING"},
        doc! {"_id": owner, "lns_name": owner, "status": "DELETED"},
    ).await?;
    Ok(())
}

pub async fn resume(state: AppState) {
    let mut retry = tokio::time::interval(std::time::Duration::from_secs(30));
    loop {
        retry.tick().await;
        let sweep = async {
            let mut pending = state.db.collection::<Document>("lns")
                .find(doc! {"status": "DELETING"}).projection(doc! {"_id": 1}).await?;
            while let Some(account) = pending.try_next().await? {
                if let Ok(owner) = account.get_str("_id") {
                    erase(&state, owner).await?;
                }
            }
            Ok::<(), mongodb::error::Error>(())
        };
        if sweep.await.is_err() {
            tracing::warn!("ULTRON account reset cleanup will retry");
        }
    }
}
