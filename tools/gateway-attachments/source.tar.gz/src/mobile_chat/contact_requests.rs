//! Explicit consent for direct contact requests in the hosted pilot.
use super::{address, authenticated, bad, blocked, edge, error, pair_id, reply, storage, ContactRequest, Result};
use crate::{wake, AppState};
use axum::{extract::{Path, State}, http::{HeaderMap, StatusCode}, Json};
use bson::{doc, oid::ObjectId, Document};
use futures::TryStreamExt;
use mongodb::{Collection, Database, IndexModel};
use serde_json::json;

const REQUESTS: &str = "ultron_mobile_contact_requests";

pub(super) fn enabled() -> bool {
    std::env::var("ULTRON_EXPERIMENTAL_RATCHET").as_deref() == Ok("1")
}

fn requests(db: &Database) -> Collection<Document> { db.collection(REQUESTS) }

pub(super) async fn ensure_indexes(db: &Database) -> mongodb::error::Result<()> {
    for keys in [
        doc! {"members": 1},
        doc! {"recipient": 1, "status": 1, "request_id": -1},
    ] {
        requests(db).create_index(IndexModel::builder().keys(keys).build()).await?;
    }
    Ok(())
}

pub(super) async fn status(state: &AppState, owner: &str, peer: &str) -> Result<Option<Document>> {
    requests(&state.db).find_one(doc! {"_id": pair_id(owner, peer)}).await.map_err(storage)
}

async fn allowed(state: &AppState, owner: &str, peer: &str) -> Result<()> {
    if owner == peer { return Err(bad("Scegli un altro contatto.")); }
    let own = edge(state, owner, peer).await?;
    let other = edge(state, peer, owner).await?;
    if blocked(own.as_ref()) || blocked(other.as_ref()) {
        return Err(error(StatusCode::FORBIDDEN, "Contatto non disponibile."));
    }
    wake::require_active(state, peer).await
}

pub(super) async fn request(state: &AppState, owner: &str, peer: &str) -> Result {
    allowed(state, owner, peer).await?;
    // Existing reciprocal contacts keep their consent. A lone legacy edge does
    // not give either account permission to send through the new flow.
    if super::may_send(state, owner, peer).await? {
        return Ok(reply(json!({"ok": true, "lns": peer, "mutual": true})));
    }
    let coll = requests(&state.db);
    let key = pair_id(owner, peer);
    let pending = doc! {"members": [owner, peer], "sender": owner, "recipient": peer,
        "status": "pending", "request_id": ObjectId::new()};
    coll.update_one(doc! {"_id": &key, "status": "closed"}, doc! {"$set": &pending, "$unset": {"closed_by": ""}})
        .await.map_err(storage)?;
    let inserted = coll.update_one(doc! {"_id": &key}, doc! {"$setOnInsert": &pending}).upsert(true).await;
    if let Err(err) = inserted {
        let duplicate = matches!(err.kind.as_ref(), mongodb::error::ErrorKind::Write(
            mongodb::error::WriteFailure::WriteError(write)) if write.code == 11000);
        if !duplicate { return Err(storage(err)); }
    }
    let row = coll.find_one(doc! {"_id": &key}).await.map_err(storage)?
        .ok_or_else(|| error(StatusCode::SERVICE_UNAVAILABLE, "Richiesta non disponibile."))?;
    let direction = row.get_str("sender").ok() == Some(owner);
    match row.get_str("status").unwrap_or("") {
        "accepted" => Ok(reply(json!({"ok": true, "lns": peer, "mutual": true}))),
        "pending" => Ok(reply(json!({"ok": true, "lns": peer, "mutual": false,
            "contact_request": if direction { "outgoing" } else { "incoming" }}))),
        _ => Err(error(StatusCode::CONFLICT, "Richiesta chiusa. Il contatto deve riaprire la richiesta.")),
    }
}

pub async fn accept(State(state): State<AppState>, headers: HeaderMap, Json(req): Json<ContactRequest>) -> Result {
    let owner = authenticated(&state, &headers).await?;
    let peer = address(&req.lns)?;
    allowed(&state, &owner, &peer).await?;
    let coll = requests(&state.db);
    let key = pair_id(&owner, &peer);
    let result = coll.update_one(doc! {"_id": &key, "sender": &peer, "recipient": &owner,
        "status": {"$in": ["pending", "accepted"]}},
        doc! {"$set": {"status": "accepted"}}).await.map_err(storage)?;
    if result.matched_count == 0 {
        // Legacy inbound-only entries must be reissued using the new protocol.
        return Err(error(StatusCode::NOT_FOUND, "Richiesta in arrivo non disponibile."));
    }
    Ok(reply(json!({"ok": true, "lns": peer, "mutual": true})))
}

pub async fn get(State(state): State<AppState>, headers: HeaderMap, Path(raw): Path<String>) -> Result {
    let owner = authenticated(&state, &headers).await?;
    let peer = address(&raw)?;
    let mutual = super::may_send(&state, &owner, &peer).await?;
    let row = status(&state, &owner, &peer).await?;
    let own = edge(&state, &owner, &peer).await?;
    let other = edge(&state, &peer, &owner).await?;
    let pending = row.as_ref().filter(|row|
        !blocked(own.as_ref()) && !blocked(other.as_ref()) && row.get_str("status").ok() == Some("pending"));
    let direction = pending.map(|row| if row.get_str("sender").ok() == Some(owner.as_str()) { "outgoing" } else { "incoming" });
    Ok(reply(json!({"mutual": mutual, "contact_request": direction})))
}

pub(super) async fn close(state: &AppState, owner: &str, peer: &str) -> Result<()> {
    requests(&state.db).update_one(doc! {"_id": pair_id(owner, peer)}, doc! {
        "$set": {"status": "closed", "closed_by": owner, "members": [owner, peer]},
        "$unset": {"request_id": "", "sender": "", "recipient": ""},
    }).upsert(true).await.map_err(storage)?;
    Ok(())
}

pub(super) async fn list(state: &AppState, owner: &str) -> Result<Vec<Document>> {
    requests(&state.db).find(doc! {"members": owner}).limit(2000).await.map_err(storage)?
        .try_collect().await.map_err(storage)
}

pub(crate) async fn pending_notice(state: &AppState, owner: &str) -> mongodb::error::Result<Option<ObjectId>> {
    if !enabled() { return Ok(None); }
    let row = requests(&state.db).find_one(doc! {"recipient": owner, "status": "pending"})
        .sort(doc! {"request_id": -1}).projection(doc! {"request_id": 1}).await?;
    Ok(row.and_then(|row| row.get_object_id("request_id").ok()))
}
