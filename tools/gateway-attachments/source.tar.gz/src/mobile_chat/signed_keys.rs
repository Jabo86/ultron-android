//! Signed public keys for personal ULTRON identities.
use super::{address, authenticated, bad, error, hex_len, may_send, reply, storage, Result, KEYS};
use crate::{wake, AppState};
use axum::{extract::{Path, State}, http::{HeaderMap, StatusCode}, Json};
use bson::{doc, Document};
use pqcrypto_mldsa::mldsa65;
use pqcrypto_traits::sign::{DetachedSignature as _, PublicKey as _};
use serde::Deserialize;
use serde_json::json;

#[derive(Deserialize)]
pub struct SignedKeys {
    pub kem_pk_hex: String,
    pub dh_pk_hex: String,
    pub signature_hex: String,
}

fn message(owner: &str, kem: &str, dh: &str) -> String {
    format!("ultron-chat-keys-v1\n{owner}\n{kem}\n{dh}")
}

pub(super) async fn identity_key(state: &AppState, owner: &str) -> Result<String> {
    let account = state.db.collection::<Document>("lns")
        .find_one(doc! {"lns_name": owner, "status": "ACTIVE"})
        .projection(doc! {"ultron_public_key_hex": 1}).await.map_err(storage)?;
    account.as_ref().and_then(|row| row.get_str("ultron_public_key_hex").ok())
        .map(str::to_owned)
        .ok_or_else(|| error(StatusCode::CONFLICT, "Identità ULTRON non disponibile."))
}

fn valid(owner: &str, pk_hex: &str, kem: &str, dh: &str, sig_hex: &str) -> bool {
    if !hex_len(kem, 2368) || !hex_len(dh, 64)
        || !hex_len(sig_hex, 2 * mldsa65::signature_bytes())
        || !hex_len(pk_hex, 2 * mldsa65::public_key_bytes())
    {
        return false;
    }
    let Ok(pk) = mldsa65::PublicKey::from_bytes(&hex::decode(pk_hex).unwrap_or_default()) else { return false; };
    let Ok(sig) = mldsa65::DetachedSignature::from_bytes(&hex::decode(sig_hex).unwrap_or_default()) else { return false; };
    mldsa65::verify_detached_signature(&sig, message(owner, kem, dh).as_bytes(), &pk).is_ok()
}

pub async fn publish(State(state): State<AppState>, headers: HeaderMap, Json(req): Json<SignedKeys>) -> Result {
    let owner = authenticated(&state, &headers).await?;
    let pk = identity_key(&state, &owner).await?;
    let kem = req.kem_pk_hex.to_ascii_lowercase();
    let dh = req.dh_pk_hex.to_ascii_lowercase();
    if !valid(&owner, &pk, &kem, &dh, &req.signature_hex) {
        return Err(bad("Firma delle chiavi chat non valida."));
    }
    state.db.collection::<Document>(KEYS).update_one(
        doc! {"_id": owner},
        doc! {"$set": {"kem": kem, "dh": dh, "signature": req.signature_hex.to_ascii_lowercase()}},
    ).upsert(true).await.map_err(storage)?;
    Ok(reply(json!({"ok": true})))
}

pub async fn lookup(State(state): State<AppState>, headers: HeaderMap, Path(raw): Path<String>) -> Result {
    let owner = authenticated(&state, &headers).await?;
    let peer = address(&raw)?;
    wake::require_active(&state, &peer).await?;
    if peer != owner && !may_send(&state, &owner, &peer).await? {
        return Err(error(StatusCode::FORBIDDEN, "Contatto non autorizzato."));
    }
    let row = state.db.collection::<Document>(KEYS).find_one(doc! {"_id": &peer}).await.map_err(storage)?;
    let Some(row) = row else { return Ok(reply(json!({"signed": false}))); };
    let Ok(signature) = row.get_str("signature") else { return Ok(reply(json!({"signed": false}))); };
    let pk = identity_key(&state, &peer).await?;
    let kem = row.get_str("kem").unwrap_or_default();
    let dh = row.get_str("dh").unwrap_or_default();
    if !valid(&peer, &pk, kem, dh, signature) {
        return Err(error(StatusCode::CONFLICT, "Firma delle chiavi chat non valida."));
    }
    Ok(reply(json!({
        "signed": true, "identity_pk_hex": pk, "kem_pk_hex": kem, "dh_pk_hex": dh,
        "signature_hex": signature,
    })))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn signature_binds_account_and_both_chat_keys() {
        let owner = "test@ultron.uns";
        let kem = "11".repeat(1184);
        let dh = "22".repeat(32);
        let (pk, sk) = mldsa65::keypair();
        let sig = mldsa65::detached_sign(message(owner, &kem, &dh).as_bytes(), &sk);
        let pk = hex::encode(pk.as_bytes());
        let sig = hex::encode(sig.as_bytes());
        assert!(valid(owner, &pk, &kem, &dh, &sig));
        assert!(!valid("other@ultron.uns", &pk, &kem, &dh, &sig));
        assert!(!valid(owner, &pk, &kem, &"33".repeat(32), &sig));
        assert!(!valid(owner, &pk, &"44".repeat(1184), &dh, &sig));
    }
}
