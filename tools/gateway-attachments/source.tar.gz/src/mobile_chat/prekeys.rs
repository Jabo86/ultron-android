//! Atomic distribution of signed public prekeys. Secrets stay on the device.
use super::{address, authenticated, bad, error, hex_len, may_send, reply, storage, Result};
use crate::{wake, AppState};
use axum::{extract::{Path, State}, http::{HeaderMap, StatusCode}, Json};
use bson::{doc, Bson, Document};
use pqcrypto_mldsa::mldsa65;
use pqcrypto_traits::sign::{DetachedSignature as _, PublicKey as _};
use serde::{Deserialize, Serialize};
use serde_json::json;
use sha2::{Digest, Sha256};
use std::collections::HashSet;

const MAX_DEVICES: usize = 8;
const MAX_BATCH: usize = 32;

#[derive(Clone, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
struct PublicPrekey {
    id: String,
    kem: String,
    signature: String,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Batch {
    device: String,
    generation: i64,
    keys: Vec<PublicPrekey>,
}

fn lower_hex(value: &str, len: usize) -> bool {
    hex_len(value, len) && !value.bytes().any(|b| b.is_ascii_uppercase())
}

fn valid_device(device: &str) -> bool {
    lower_hex(device, 32)
}

fn proof(owner: &str, device: &str, generation: i64, key: &PublicPrekey) -> String {
    format!("ultron-prekey-v1\n{owner}\n{device}\n{generation}\n{}\n{}", key.id, key.kem)
}

fn valid_batch(owner: &str, identity: &mldsa65::PublicKey, batch: &Batch) -> bool {
    if !valid_device(&batch.device) || batch.generation < 1 || !(1..=MAX_BATCH).contains(&batch.keys.len()) {
        return false;
    }
    let mut seen = HashSet::new();
    batch.keys.iter().all(|key| {
        if !lower_hex(&key.id, 32) || !seen.insert(&key.id) || !lower_hex(&key.kem, 2368)
            || !lower_hex(&key.signature, mldsa65::signature_bytes() * 2)
        {
            return false;
        }
        let Ok(sig) = mldsa65::DetachedSignature::from_bytes(&hex::decode(&key.signature).unwrap_or_default())
            else { return false; };
        mldsa65::verify_detached_signature(
            &sig, proof(owner, &batch.device, batch.generation, key).as_bytes(), identity,
        ).is_ok()
    })
}

pub async fn pools(State(state): State<AppState>, headers: HeaderMap, Path(raw): Path<String>) -> Result {
    let owner = authenticated(&state, &headers).await?;
    let peer = address(&raw)?;
    if peer != owner && !may_send(&state, &owner, &peer).await? {
        return Err(error(StatusCode::FORBIDDEN, "Contatto non autorizzato."));
    }
    let account = state.db.collection::<Document>("lns")
        .find_one(doc! {"_id": &peer, "lns_name": &peer, "status": "ACTIVE"})
        .projection(doc! {"chat_prekey_pools": 1})
        .await.map_err(storage)?
        .ok_or_else(|| error(StatusCode::NOT_FOUND, "Identità non disponibile."))?;
    let devices: Vec<_> = account.get_document("chat_prekey_pools").ok().into_iter()
        .flat_map(|pools| pools.iter()).filter_map(|(device, value)| {
            if !valid_device(device) { return None; }
            let pool = value.as_document()?;
            let count = pool.get_array("queue").ok()?.len();
            let generation = pool.get_i64("generation").ok()?;
            Some(json!({"device": device, "generation": generation, "available": count}))
        }).collect();
    Ok(reply(json!({"protocol": 2, "devices": devices})))
}

pub async fn publish(State(state): State<AppState>, headers: HeaderMap, Json(batch): Json<Batch>) -> Result {
    let owner = authenticated(&state, &headers).await?;
    let accounts = state.db.collection::<Document>("lns");
    let active = doc! {"_id": &owner, "lns_name": &owner, "status": "ACTIVE"};
    let account = accounts.find_one(active.clone())
        .projection(doc! {"ultron_public_key_hex": 1, "chat_prekey_pools": 1})
        .await.map_err(storage)?
        .ok_or_else(|| error(StatusCode::NOT_FOUND, "Identità non disponibile."))?;
    let raw = hex::decode(account.get_str("ultron_public_key_hex").unwrap_or_default()).unwrap_or_default();
    let identity = mldsa65::PublicKey::from_bytes(&raw)
        .map_err(|_| bad("Chiave d’identità non valida."))?;
    if !valid_batch(&owner, &identity, &batch) {
        return Err(bad("Lotto di prekey non valido."));
    }

    let mut hash = Sha256::new();
    for key in &batch.keys {
        hash.update(key.id.as_bytes());
        hash.update(key.kem.as_bytes());
    }
    let digest = hex::encode(hash.finalize());
    let slot = format!("chat_prekey_pools.{}", batch.device);
    let generation = format!("{slot}.generation");
    let queue = format!("{slot}.queue");
    let pools = account.get_document("chat_prekey_pools").cloned().unwrap_or_default();
    let mut filter = active;
    if let Ok(previous) = pools.get_document(&batch.device) {
        let old = previous.get_i64("generation").unwrap_or(0);
        // A retry, even after a claim, never makes the same batch available again.
        if old == batch.generation && previous.get_str("digest").ok() == Some(digest.as_str()) {
            return Ok(reply(json!({"ok": true})));
        }
        if old == batch.generation { return Err(error(StatusCode::CONFLICT, "La generazione è già in uso.")); }
        if old > batch.generation { return Err(error(StatusCode::CONFLICT, "Generazione superata.")); }
        filter.insert(generation, old);
        filter.insert(queue, doc! {"$size": 0});
    } else {
        if pools.len() >= MAX_DEVICES {
            return Err(error(StatusCode::CONFLICT, "Limite dispositivi raggiunto."));
        }
        // Compare only the roster. A concurrent claim can safely force a retry as well.
        if account.contains_key("chat_prekey_pools") {
            filter.insert("chat_prekey_pools", pools);
        } else {
            filter.insert("chat_prekey_pools", doc! {"$exists": false});
        }
    }
    let keys = bson::to_bson(&batch.keys).map_err(|_| bad("Lotto di prekey non valido."))?;
    let mut set = Document::new();
    set.insert(slot, doc! {"generation": batch.generation, "queue": keys, "digest": digest});
    let update = accounts.update_one(filter, doc! {"$set": set}).await.map_err(storage)?;
    if update.matched_count == 0 {
        return Err(error(StatusCode::CONFLICT, "Lotto ancora in uso o modificato. Riprova."));
    }
    Ok(reply(json!({"ok": true})))
}

pub async fn claim(State(state): State<AppState>, headers: HeaderMap, Path((raw, device)): Path<(String, String)>) -> Result {
    let owner = authenticated(&state, &headers).await?;
    let peer = address(&raw)?;
    if !valid_device(&device) { return Err(bad("Dispositivo non valido.")); }
    wake::require_active(&state, &peer).await?;
    if peer == owner || !may_send(&state, &owner, &peer).await? {
        return Err(error(StatusCode::FORBIDDEN, "Contatto non autorizzato."));
    }
    let slot = format!("chat_prekey_pools.{device}");
    let queue = format!("{slot}.queue");
    let mut filter = doc! {"_id": &peer, "lns_name": &peer, "status": "ACTIVE"};
    filter.insert(format!("{queue}.0"), doc! {"$exists": true});
    let mut pop = Document::new();
    pop.insert(queue, -1);
    let mut projection = doc! {"_id": 0};
    projection.insert(slot, 1);
    // findOneAndUpdate returns the old head and removes it in one write.
    let old = state.db.collection::<Document>("lns").find_one_and_update(filter, doc! {"$pop": pop})
        .projection(projection).await.map_err(storage)?;
    let data = old.as_ref().and_then(|row| row.get_document("chat_prekey_pools").ok())
        .and_then(|pools| pools.get_document(&device).ok());
    let Some(data) = data else { return Ok(reply(json!({"prekey": null}))); };
    let generation = data.get_i64("generation").unwrap_or(0);
    let prekey = data.get_array("queue").ok().and_then(|keys| keys.first()).cloned().unwrap_or(Bson::Null);
    let prekey: PublicPrekey = bson::from_bson(prekey).map_err(|_| bad("Prekey non disponibile."))?;
    Ok(reply(json!({"device": device, "generation": generation, "prekey": prekey})))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn proof_binds_owner_device_generation_and_key() {
        let owner = "test@ultron.uns";
        let (pk, sk) = mldsa65::keypair();
        let mut batch = Batch {
            device: "ab".repeat(16), generation: 1,
            keys: vec![PublicPrekey { id: "11".repeat(16), kem: "22".repeat(1184), signature: String::new() }],
        };
        let signature = mldsa65::detached_sign(proof(owner, &batch.device, 1, &batch.keys[0]).as_bytes(), &sk);
        batch.keys[0].signature = hex::encode(signature.as_bytes());
        assert!(valid_batch(owner, &pk, &batch));
        assert!(!valid_batch("other@ultron.uns", &pk, &batch));
        batch.generation = 2;
        assert!(!valid_batch(owner, &pk, &batch));
        batch.generation = 1;
        let duplicate = batch.keys[0].clone();
        batch.keys.push(duplicate);
        assert!(!valid_batch(owner, &pk, &batch));
    }
}
