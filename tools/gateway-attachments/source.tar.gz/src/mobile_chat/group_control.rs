//! Durable group access policy. MLS membership keys still change in a signed Commit.
use super::{address, bad, error, group_invites, groups, hex_len, purge::durable, reply, signed_keys, storage, AppState, Result};
use axum::{extract::{Path, State}, http::{HeaderMap, StatusCode}, Json};
use bson::{doc, Bson, DateTime, Document};
use futures::TryStreamExt;
use rand::{rngs::OsRng, RngCore};
use serde::Deserialize;
use serde_json::json;
use sha2::{Digest, Sha256};

const VERIFIED: &str = "ultron_mls_verified";
const REPORTS: &str = "ultron_mls_reports";

pub(super) fn enabled() -> bool {
    std::env::var("ULTRON_MLS_CONTROL").as_deref() == Ok("1")
}

pub(super) fn denied() -> super::Error {
    error(StatusCode::FORBIDDEN, "Operazione di gruppo non autorizzata.")
}

fn missing() -> super::Error {
    error(StatusCode::NOT_FOUND, "Gruppo o richiesta non disponibile.")
}

fn random_hex<const N: usize>() -> String {
    let mut bytes = [0_u8; N];
    OsRng.fill_bytes(&mut bytes);
    hex::encode(bytes)
}

fn deadline(hours: i64) -> DateTime {
    DateTime::from_millis(DateTime::now().timestamp_millis() + hours * 3_600_000)
}

async fn actor(state: &AppState, headers: &HeaderMap) -> Result<String> {
    if !enabled() { return Err(missing()); }
    groups::owner(state, headers).await
}

pub(super) fn founder<'a>(group: &'a Document) -> Result<&'a str> {
    group.get_str("admin").map_err(|_| missing())
}

fn entries(group: &Document, field: &str) -> Vec<Bson> {
    group.get_array(field).cloned().unwrap_or_default()
}

fn account_entry<'a>(group: &'a Document, field: &str, account: &str) -> Option<&'a Document> {
    group.get_array(field).ok()?.iter().filter_map(Bson::as_document)
        .find(|entry| entry.get_str("account").ok() == Some(account))
}

pub(super) fn leaving(group: &Document, account: &str) -> bool {
    account_entry(group, "leaving", account).is_some()
}

pub(super) fn visible(group: &Document, account: &str) -> bool {
    !group.contains_key("deleted_at") && !leaving(group, account) && groups::since(group, account).is_some()
}

fn rank(group: &Document, account: &str) -> u8 {
    if !visible(group, account) { return 0; }
    if founder(group).ok() == Some(account) { return 4; }
    let admission = groups::since(group, account);
    let grant = account_entry(group, "roles", account)
        .filter(|grant| grant.get_i64("since").ok() == admission);
    match grant.and_then(|grant| grant.get_str("role").ok()) {
        Some("admin") => 3,
        Some("moderator") => 2,
        _ => 1,
    }
}

fn role_name(rank: u8) -> &'static str {
    match rank { 4 => "founder", 3 => "admin", 2 => "moderator", _ => "member" }
}

pub(super) fn can_manage(group: &Document, account: &str) -> bool {
    rank(group, account) >= 3
}

pub(super) fn muted(group: &Document, account: &str) -> bool {
    account_entry(group, "mutes", account).is_some_and(|entry|
        entry.get_i64("since").ok() == groups::since(group, account) &&
        entry.get_datetime("until").is_ok_and(|until| *until > DateTime::now()))
}

pub(super) fn pending_rotation(group: &Document) -> bool {
    group.get_array("leaving").is_ok_and(|rows| !rows.is_empty())
}

pub(super) async fn live_group(state: &AppState, id: &str) -> Result<Document> {
    let group = durable(state, groups::GROUPS).find_one(doc! {"_id": id, "deleted_at": {"$exists": false}})
        .await.map_err(storage)?.ok_or_else(missing)?;
    groups::settle(state, id, group).await
}

pub(super) async fn verified(state: &AppState, account: &str) -> Result<bool> {
    let key = signed_keys::identity_key(state, account).await?;
    let fingerprint = hex::encode(Sha256::digest(key.as_bytes()));
    Ok(durable(state, VERIFIED).find_one(doc! {"_id": account, "key": fingerprint})
        .await.map_err(storage)?.is_some())
}

#[derive(Deserialize)]
pub struct AccountProof { signature: String }

pub async fn account_status(State(state): State<AppState>, headers: HeaderMap) -> Result {
    let account = actor(&state, &headers).await?;
    Ok(reply(json!({"verified": verified(&state, &account).await?})))
}

pub async fn verify_account(State(state): State<AppState>, headers: HeaderMap, Json(req): Json<AccountProof>) -> Result {
    let account = actor(&state, &headers).await?;
    let key = signed_keys::identity_key(&state, &account).await?;
    let origin = std::env::var("ULTRON_MLS_ORIGIN").map_err(|_| denied())?;
    let transcript = json!(["ultron-mls-account-v1", origin, &account, &key]).to_string();
    group_invites::verify_signature(&state, &account, &transcript, &req.signature).await?;
    let fingerprint = hex::encode(Sha256::digest(key.as_bytes()));
    durable(&state, VERIFIED).update_one(doc! {"_id": &account},
        doc! {"$set": {"key": fingerprint, "updated": DateTime::now()}})
        .upsert(true).await.map_err(storage)?;
    Ok(reply(json!({"verified": true})))
}

pub async fn policy(State(state): State<AppState>, headers: HeaderMap, Path(raw): Path<String>) -> Result {
    let account = actor(&state, &headers).await?;
    let id = groups::group_id(&raw)?;
    let _guard = groups::WRITE.lock().await;
    let group = live_group(&state, id).await?;
    if !visible(&group, &account) { return Err(missing()); }
    let members = entries(&group, "members");
    let members: Vec<_> = members.iter().filter_map(Bson::as_document).filter_map(|member| {
        let name = member.get_str("account").ok()?;
        if !visible(&group, name) { return None; }
        Some(json!({"account": name, "role": role_name(rank(&group, name)), "muted": muted(&group, name)}))
    }).collect();
    let removed = entries(&group, "hidden");
    let hidden: Vec<_> = removed.iter().filter_map(Bson::as_i64).collect();
    let leaving = if founder(&group)? == account { entries(&group, "leaving").iter().filter_map(Bson::as_document)
        .filter_map(|row| row.get_str("account").ok().map(str::to_owned)).collect::<Vec<_>>() } else { vec![] };
    Ok(reply(json!({
        "role": role_name(rank(&group, &account)), "members": members, "hidden": hidden, "leaving": leaving,
        "rotating": pending_rotation(&group), "muted": muted(&group, &account),
        "visibility": if group.contains_key("listing") {"public"} else {"private"},
    })))
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Action {
    action: String,
    target: Option<String>,
    role: Option<String>,
    minutes: Option<i64>,
    seq: Option<i64>,
    name: Option<String>,
    visibility: Option<String>,
}

fn without_account(group: &Document, field: &str, account: &str) -> Vec<Bson> {
    entries(group, field).into_iter().filter(|entry| entry.as_document()
        .and_then(|entry| entry.get_str("account").ok()) != Some(account)).collect()
}

pub async fn action(State(state): State<AppState>, headers: HeaderMap, Path(raw): Path<String>, Json(req): Json<Action>) -> Result {
    let account = actor(&state, &headers).await?;
    let id = groups::group_id(&raw)?;
    let _guard = groups::WRITE.lock().await;
    let group = live_group(&state, id).await?;
    let requester = rank(&group, &account);
    if requester == 0 { return Err(missing()); }
    let group_store = durable(&state, groups::GROUPS);
    let mut set = Document::new();
    let mut unset = Document::new();
    match req.action.as_str() {
        "role" | "mute" | "remove" => {
            let target = address(req.target.as_deref().ok_or_else(denied)?)?;
            let current = rank(&group, &target);
            if target == account || current == 0 || current >= requester || requester < 2 { return Err(denied()); }
            let since = groups::since(&group, &target).ok_or_else(denied)?;
            match req.action.as_str() {
                "role" => {
                    let role = req.role.as_deref().ok_or_else(denied)?;
                    let desired = match role { "admin" => 3, "moderator" => 2, "member" => 1, _ => return Err(denied()) };
                    if requester < 3 || desired >= requester { return Err(denied()); }
                    let mut roles = without_account(&group, "roles", &target);
                    if desired > 1 { roles.push(Bson::Document(doc! {"account": target, "since": since, "role": role})); }
                    set.insert("roles", roles);
                }
                "mute" => {
                    let minutes = req.minutes.filter(|minutes| (0..=1440).contains(minutes)).ok_or_else(denied)?;
                    let mut mutes = without_account(&group, "mutes", &target);
                    if minutes > 0 {
                        mutes.push(Bson::Document(doc! {"account": target, "since": since,
                            "until": DateTime::from_millis(DateTime::now().timestamp_millis() + minutes * 60_000)}));
                    }
                    set.insert("mutes", mutes);
                }
                _ => {
                    let mut leaving = entries(&group, "leaving");
                    leaving.push(Bson::Document(doc! {"account": target}));
                    set.insert("leaving", leaving);
                }
            }
        }
        "leave" => {
            if requester == 4 { return Err(denied()); }
            let mut leaving = entries(&group, "leaving");
            leaving.push(Bson::Document(doc! {"account": &account}));
            set.insert("leaving", leaving);
        }
        "hide" => {
            if requester < 2 { return Err(denied()); }
            let seq = req.seq.filter(|value| *value > 0).ok_or_else(denied)?;
            if seq < groups::since(&group, &account).ok_or_else(denied)? { return Err(denied()); }
            let event = durable(&state, groups::EVENTS).find_one(doc! {"group": id, "seq": seq, "kind": "message"})
                .await.map_err(storage)?.ok_or_else(missing)?;
            let author = event.get_str("author").map_err(|_| missing())?;
            if rank(&group, author) >= requester && author != account { return Err(denied()); }
            group_store.update_one(doc! {"_id": id}, doc! {"$addToSet": {"hidden": seq}})
                .await.map_err(storage)?;
            return Ok(reply(json!({"ok": true})));
        }
        "visibility" => {
            if requester < 3 { return Err(denied()); }
            match req.visibility.as_deref() {
                Some("private") => {
                    unset.insert("listing", "");
                    unset.insert("invite_link", "");
                    durable(&state, group_invites::COLLECTION).delete_many(doc! {"group": id, "link": {"$exists": true},
                        "status": {"$in": ["review", "pending", "accepted"]}}).await.map_err(storage)?;
                }
                Some("public") => {
                    let name = req.name.as_deref().map(str::trim)
                        .filter(|name| !name.is_empty() && name.chars().count() <= 60 && !name.chars().any(char::is_control))
                        .ok_or_else(|| bad("Nome pubblico non valido."))?;
                    set.insert("listing", doc! {"name": name});
                }
                _ => return Err(denied()),
            }
        }
        "link" => {
            if requester < 3 { return Err(denied()); }
            let token = random_hex::<32>();
            durable(&state, group_invites::COLLECTION).delete_many(doc! {"group": id, "link": {"$exists": true},
                "status": {"$in": ["review", "pending", "accepted"]}}).await.map_err(storage)?;
            group_store.update_one(doc! {"_id": id}, doc! {"$set": {
                "invite_link": {"hash": hex::encode(Sha256::digest(token.as_bytes())), "expires": deadline(168)},
            }}).await.map_err(storage)?;
            return Ok(reply(json!({"code": format!("{id}.{token}")})));
        }
        _ => return Err(bad("Operazione di gruppo non valida.")),
    }
    let mut update = Document::new();
    if !set.is_empty() { update.insert("$set", set); }
    if !unset.is_empty() { update.insert("$unset", unset); }
    group_store.update_one(doc! {"_id": id}, update).await.map_err(storage)?;
    Ok(reply(json!({"ok": true})))
}

#[derive(Deserialize)]
pub struct Redeem { code: String }

pub async fn redeem(State(state): State<AppState>, headers: HeaderMap, Json(req): Json<Redeem>) -> Result {
    let account = actor(&state, &headers).await?;
    let (raw, token) = req.code.trim().split_once('.').ok_or_else(missing)?;
    let id = groups::group_id(raw)?;
    if !hex_len(token, 64) { return Err(missing()); }
    let hash = hex::encode(Sha256::digest(token.as_bytes()));
    let _guard = groups::WRITE.lock().await;
    let group = live_group(&state, id).await?;
    if groups::since(&group, &account).is_some() { return Err(denied()); }
    let link = group.get_document("invite_link").map_err(|_| missing())?;
    if link.get_str("hash").ok() != Some(hash.as_str()) ||
        !link.get_datetime("expires").is_ok_and(|expires| *expires > DateTime::now()) { return Err(missing()); }
    let invites = durable(&state, group_invites::COLLECTION);
    if let Some(row) = invites.find_one(doc! {"group": id, "target": &account, "link": &hash,
        "status": {"$in": ["review", "pending", "accepted"]}}).await.map_err(storage)? {
        return Ok(reply(group_invites::view(&row).ok_or_else(missing)?));
    }
    if invites.count_documents(doc! {"group": id, "status": {"$in": ["review", "pending", "accepted"]}})
        .limit(24).await.map_err(storage)? >= 24 {
        return Err(error(StatusCode::TOO_MANY_REQUESTS, "Troppe richieste di ingresso aperte."));
    }
    let row = doc! {"_id": random_hex::<16>(), "group": id, "inviter": founder(&group)?, "target": &account,
        "status": if group.contains_key("listing") {"pending"} else {"review"}, "link": hash, "delete_at": deadline(168)};
    invites.insert_one(&row).await.map_err(storage)?;
    Ok(reply(group_invites::view(&row).ok_or_else(missing)?))
}

pub(super) fn active_link_invite(group: &Document, row: &Document) -> bool {
    let Ok(hash) = row.get_str("link") else { return true; };
    group.get_document("invite_link").is_ok_and(|link| link.get_str("hash").ok() == Some(hash) &&
        link.get_datetime("expires").is_ok_and(|expires| *expires > DateTime::now()))
}

#[derive(Deserialize)]
pub struct Review { accept: bool }

pub async fn review(State(state): State<AppState>, headers: HeaderMap, Path(raw): Path<String>, Json(req): Json<Review>) -> Result {
    let account = actor(&state, &headers).await?;
    if !hex_len(&raw, 32) { return Err(missing()); }
    let _guard = groups::WRITE.lock().await;
    let store = durable(&state, group_invites::COLLECTION);
    let row = store.find_one(doc! {"_id": &raw, "status": "review"}).await.map_err(storage)?.ok_or_else(missing)?;
    let group = live_group(&state, row.get_str("group").map_err(|_| missing())?).await?;
    if !can_manage(&group, &account) || !active_link_invite(&group, &row) { return Err(denied()); }
    store.update_one(doc! {"_id": raw, "status": "review"}, doc! {"$set": {
        "status": if req.accept {"pending"} else {"declined"},
    }}).await.map_err(storage)?;
    Ok(reply(json!({"ok": true})))
}

#[derive(Deserialize)]
pub struct Report { target: Option<String>, reason: String }

pub async fn report(State(state): State<AppState>, headers: HeaderMap, Path(raw): Path<String>, Json(req): Json<Report>) -> Result {
    let account = actor(&state, &headers).await?;
    let id = groups::group_id(&raw)?;
    let reason = req.reason.trim();
    if reason.is_empty() || reason.chars().count() > 500 { return Err(bad("Motivo della segnalazione non valido.")); }
    let _guard = groups::WRITE.lock().await;
    let group = live_group(&state, id).await?;
    if !visible(&group, &account) { return Err(missing()); }
    let target = req.target.as_deref().map(address).transpose()?;
    if target.as_ref().is_some_and(|target| !visible(&group, target)) { return Err(missing()); }
    let reports = durable(&state, REPORTS);
    if reports.count_documents(doc! {"reporter": &account, "expires": {"$gt": DateTime::now()}})
        .limit(20).await.map_err(storage)? >= 20 { return Err(denied()); }
    reports.insert_one(doc! {"group": id, "reporter": &account, "target": target, "reason": reason,
        "expires": deadline(720)}).await.map_err(storage)?;
    Ok(reply(json!({"ok": true})))
}

pub async fn reports(State(state): State<AppState>, headers: HeaderMap, Path(raw): Path<String>) -> Result {
    let account = actor(&state, &headers).await?;
    let id = groups::group_id(&raw)?;
    let _guard = groups::WRITE.lock().await;
    let group = live_group(&state, id).await?;
    if !can_manage(&group, &account) { return Err(denied()); }
    let rows: Vec<Document> = durable(&state, REPORTS).find(doc! {"group": id, "expires": {"$gt": DateTime::now()}})
        .sort(doc! {"_id": -1}).limit(50).await.map_err(storage)?.try_collect().await.map_err(storage)?;
    Ok(reply(json!(rows.iter().filter_map(|row| Some(json!({"id": row.get_object_id("_id").ok()?.to_hex(),
        "target": row.get_str("target").ok(), "reason": row.get_str("reason").ok()?}))).collect::<Vec<_>>())))
}

pub async fn delete_group(State(state): State<AppState>, headers: HeaderMap, Path(raw): Path<String>) -> Result {
    let account = actor(&state, &headers).await?;
    let id = groups::group_id(&raw)?;
    let _guard = groups::WRITE.lock().await;
    let store = durable(&state, groups::GROUPS);
    let group = store.find_one(doc! {"_id": id}).await.map_err(storage)?.ok_or_else(missing)?;
    if founder(&group)? != account { return Err(denied()); }
    if !group.contains_key("deleted_at") {
        store.replace_one(doc! {"_id": id}, doc! {"_id": id, "admin": &account, "deleted_at": DateTime::now()})
            .await.map_err(storage)?;
    }
    durable(&state, groups::EVENTS).delete_many(doc! {"group": id}).await.map_err(storage)?;
    durable(&state, group_invites::COLLECTION).delete_many(doc! {"group": id}).await.map_err(storage)?;
    durable(&state, REPORTS).delete_many(doc! {"group": id}).await.map_err(storage)?;
    durable(&state, super::group_files::STORE).delete_many(doc! {"group": id}).await.map_err(storage)?;
    Ok(reply(json!({"ok": true})))
}

pub(super) async fn indexes(db: &mongodb::Database) -> mongodb::error::Result<()> {
    use mongodb::{options::IndexOptions, IndexModel};
    use std::time::Duration;
    let reports = db.collection::<Document>(REPORTS);
    reports.create_index(IndexModel::builder().keys(doc! {"expires": 1})
        .options(IndexOptions::builder().expire_after(Duration::ZERO).build()).build()).await?;
    reports.create_index(IndexModel::builder().keys(doc! {"group": 1}).build()).await?;
    Ok(())
}
