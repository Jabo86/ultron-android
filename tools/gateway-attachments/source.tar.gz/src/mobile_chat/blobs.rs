//! Authenticated, opaque attachment storage.
use super::{address, authenticated, bad, error, may_send, reply, storage, Result};
use crate::AppState;
use axum::{
    body::{Body, Bytes},
    extract::{Path, Query, State},
    http::{header, HeaderMap, StatusCode},
    response::{IntoResponse, Response},
    Json,
};
use bson::{doc, oid::ObjectId, spec::BinarySubtype, Binary, DateTime, Document};
use futures::StreamExt;
use mongodb::{options::IndexOptions, IndexModel};
use serde::Deserialize;
use serde_json::json;
use std::time::Duration;

pub const MAX_CHUNK: usize = 4 * 1024 * 1024 + 16;
const MAX_SIZE: i64 = 50 * 1024 * 1024;
const MAX_PARTS: i64 = 13;
const UPLOADS: &str = "ultron_attachment_uploads";
const CHUNKS: &str = "ultron_attachment_chunks";

pub async fn ensure_indexes(db: &mongodb::Database) -> mongodb::error::Result<()> {
    for name in [UPLOADS, CHUNKS] {
        db.collection::<Document>(name).create_index(
            IndexModel::builder().keys(doc! {"expires_at": 1})
                .options(IndexOptions::builder().expire_after(Duration::ZERO).build())
                .build(),
        ).await?;
    }
    db.collection::<Document>(CHUNKS).create_index(
        IndexModel::builder().keys(doc! {"upload": 1, "index": 1})
            .options(IndexOptions::builder().unique(true).build()).build(),
    ).await?;
    Ok(())
}

fn unavailable() -> super::Error {
    error(StatusCode::NOT_FOUND, "Allegato non disponibile.")
}

fn id(value: &str) -> Result<ObjectId> {
    ObjectId::parse_str(value).map_err(|_| bad("Identificativo allegato non valido."))
}

pub async fn init(State(state): State<AppState>, headers: HeaderMap) -> Result {
    let owner = authenticated(&state, &headers).await?;
    let uploads = state.db.collection::<Document>(UPLOADS);
    let pending = uploads.count_documents(doc! {"owner": &owner, "ready": false, "expires_at": {"$gt": DateTime::now()}})
        .limit(8).await.map_err(storage)?;
    if pending >= 8 { return Err(error(StatusCode::TOO_MANY_REQUESTS, "Troppi allegati in caricamento.")); }
    let id = ObjectId::new();
    let expires = DateTime::from_millis(DateTime::now().timestamp_millis() + 86_400_000);
    uploads.insert_one(doc! {
        "_id": id, "owner": owner, "expires_at": expires, "ready": false, "next": 0_i64, "size": 0_i64,
    }).await.map_err(storage)?;
    Ok(reply(json!({"upload_id": id.to_hex()})))
}

#[derive(Deserialize)]
pub struct ChunkQuery {
    upload_id: String,
    index: i64,
}

pub async fn chunk(State(state): State<AppState>, headers: HeaderMap, Query(req): Query<ChunkQuery>, bytes: Bytes) -> Result {
    let owner = authenticated(&state, &headers).await?;
    if !(0..MAX_PARTS).contains(&req.index) || bytes.len() <= 16 || bytes.len() > MAX_CHUNK {
        return Err(bad("Dimensione o indice del blocco non valido."));
    }
    let _guard = super::purge::WRITES.read().await;
    let id = id(&req.upload_id)?;
    let uploads = state.db.collection::<Document>(UPLOADS);
    let chunks = state.db.collection::<Document>(CHUNKS);
    let upload = uploads.find_one(doc! {"_id": id, "owner": &owner, "ready": false, "closing": {"$exists": false}, "expires_at": {"$gt": DateTime::now()}})
        .await.map_err(storage)?.ok_or_else(unavailable)?;
    let length = bytes.len() as i64;
    let next = upload.get_i64("next").map_err(|_| unavailable())?;
    let size = upload.get_i64("size").map_err(|_| unavailable())?;
    let part = doc! {"upload": id, "index": req.index};
    if req.index > next || (req.index == next && size + length - (next + 1) * 16 > MAX_SIZE) {
        return Err(bad("Sequenza o dimensione dell’allegato non valida."));
    }
    if req.index == next {
        // Reserve the immutable chunk before advancing the upload cursor. A retry can
        // complete a partially interrupted write without changing the bytes.
        chunks.update_one(part.clone(), doc! {"$setOnInsert": {
            "upload": id, "index": req.index, "length": length,
            "expires_at": upload.get_datetime("expires_at").map_err(|_| unavailable())?.to_owned(),
            "data": Binary { subtype: BinarySubtype::Generic, bytes: bytes.to_vec() },
        }}).upsert(true).await.map_err(storage)?;
    }
    let stored = chunks.find_one(part).await.map_err(storage)?.ok_or_else(unavailable)?;
    if stored.get_binary_generic("data").map(|data| &data[..]).ok() != Some(bytes.as_ref()) {
        return Err(error(StatusCode::CONFLICT, "Il blocco è già stato caricato con dati diversi."));
    }
    if req.index == next {
        uploads.update_one(doc! {"_id": id, "owner": owner, "ready": false, "next": next, "closing": {"$exists": false}},
            doc! {"$inc": {"next": 1_i64, "size": length}}).await.map_err(storage)?;
    }
    Ok(reply(json!({"ok": true})))
}

#[derive(Deserialize)]
pub struct Finalize {
    upload_id: String,
    #[serde(default)]
    allowed: Vec<String>,
    #[serde(default)]
    generation: i64,
}

pub async fn finalize(State(state): State<AppState>, headers: HeaderMap, Json(req): Json<Finalize>) -> Result {
    let owner = authenticated(&state, &headers).await?;
    let _guard = super::purge::WRITES.read().await;
    let id = id(&req.upload_id)?;
    if req.allowed.len() > 1 { return Err(bad("L’allegato richiede una chat individuale.")); }
    let mut allowed = Vec::new();
    for raw in req.allowed {
        let peer = address(&raw)?;
        if !may_send(&state, &owner, &peer).await? {
            return Err(error(StatusCode::FORBIDDEN, "Destinatario dell’allegato non autorizzato."));
        }
        super::purge::require_generation(&state, &super::pair_id(&owner, &peer), req.generation).await?;
        allowed.push(peer);
    }
    let uploads = state.db.collection::<Document>(UPLOADS);
    let chunks = state.db.collection::<Document>(CHUNKS);
    let upload = uploads.find_one(doc! {"_id": id, "owner": &owner}).await.map_err(storage)?.ok_or_else(unavailable)?;
    if upload.get_bool("ready").unwrap_or(false) {
        if upload.get_array("allowed").ok() != doc! {"allowed": allowed}.get_array("allowed").ok() {
            return Err(error(StatusCode::CONFLICT, "Destinatario già assegnato."));
        }
        return Ok(reply(json!({"id": id.to_hex()})));
    }
    let next = upload.get_i64("next").map_err(|_| unavailable())?;
    let length = upload.get_i64("size").map_err(|_| unavailable())?;
    if next < 1 || next > MAX_PARTS || length - next * 16 > MAX_SIZE { return Err(bad("Allegato non valido: massimo 50 MB.")); }
    // Freeze the cursor before clearing TTLs. A concurrent chunk either advanced
    // the cursor first (retry finalize) or cannot become visible in the download.
    let frozen = uploads.update_one(doc! {"_id": id, "owner": &owner, "ready": false, "next": next, "closing": {"$exists": false}},
        doc! {"$set": {"closing": allowed.clone()}}).await.map_err(storage)?;
    if frozen.matched_count == 0 && upload.get_array("closing").ok() != doc! {"closing": allowed.clone()}.get_array("closing").ok() {
        return Err(error(StatusCode::CONFLICT, "Caricamento ancora in corso. Riprova."));
    }
    let parts = doc! {"upload": id, "index": {"$lt": next}};
    let cleared = chunks.update_many(parts, doc! {"$unset": {"expires_at": ""}}).await.map_err(storage)?;
    if cleared.matched_count != next as u64 { return Err(unavailable()); }
    uploads.update_one(doc! {"_id": id, "owner": owner, "next": next, "closing": allowed.clone()},
        doc! {"$set": {"ready": true, "allowed": allowed, "generation": req.generation}, "$unset": {"expires_at": "", "closing": ""}})
        .await.map_err(storage)?;
    Ok(reply(json!({"id": id.to_hex()})))
}

pub async fn download(State(state): State<AppState>, headers: HeaderMap, Path(raw): Path<String>) -> Result<Response> {
    let owner = authenticated(&state, &headers).await?;
    let id = id(&raw)?;
    let upload = state.db.collection::<Document>(UPLOADS)
        .find_one(doc! {"_id": id, "ready": true, "$or": [{"owner": &owner}, {"allowed": &owner}]})
        .await.map_err(storage)?.ok_or_else(unavailable)?;
    let next = upload.get_i64("next").map_err(|_| unavailable())?;
    let size = upload.get_i64("size").map_err(|_| unavailable())?;
    let cursor = state.db.collection::<Document>(CHUNKS)
        .find(doc! {"upload": id, "index": {"$lt": next}}).sort(doc! {"index": 1}).batch_size(1)
        .await.map_err(storage)?;
    let stream = cursor.map(|result| {
        let row = result.map_err(std::io::Error::other)?;
        let data = row.get_binary_generic("data").map_err(std::io::Error::other)?;
        Ok::<_, std::io::Error>(Bytes::copy_from_slice(data))
    });
    Ok(([(header::CONTENT_TYPE, "application/octet-stream".into()),
         (header::CACHE_CONTROL, "no-store".into()), (header::CONTENT_LENGTH, size.to_string())],
        Body::from_stream(stream)).into_response())
}

pub(super) async fn purge_pair(
    state: &AppState, owner: &str, peer: &str, conversation: &str, generation: i64,
    receipts: &mongodb::Collection<Document>,
) -> Result<()> {
    use futures::TryStreamExt;
    let uploads = super::purge::durable(state, UPLOADS);
    let chunks = super::purge::durable(state, CHUNKS);
    let mut rows = uploads.find(doc! {"$or": [
        {"owner": owner, "allowed": peer}, {"owner": peer, "allowed": owner},
        {"owner": owner, "closing": peer}, {"owner": peer, "closing": owner},
    ]}).projection(doc! {"_id": 1}).await.map_err(storage)?;
    while let Some(row) = rows.try_next().await.map_err(storage)? {
        let Ok(id) = row.get_object_id("_id") else { continue };
        receipts.update_one(doc! {"_id": id}, doc! {"$setOnInsert": {
            "conv_id": conversation, "generation": generation, "attachment": true,
        }}).upsert(true).await.map_err(storage)?;
        chunks.delete_many(doc! {"upload": id}).await.map_err(storage)?;
        uploads.delete_one(doc! {"_id": id}).await.map_err(storage)?;
    }
    Ok(())
}


pub(super) async fn require_attachments(
    state: &AppState, owner: &str, peer: &str, generation: i64, attachments: &[String],
) -> Result<()> {
    if attachments.len() > 16 { return Err(bad("Troppi allegati per il messaggio.")); }
    for raw in attachments {
        let upload = state.db.collection::<Document>(UPLOADS)
            .find_one(doc! {"_id": id(raw)?, "owner": owner, "allowed": peer, "ready": true})
            .projection(doc! {"generation": 1}).await.map_err(storage)?
            .ok_or_else(unavailable)?;
        if upload.get_i64("generation").unwrap_or(0) != generation { return Err(unavailable()); }
    }
    Ok(())
}
