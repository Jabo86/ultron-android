//! Consent for MLS delivery. Invitations contain no MLS Welcome or group key.
use super::{address, bad, error, group_control, groups, hex_len, may_send, purge::durable, reply, signed_keys, storage, AppState, Result};
use crate::wake;
use axum::{extract::{Path, State}, http::{HeaderMap, StatusCode}, Json};
use bson::{doc, DateTime, Document};
use futures::TryStreamExt;
use pqcrypto_mldsa::mldsa65;
use pqcrypto_traits::sign::{DetachedSignature as _, PublicKey as _};
use serde::Deserialize;
use serde_json::{json, Value};
use std::time::Duration;

pub(super) const COLLECTION: &str = "ultron_mls_invites";
const WEEK: i64 = 604_800_000;

pub(super) fn enabled() -> bool {
    std::env::var("ULTRON_MLS_CONSENT").as_deref() == Ok("1")
}

pub(super) async fn ensure_indexes(db: &mongodb::Database) -> mongodb::error::Result<()> {
    use mongodb::{options::IndexOptions, IndexModel};
    let records = db.collection::<Document>(COLLECTION);
    for keys in [doc! {"target": 1, "status": 1}, doc! {"group": 1, "status": 1}] {
        records.create_index(IndexModel::builder().keys(keys).build()).await?;
    }
    records.create_index(IndexModel::builder().keys(doc! {"delete_at": 1})
        .options(IndexOptions::builder().expire_after(Duration::ZERO).build()).build()).await?;
    Ok(())
}

fn denied() -> super::Error {
    error(StatusCode::FORBIDDEN, "Invito al gruppo non autorizzato.")
}
fn missing() -> super::Error {
    error(StatusCode::NOT_FOUND, "Invito al gruppo non disponibile.")
}
async fn actor(state: &AppState, headers: &HeaderMap) -> Result<String> {
    if !enabled() { return Err(missing()); }
    groups::owner(state, headers).await
}
fn expire() -> DateTime { DateTime::from_millis(DateTime::now().timestamp_millis() + WEEK) }

pub(super) fn view(row: &Document) -> Option<Value> {
    Some(json!({
        "id": row.get_str("_id").ok()?, "group": row.get_str("group").ok()?,
        "target": row.get_str("target").ok()?, "inviter": row.get_str("inviter").ok()?,
        "status": row.get_str("status").ok()?, "proof": row.get_str("proof").ok(), "note": row.get_str("note").ok(),
        "link": row.contains_key("link"),
    }))
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct NewInvite { id: String, target: String, note: Option<String> }

pub async fn request(State(state): State<AppState>, headers: HeaderMap, Path(raw): Path<String>, Json(req): Json<NewInvite>) -> Result {
    let owner = actor(&state, &headers).await?;
    let id = groups::group_id(&raw)?;
    let target = address(&req.target)?;
    if !hex_len(&req.id, 32) || target == owner || req.note.as_ref().is_some_and(|value| value.len() > 32_768) { return Err(bad("Identità invito non valida.")); }
    wake::require_active(&state, &target).await?;
    let _guard = groups::WRITE.lock().await;
    let (owner, note) = if group_control::enabled() {
        let group = group_control::live_group(&state, id).await?;
        if !group_control::can_manage(&group, &owner) { return Err(denied()); }
        let founder = group_control::founder(&group)?.to_owned();
        let note = if founder == owner { req.note } else { None };
        (founder, note)
    } else { (owner, req.note) };
    if !may_send(&state, &owner, &target).await? { return Err(denied()); }
    let group = groups::admin_group(&state, id, &owner).await?;
    if groups::since(&group, &target).is_some() { return Err(denied()); }
    let records = durable(&state, COLLECTION);
    if let Some(row) = records.find_one(doc! {"_id": &req.id}).await.map_err(storage)? {
        if row.get_str("group").ok() != Some(id) || row.get_str("inviter").ok() != Some(owner.as_str())
            || row.get_str("target").ok() != Some(target.as_str()) { return Err(denied()); }
        return Ok(reply(view(&row).ok_or_else(missing)?));
    }
    if let Some(row) = records.find_one(doc! {"group": id, "inviter": &owner, "target": &target,
        "link": {"$exists": false}, "status": {"$in": ["pending", "accepted"]}}).await.map_err(storage)? {
        return Ok(reply(view(&row).ok_or_else(missing)?));
    }
    if records.count_documents(doc! {"group": id, "status": {"$in": ["pending", "accepted"]}})
        .limit(24).await.map_err(storage)? >= 24 {
        return Err(error(StatusCode::TOO_MANY_REQUESTS, "Troppi inviti aperti."));
    }
    let mut row = doc! {"_id": &req.id, "group": id, "inviter": owner, "target": target, "status": "pending", "delete_at": expire()};
    if let Some(note) = note { row.insert("note", note); }
    records.insert_one(&row).await.map_err(storage)?;
    Ok(reply(view(&row).ok_or_else(missing)?))
}

async fn query(state: &AppState, filter: Document) -> Result {
    let rows: Vec<Document> = durable(state, COLLECTION).find(filter).sort(doc! {"_id": 1})
        .limit(100).await.map_err(storage)?.try_collect().await.map_err(storage)?;
    let mut available = Vec::new();
    for row in rows {
        let Some(mut item) = view(&row) else { continue; };
        if group_control::enabled() {
            let id = row.get_str("group").map_err(|_| missing())?;
            let Some(group) = durable(state, groups::GROUPS).find_one(doc! {"_id": id, "deleted_at": {"$exists": false}})
                .await.map_err(storage)? else { continue; };
            if !group_control::active_link_invite(&group, &row) { continue; }
            let public = group.contains_key("listing");
            item["public"] = json!(public);
            if public && row.get_str("status").ok() == Some("accepted") && !group_control::verified(state, row.get_str("target").map_err(|_| missing())?).await? {
                item["status"] = json!("verification");
            }
        }
        available.push(item);
    }
    Ok(reply(json!(available)))
}

pub async fn inbox(State(state): State<AppState>, headers: HeaderMap) -> Result {
    let target = actor(&state, &headers).await?;
    query(&state, doc! {"target": target, "status": {"$in": ["review", "pending", "accepted"]}}).await
}

pub async fn outgoing(State(state): State<AppState>, headers: HeaderMap, Path(raw): Path<String>) -> Result {
    let owner = actor(&state, &headers).await?;
    let id = groups::group_id(&raw)?;
    let owner = if group_control::enabled() {
        let _guard = groups::WRITE.lock().await;
        let group = group_control::live_group(&state, id).await?;
        if !group_control::can_manage(&group, &owner) { return Err(denied()); }
        group_control::founder(&group)?.to_owned()
    } else {
        groups::admin_group(&state, id, &owner).await?;
        owner
    };
    query(&state, doc! {"group": id, "inviter": owner, "status": {"$in": ["review", "pending", "accepted", "declined"]}}).await
}

pub(super) async fn verify_signature(state: &AppState, signer: &str, transcript: &str, signature: &str) -> Result<()> {
    if !hex_len(signature, 6618) { return Err(denied()); }
    let key = signed_keys::identity_key(state, signer).await?;
    let key = hex::decode(key).map_err(|_| denied())?;
    let sig = hex::decode(signature).map_err(|_| denied())?;
    let key = mldsa65::PublicKey::from_bytes(&key).map_err(|_| denied())?;
    let sig = mldsa65::DetachedSignature::from_bytes(&sig).map_err(|_| denied())?;
    mldsa65::verify_detached_signature(&sig, transcript.as_bytes(), &key).map_err(|_| denied())
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Decision { decision: String, signature: String }

pub async fn decide(State(state): State<AppState>, headers: HeaderMap, Path(id): Path<String>, Json(req): Json<Decision>) -> Result {
    let target = actor(&state, &headers).await?;
    if !hex_len(&id, 32) || !matches!(req.decision.as_str(), "accepted" | "declined")
        || !hex_len(&req.signature, 6618) { return Err(bad("Decisione invito non valida.")); }
    let _guard = groups::WRITE.lock().await;
    let records = durable(&state, COLLECTION);
    let row = records.find_one(doc! {"_id": &id, "target": &target}).await.map_err(storage)?.ok_or_else(missing)?;
    let group = row.get_str("group").map_err(|_| missing())?;
    let inviter = row.get_str("inviter").map_err(|_| missing())?;
    if group_control::enabled() {
        let current = group_control::live_group(&state, group).await?;
        if !group_control::active_link_invite(&current, &row) { return Err(missing()); }
    }
    let scope = std::env::var("ULTRON_MLS_ORIGIN").map_err(|_| denied())?;
    let transcript = json!(["ultron-mls-consent-v1", scope, group, &id, inviter, &target, &req.decision]).to_string();
    verify_signature(&state, &target, &transcript, &req.signature).await?;
    let status = row.get_str("status").map_err(|_| missing())?;
    if status == req.decision { return Ok(reply(view(&row).ok_or_else(missing)?)); }
    if status != "pending" || row.get_datetime("delete_at").is_ok_and(|value| *value <= DateTime::now()) {
        return Err(denied());
    }
    let mut update = doc! {"$set": {"status": &req.decision, "proof": &req.signature}};
    if req.decision == "accepted" { update.insert("$unset", doc! {"delete_at": ""}); }
    records.update_one(doc! {"_id": &id, "target": &target, "status": "pending"}, update).await.map_err(storage)?;
    let found = records.find_one(doc! {"_id": id, "target": target}).await.map_err(storage)?.ok_or_else(missing)?;
    Ok(reply(view(&found).ok_or_else(missing)?))
}

pub(super) async fn check_accepted(state: &AppState, id: &str, group: &str, inviter: &str, target: &str) -> Result<String> {
    if !hex_len(id, 32) { return Err(denied()); }
    let row = durable(state, COLLECTION).find_one(doc! {
        "_id": id, "group": group, "inviter": inviter, "target": target, "status": "accepted",
    }).await.map_err(storage)?.ok_or_else(denied)?;
    if group_control::enabled() {
        let current = durable(state, groups::GROUPS).find_one(doc! {"_id": group})
            .await.map_err(storage)?.ok_or_else(missing)?;
        if !group_control::active_link_invite(&current, &row) { return Err(denied()); }
    }
    Ok(row.get_str("proof").map_err(|_| denied())?.to_owned())
}

pub(super) async fn settle(state: &AppState, invitation: &str, event: &str) -> Result<()> {
    let result = durable(state, COLLECTION).update_one(doc! {"_id": invitation, "$or": [
        {"status": "accepted"}, {"status": "joined", "event": event},
    ]}, doc! {"$set": {"status": "joined", "event": event, "delete_at": expire()}}).await.map_err(storage)?;
    if result.matched_count != 1 { return Err(denied()); }
    Ok(())
}
