//! Device wake channel for ULTRON Android. Only notification counts leave this API.

use std::time::{Duration, Instant};

use axum::{
    extract::{Query, State},
    http::{header::CACHE_CONTROL, HeaderMap, StatusCode},
    Json,
};
use bson::{doc, Document};
use chrono::Utc;
use mongodb::{options::ReturnDocument, Collection};
use serde::Deserialize;
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use tokio::sync::Semaphore;

use crate::{misc::jwt_decode, AppState};

const DEVICE_TTL: i64 = 30 * 24 * 60 * 60;
const TEST_TTL: i64 = 90;
const MAX_WAIT: u64 = 25;
static POLL_SLOTS: Semaphore = Semaphore::const_new(64);

type ApiError = (StatusCode, Json<Value>);
type ApiResult<T> = Result<T, ApiError>;

#[derive(Deserialize)]
pub struct DeviceRequest {
    rid: String,
}

#[derive(Deserialize)]
pub struct PollRequest {
    rid: String,
    #[serde(default)]
    wait: u64,
    contact: Option<String>,
}

fn error(status: StatusCode, detail: &str) -> ApiError {
    (status, Json(json!({ "detail": detail })))
}

fn unavailable(_: mongodb::error::Error) -> ApiError {
    error(StatusCode::SERVICE_UNAVAILABLE, "wake storage unavailable")
}

fn now() -> i64 {
    Utc::now().timestamp()
}

fn rid_hash(rid: &str) -> ApiResult<String> {
    if rid.len() < 32 || rid.len() > 128 || rid.len() % 2 != 0
        || !rid.bytes().all(|byte| byte.is_ascii_hexdigit())
    {
        return Err(error(StatusCode::BAD_REQUEST, "invalid rid"));
    }
    let bytes = hex::decode(rid).map_err(|_| error(StatusCode::BAD_REQUEST, "invalid rid"))?;
    Ok(hex::encode(Sha256::digest(bytes)))
}

fn devices(state: &AppState) -> Collection<Document> {
    state.db.collection("ultron_wake_devices")
}

pub(crate) async fn require_active(state: &AppState, owner: &str) -> ApiResult<()> {
    let active = state.db.collection::<Document>("lns")
        .find_one(doc! { "lns_name": owner, "status": "ACTIVE" })
        .projection(doc! { "_id": 1 })
        .await
        .map_err(unavailable)?;
    if active.is_none() {
        return Err(error(StatusCode::NOT_FOUND, "wake device unavailable"));
    }
    Ok(())
}

pub(crate) fn identity(headers: &HeaderMap) -> ApiResult<(String, i64)> {
    let claims = jwt_decode(headers)
        .ok_or_else(|| error(StatusCode::UNAUTHORIZED, "valid session required"))?;
    let owner = claims.sub.filter(|sub| !sub.is_empty())
        .ok_or_else(|| error(StatusCode::UNAUTHORIZED, "identity required"))?;
    let issued_at = claims.iat
        .ok_or_else(|| error(StatusCode::UNAUTHORIZED, "identity required"))?;
    Ok((owner, issued_at))
}

pub async fn register(
    State(state): State<AppState>,
    headers: HeaderMap,
    Json(req): Json<DeviceRequest>,
) -> ApiResult<Json<Value>> {
    let (owner, issued_at) = identity(&headers)?;
    require_active(&state, &owner).await?;
    let key = rid_hash(&req.rid)?;
    let collection = devices(&state);
    let current = now();
    let renew = collection.update_one(
        doc! { "_id": &key, "owner": &owner },
        doc! { "$set": { "expires_at": current + DEVICE_TTL },
               "$max": { "session_iat": issued_at } },
    ).await.map_err(unavailable)?;
    if renew.matched_count == 0 {
        let registration = collection.insert_one(doc! {
            "_id": &key, "owner": &owner, "expires_at": current + DEVICE_TTL,
            "session_iat": issued_at,
        }).await;
        if let Err(failure) = registration {
            if !matches!(failure.kind.as_ref(), mongodb::error::ErrorKind::Write(
                mongodb::error::WriteFailure::WriteError(err)) if err.code == 11000)
            {
                return Err(unavailable(failure));
            }
            // Another registration won the insert. Renew only for the same account.
            let retry = collection.update_one(
                doc! { "_id": &key, "owner": &owner },
                doc! { "$set": { "expires_at": current + DEVICE_TTL },
                       "$max": { "session_iat": issued_at } },
            ).await.map_err(unavailable)?;
            if retry.matched_count == 0 {
                return Err(error(StatusCode::CONFLICT, "wake device unavailable"));
            }
        }
    }
    Ok(Json(json!({ "ok": true })))
}

pub async fn revoke(
    State(state): State<AppState>,
    headers: HeaderMap,
    Json(req): Json<DeviceRequest>,
) -> ApiResult<Json<Value>> {
    let (owner, _) = identity(&headers)?;
    let key = rid_hash(&req.rid)?;
    devices(&state).delete_one(doc! { "_id": key, "owner": owner })
        .await.map_err(unavailable)?;
    Ok(Json(json!({ "ok": true })))
}

pub async fn test_notify(
    State(state): State<AppState>,
    headers: HeaderMap,
) -> ApiResult<Json<Value>> {
    let started = Instant::now();
    let (owner, _) = identity(&headers)?;
    require_active(&state, &owner).await?;
    let current = now();
    let collection = devices(&state);
    let listening = collection.find_one(doc! {
        "owner": &owner, "expires_at": { "$gt": current },
        "last_poll_at": { "$gt": current - 40 },
    }).projection(doc! { "_id": 1 }).await.map_err(unavailable)?.is_some();
    let queued = collection.update_many(
        doc! { "owner": owner, "expires_at": { "$gt": current } },
        doc! { "$set": { "test_until": current + TEST_TTL } },
    ).await.map_err(unavailable)?;
    let count = queued.matched_count;
    Ok(Json(json!({
        "ok": count > 0,
        "wake": { "alive": listening, "registered": count, "queued": count },
        "total_ms": started.elapsed().as_millis() as u64,
    })))
}

pub(crate) async fn check_revocation(state: &AppState, owner: &str, registration_iat: i64) -> ApiResult<()> {
    let revoke = state.db.collection::<Document>("revoked_jwts")
        .find_one(doc! { "_id": format!("nuke:{owner}") })
        .await
        .map_err(unavailable)?;
    if let Some(marker) = revoke {
        let cutoff = crate::get_i64_lenient(&marker, "nuked_iat");
        if cutoff <= 0 || registration_iat <= cutoff {
            return Err(error(StatusCode::NOT_FOUND, "wake device unavailable"));
        }
    }
    Ok(())
}

pub async fn poll(
    State(state): State<AppState>,
    Query(req): Query<PollRequest>,
) -> ApiResult<([(axum::http::HeaderName, &'static str); 1], Json<Value>)> {
    let key = rid_hash(&req.rid)?;
    let _slot = POLL_SLOTS.try_acquire()
        .map_err(|_| error(StatusCode::SERVICE_UNAVAILABLE, "wake channel busy"))?;
    let deadline = tokio::time::Instant::now() + Duration::from_secs(req.wait.min(MAX_WAIT));
    let collection = devices(&state);

    let mut record_poll = true;
    loop {
        let current = now();
        let active_filter = doc! { "_id": &key, "expires_at": { "$gt": current } };
        let registration = collection.find_one(active_filter.clone()).await
            .map_err(unavailable)?
            .ok_or_else(|| error(StatusCode::NOT_FOUND, "wake device unavailable"))?;
        let owner = registration.get_str("owner")
            .map_err(|_| error(StatusCode::NOT_FOUND, "wake device unavailable"))?;
        require_active(&state, owner).await?;
        check_revocation(&state, owner, crate::get_i64_lenient(&registration, "session_iat")).await?;

        if record_poll {
            collection.update_one(
                active_filter.clone(),
                doc! { "$set": { "last_poll_at": current } },
            ).await.map_err(unavailable)?;
            record_poll = false;
        }

        let pending = state.db.collection::<Document>("pulse_messages")
            .count_documents(doc! { "to_lns": owner, "delivered_at": bson::Bson::Null })
            .limit(100)
            .await.map_err(unavailable)?;

        let mobile_pending = state.db.collection::<Document>("ultron_mobile_messages")
            .count_documents(doc! {"to_lns": owner, "delivered": false, "silent": false, "hidden_for": {"$ne": owner}, "hidden_for_all": {"$ne": true}})
            .limit(100).await.map_err(unavailable)?;
        let pending = pending.saturating_add(mobile_pending);

        // Stable message identity: a fluctuating unread count is not a new event.
        let message_notice = state.db.collection::<Document>("ultron_mobile_messages")
            .find_one(doc! {"to_lns": owner, "delivered": false, "silent": false, "hidden_for": {"$ne": owner}, "hidden_for_all": {"$ne": true}})
            .sort(doc! {"_id": -1}).projection(doc! {"_id": 1}).await.map_err(unavailable)?
            .and_then(|row| row.get_object_id("_id").ok()).map(|id| id.to_hex());
        let legacy_notice = state.db.collection::<Document>("pulse_messages")
            .find_one(doc! {"to_lns": owner, "delivered_at": bson::Bson::Null})
            .sort(doc! {"_id": -1}).projection(doc! {"_id": 1}).await.map_err(unavailable)?
            .and_then(|row| row.get_object_id("_id").ok()).map(|id| id.to_hex());
        let message_notice = message_notice.into_iter().chain(legacy_notice).max();

        let mut pending_test = active_filter;
        pending_test.insert("test_until", doc! { "$gt": current });
        let test = collection.find_one_and_update(
            pending_test,
            doc! { "$unset": { "test_until": "" } },
        ).return_document(ReturnDocument::Before).await.map_err(unavailable)?.is_some();

        let call = registration.get_str("call_rid").ok()
            .filter(|_| crate::get_i64_lenient(&registration, "call_until") > current);
        let count = if test { pending.max(1) } else { pending };
        let contact = crate::mobile_chat::contact_requests::pending_notice(&state, owner)
            .await.map_err(unavailable)?.map(|id| id.to_hex());
        let contact_changed = contact.as_deref().is_some_and(|id| Some(id) != req.contact.as_deref());
        if count > 0 || call.is_some() || contact_changed || tokio::time::Instant::now() >= deadline {
            return Ok(([(CACHE_CONTROL, "no-store")], Json(json!({ "n": count, "message_notice": message_notice, "test": test, "call": call, "contact": contact }))));
        }
        let next = tokio::time::Instant::now() + Duration::from_secs(2);
        tokio::time::sleep_until(next.min(deadline)).await;
    }
}

#[cfg(test)]
mod tests {
    use super::rid_hash;

    #[test]
    fn hashes_the_android_rid_without_storing_the_token() {
        let rid = "e1".repeat(24);
        let hash = rid_hash(&rid).unwrap();
        assert_eq!(hash.len(), 64);
        assert_eq!(hash, rid_hash(&rid.to_uppercase()).unwrap());
        assert_ne!(hash, rid_hash(&"e2".repeat(24)).unwrap());
    }

    #[test]
    fn rejects_malformed_tokens() {
        for token in ["e1".repeat(15), "g1".repeat(24), "1".repeat(49), "11".repeat(65)] {
            assert!(rid_hash(&token).is_err());
        }
    }
}
